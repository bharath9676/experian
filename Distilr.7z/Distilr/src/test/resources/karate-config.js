function() {
    var System = Java.type('java.lang.System');
    var env = System.getProperty("karate.env");
	var host;
	var msgId = function() {  return java.util.UUID.randomUUID().toString() };

	if(!env){
		env = 'uat';
	}
	

var config = {
	"makoKotlinURL":"https://griffin-wapi-grif.sit.apps.cs.sgp.dbs.com",
	"accessToken" : "AT-3590-ZSM6ZcwvySLwJp1gvtNCFwSFa9S5KT2K",
	"sitURL" : "https://reqres.in",
	"distilr_dev" : "https://adamsdev.compassmanager.com",
	"distilr_sit" : "https://distilrapi.sit.apps.cs.sgp.dbs.com",
	"distilr_uat" : "https://wapi-account-sync-api-mako.uat.apps.cs.sgp.dbs.com",
    "success" : "SUCCESS",
    "failure" : "FAILURE",
	};
karate.configure('readTimeout', 150000);
return config;
}

