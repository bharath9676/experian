package com.optum.coliseum.generic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DBUtils {
	static Connection con = null;

	public static void main(String[] args)throws Exception {
		DBCon();
		}
	
	public static void DBCon() throws ClassNotFoundException, SQLException {
		Class.forName("net.sourceforge.jtds.jdbc.Driver");
		Connection connection = DriverManager.getConnection("C:\\Users\\home\\Desktop\\test.xlsx");	
		Statement statement = connection.createStatement();
		ResultSet resultSet=statement.executeQuery("Select * from TestB");
		while(resultSet.next()) {
			System.out.println(resultSet.getString("TC"));;
		}
	}

	public static Connection DBConnect_Automation()
	{
		try{
			if(Settings.getProperty("databasename", "db").isEmpty() || Settings.getProperty("username", "db").isEmpty() ||Settings.getProperty("password", "db").isEmpty()
					||Settings.getProperty("sqlserver", "db").isEmpty() || Settings.getProperty("portnumber", "db").isEmpty()){

			}else{
				Class.forName("net.sourceforge.jtds.jdbc.Driver");
				
	        	String url ="jdbc:jtds:sqlserver://"+Settings.getProperty("sqlserver", "db")+":"+Settings.getProperty("portnumber", "db")+";useLOBs=false;databaseName="+Settings.getProperty("databasename", "db")+";user="+Settings.getProperty("username", "db")+";password="+Settings.getProperty("password", "db")+";integratedSecurity=true";
	            con =DriverManager.getConnection(url);
			    System.out.println("Coliseum database connected!");
			}
		    return con;
		}
		catch(Exception e1){
			e1.printStackTrace();
			System.out.println("Couldnot connect to Automation Database!");
			return null;
		}
	}

	public static Connection DBConnect_Application()
	{
		Connection con 	= DBUtils.DBConnect_Automation();
		if(con!=null){
		String sServerName 	= Settings.getEnvValue("DB_SERVER", con);
		String sDBName 		= Settings.getEnvValue("DB_NAME", con);
        String sUsername 	= Settings.getEnvValue("DB_USERNAME", con);
        String sPassword 	= Settings.getEnvValue("DB_PASSWORD", con);
        try {con.close();} catch (SQLException e) {}

        try{
        	Class.forName("net.sourceforge.jtds.jdbc.Driver");
	    	String url ="jdbc:jtds:sqlserver://"+sServerName+";useLOBs=false;databaseName="+sDBName+";user="+sUsername+";password="+sPassword+";integratedSecurity=true";
	    	con =DriverManager.getConnection(url);
			System.out.println("Application database connected!");

		    return con;
		}

        catch(Exception e1){
			e1.printStackTrace();
			System.out.println("Could not connect to Application Database!");
			return null;
		}
	}
		return con;
	}

	public static void FixDrvRecIDs()
	{
		Connection con = DBConnect_Automation();
		int i = 1;
		String sQuery = "Select * from Driver order by ModuleID, TCID, STEPID";
		try {
			ResultSet rs = con.createStatement().executeQuery(sQuery);
			while (rs.next()) {
				sQuery = "Update Driver set DRV_REC_ID = '"+i+"' where MODULEID = '"+rs.getString("ModuleID")+"' and TCID = '"+rs.getString("TCID")+"' and STEPID = '"+rs.getString("STEPID")+"'";
				con.createStatement().executeUpdate(sQuery);
				i = i + 1;
			}
			System.out.println("DRV_REC_IDs fixed.");
		} catch (SQLException e) {}
   	}

}
