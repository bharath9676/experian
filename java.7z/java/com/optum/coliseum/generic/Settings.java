package com.optum.coliseum.generic;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class Settings {

	public static String filePath=Constants.PATH_CONFIG_FOLDER;

	public static String getSetting(String propertyName, Connection connection){
		//Here We need to set property values
		String propertyValue  = getProperty(propertyName, "Override");
		if (propertyValue!=null) System.out.println("Setting Overriden! "+propertyName+" set to : "+propertyValue);
		else {
           try {
				ResultSet rs=connection.createStatement().executeQuery("select VALUE from SETTINGS where SKEY ='"+propertyName+"'");
				if (rs.next()) propertyValue = rs.getString("VALUE");
           } catch (SQLException e) {e.printStackTrace();}
        }
        return propertyValue;
    }


	public static String getEnvValue(String EnvParameter, Connection connection){
		String str = null;
		String sAut = Settings.getSetting("AUT", connection);
		String sEnv = Settings.getSetting("ENVIRONMENT", connection);
	    try {
			ResultSet rs=connection.createStatement().executeQuery("select "+EnvParameter+" from ENV where APPLICATION ='"+sAut+"' and TEST_ENVIRONMENT = '"+sEnv+"'");
			if (rs.next()) str = rs.getString(EnvParameter);
        } catch (SQLException e) {e.printStackTrace();}

 		return str;
    }

	public static String getProperty(String sPropName, String sFileName) throws FileNotFoundException, IOException{
		
	 	   String  str=null;
	 	   Properties prop = new Properties();
	 	   InputStream input = null;
	 		try {
	 			createFolder(sFileName);
	 			input = new FileInputStream(""+filePath+"/"+sFileName+".properties");
				prop.load(input);
	 			str = prop.getProperty(sPropName);
	 		}
	 		catch (Exception ex) {ex.printStackTrace();}
	 		finally {if (input != null) {try {input.close();} catch (IOException e) {}}}
		return str;
	}
	public static void setTempProperty(String propertyName , String propertyValue, String fileName) throws IOException{

 		try {
 			createFolder(fileName);
			FileInputStream in = new FileInputStream(filePath+"/"+fileName+".properties");
			Properties props = new Properties();
			props.load(in);
			in.close();


			FileOutputStream out = new FileOutputStream(filePath+"/"+fileName+".properties");
			props.setProperty(propertyName, propertyValue);
			props.store(out, null);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

x	static Boolean createFolder(String fileName)throws Exception{
		if(!(new File(filePath).exists())) new File(filePath).mkdirs();

 		if(!(new File(filePath+"/"+fileName+".properties").exists())) new File(filePath+"/"+fileName+".properties").createNewFile();

 		if(new File(filePath+"/"+fileName+".properties").length()==0)
 			return true;
 		else
 			return false;
	}
}

