package com.optum.coliseum.generic;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test {
	public static void main(String []args) {
		Pattern pattern=Pattern.compile("[0-9]");
		Matcher matcher=pattern.matcher("jhgjh6545ghfgh");
		while(matcher.find()) {
			System.out.println(matcher.group());
		}
	}

}
