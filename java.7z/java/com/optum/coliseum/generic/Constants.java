package com.optum.coliseum.generic;

public class Constants {

	// Classpath locations
	public static final String CLASSPATH_MEDIA_FOLDER = "media/";

	// Properties (user configurable parameters)
	public static final String CFG_DB_NAME_PARAM = "databasename";
	public static final String CFG_DB_USER_PARAM = "coliseum_autotesting";
	public static final String CFG_DB_PASSWORD_PARAM = "password";
	public static final String CFG_DB_URL_PARAM = "sqlserver";
	public static final String CFG_DB_PORT_PARAM = "portnumber";

	// Base paths (not user configurable)
	public static final String PATH_CONFIG_FOLDER = "./config/";
	public static final String PATH_BIN_FOLDER = "./bin/";
	public static final String PATH_REPORTS_FOLDER = "./reports/";
	public static final String PATH_SERVERS_FOLDER = "./servers/";

	// AutoIT (not user configurable)
	public static final String PATH_AUTOIT_FILEDOWNLOAD = PATH_BIN_FOLDER + "AutoIT/FileDownload.exe";
	public static final String PATH_AUTOIT_REQUESTPHARMACYCARD = PATH_BIN_FOLDER + "AutoIT/Request Pharmacy Card.exe";
	public static final String PATH_AUTOIT_SQLDB1 = PATH_BIN_FOLDER + "AutoIT/SQLDB1.exe";
	public static final String PATH_AUTOIT_WINDOWSFRAMEWORK = PATH_BIN_FOLDER + "AutoIT/WindowsFramework.exe";

	// Database (not user configurable)
	public static final String PATH_DATABASE_APP = PATH_BIN_FOLDER + "Database/APP.sqlite";
	public static final String PATH_DATABASE_KILLPROCS = PATH_BIN_FOLDER + "Database/KillProcs.vbs";
	public static final String PATH_DATABASE_TESTMANAGER = PATH_BIN_FOLDER + "Database/TESTMANAGER.sqlite";

	// Drivers (not user configurable)
	public static final String PATH_DRIVERS_CHROMEDRIVER = PATH_BIN_FOLDER + "Drivers/chromedriver.exe";
	public static final String PATH_DRIVERS_GECKODRIVER = PATH_BIN_FOLDER + "Drivers/geckodriver.exe";
	public static final String PATH_DRIVERS_IEDRIVERSERVER = PATH_BIN_FOLDER + "Drivers/IEDriverServer.exe";
	public static final String PATH_DRIVERS_KILLPROCS = PATH_BIN_FOLDER + "Drivers/KillProcs.vbs";
	public static final String PATH_DRIVERS_PHANTOMJS = PATH_BIN_FOLDER + "Drivers/phantomjs.exe";
	public static final String PATH_DRIVERS_REPORTZIPPER2 = PATH_BIN_FOLDER + "Drivers/ReportZipper2.vbs";
	public static final String PATH_DRIVERS_SENDMAIL = PATH_BIN_FOLDER + "Drivers/SendMail.vbs";
	public static final String PATH_DRIVERS_TEMP = PATH_BIN_FOLDER + "Drivers/temp.vbs";

}
