package com.optum.coliseum.generic;

import java.io.IOException;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;

public class GenericUtils {
	public static void setCellsAlignment(JTable table, int alignment)
    {
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(alignment);

        TableModel tableModel = table.getModel();

        for (int columnIndex = 0; columnIndex < tableModel.getColumnCount(); columnIndex++)
        {
            table.getColumnModel().getColumn(columnIndex).setCellRenderer(rightRenderer);
        }
    }

	public static void sendReportMail(){
        try {Runtime.getRuntime().exec( "wscript " + Constants.PATH_DRIVERS_REPORTZIPPER2 ); Thread.sleep(1000);}
        catch (IOException | InterruptedException e) {e.printStackTrace();System.exit(0);}
          System.out.println("Execution Report sent to all!");
    }
}
