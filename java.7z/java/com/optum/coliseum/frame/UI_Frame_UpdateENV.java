package com.optum.coliseum.frame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;

import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.DBUtils;

import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;

@SuppressWarnings("serial")
public class UI_Frame_UpdateENV extends JFrame {
	static Connection connection = null;
	private JComboBox<String> cBox_App;
	private JComboBox<String> cBox_Env;
	private JPanel contentPane;
	private JTextField txt_Login;
	private JTextField txt_Uname;
	private JTextField txt_DBUname;
	private JTextField txt_Pwd;
	private JTextField txt_DBPwd;
	private JLabel label_1;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					final UI_Frame_UpdateENV frame = new UI_Frame_UpdateENV();
					frame.setVisible(true);

					frame.addWindowListener(new java.awt.event.WindowAdapter() {
					    @Override
					    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
					        if (JOptionPane.showConfirmDialog(frame,"Are you sure to close this window?", "Really Closing?",JOptionPane.YES_NO_OPTION,
					            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
					        	frame.dispose();
					        	try {
					        		connection.close();
					        		UI_Frame_Dashboard homePage = new UI_Frame_Dashboard();
					        		homePage.setVisible(true);
								} catch (Exception e) {
									e.printStackTrace();
								}
					        }
					        else{
					        	frame.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
					        }
					    }
					});
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void Fill_Env()
	{
		if (cBox_Env.getItemCount()>0) cBox_Env.removeAllItems();
		try{
			String query = "Select DISTINCT TEST_ENVIRONMENT FROM ENV where APPLICATION = '"+cBox_App.getSelectedItem()+"'";
			PreparedStatement pst  = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			cBox_Env.addItem("--Select Test Env--");
			while(rs.next()){
				cBox_Env.addItem(rs.getString("TEST_ENVIRONMENT"));
			}
			rs.close();
			pst.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	public void Fill_App()
	{
		try{
			String query = "Select DISTINCT APPLICATION FROM ENV";
			PreparedStatement pst  = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			cBox_App.addItem("--Select Application--");
			while(rs.next()){
				cBox_App.addItem(rs.getString("APPLICATION"));
			}
			rs.close();
			pst.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	public UI_Frame_UpdateENV()throws Exception {

		try {
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}

		setResizable(false);
		connection = DBUtils.DBConnect_Automation();
		setTitle("COLESIUM");
		setIconImage(Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Dlogo.jpg")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 960, 600);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblEnvironment = new JLabel("ENVIRONMENT");
		lblEnvironment.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
		lblEnvironment.setForeground(new Color(255, 140, 0));
		lblEnvironment.setBounds(267, 129, 106, 30);
		contentPane.add(lblEnvironment);

		cBox_Env = new JComboBox<String>();
		cBox_Env.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		cBox_Env.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query = "select * from ENV where TEST_ENVIRONMENT= '"+(String) cBox_Env.getSelectedItem()+"' and APPLICATION = '"+cBox_App.getSelectedItem()+"'" ;
					PreparedStatement statement = connection.prepareStatement(query);
					ResultSet resultSet = statement.executeQuery();
					while (resultSet.next()) {
						txt_Login.setText(resultSet.getString("LOGIN_URL"));
					    txt_Uname.setText(resultSet.getString("USER_NAME"));
						txt_Pwd.setText(resultSet.getString("PASSWORD"));
						txt_DBUname.setText(resultSet.getString("USER_NAME"));
						txt_DBPwd.setText(resultSet.getString("PASSWORD"));
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		cBox_Env.setBounds(426, 129, 255, 30);
		contentPane.add(cBox_Env);

		JLabel lblLoginUrlFor = new JLabel("LOGIN URL for application");
		lblLoginUrlFor.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblLoginUrlFor.setForeground(new Color(105, 105, 105));
		lblLoginUrlFor.setBounds(205, 198, 291, 30);
		contentPane.add(lblLoginUrlFor);

		JLabel lblValidUsernameFor = new JLabel("Username for entering in to the application");
		lblValidUsernameFor.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblValidUsernameFor.setForeground(new Color(105, 105, 105));
		lblValidUsernameFor.setBounds(205, 248, 317, 30);
		contentPane.add(lblValidUsernameFor);

		JLabel lblValidPasswordFor = new JLabel("Password for entering in to the application");
		lblValidPasswordFor.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblValidPasswordFor.setForeground(new Color(105, 105, 105));
		lblValidPasswordFor.setBounds(205, 298, 308, 30);
		contentPane.add(lblValidPasswordFor);

		JLabel lblUsernameForAccessing = new JLabel("Username for accessing application Database");
		lblUsernameForAccessing.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblUsernameForAccessing.setForeground(new Color(105, 105, 105));
		lblUsernameForAccessing.setBounds(205, 348, 291, 30);
		contentPane.add(lblUsernameForAccessing);

		JLabel lblPasswordForAccessing = new JLabel("Password for accessing application Database");
		lblPasswordForAccessing.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblPasswordForAccessing.setForeground(new Color(105, 105, 105));
		lblPasswordForAccessing.setBounds(205, 397, 291, 30);
		contentPane.add(lblPasswordForAccessing);

		txt_Login = new JTextField();
		txt_Login.setColumns(10);
		txt_Login.setBounds(532, 198, 220, 30);
		contentPane.add(txt_Login);

		txt_Uname = new JTextField();
		txt_Uname.setColumns(10);
		txt_Uname.setBounds(532, 248, 220, 30);
		contentPane.add(txt_Uname);

		txt_DBUname = new JTextField();
		txt_DBUname.setBounds(532, 348, 220, 30);
		contentPane.add(txt_DBUname);


		final JLabel btnNewButton = new JLabel("SAVE");
		btnNewButton.setHorizontalAlignment(SwingConstants.CENTER);
		btnNewButton.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
		btnNewButton.setOpaque(true);
		btnNewButton.setBackground(Color.BLACK);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e)
			{btnNewButton.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{btnNewButton.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{btnNewButton.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {btnNewButton.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent e) {
				int action = JOptionPane.showConfirmDialog(null, "Are you sure want to save environment details", "Confirm",JOptionPane.YES_NO_OPTION );
				if(action ==0){
					saveRecords();
				}
			}
		});
		btnNewButton.setBounds(834, 506, 100, 30);
		contentPane.add(btnNewButton);

		JLabel btnRESET = new JLabel();
		btnRESET.setHorizontalAlignment(SwingConstants.CENTER);
		btnRESET.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "icon_refresh.png")));
		btnRESET.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				int action = JOptionPane.showConfirmDialog(null, "Are you sure want to clear", "Confirm",JOptionPane.YES_NO_OPTION );
				if(action ==0){
				 txt_Login.setText("");
				 txt_Uname.setText("");
				 txt_Pwd.setText("");
				 txt_DBUname.setText("");
				 txt_DBPwd.setText("");
			}else {
				System.out.println("Nothing");
			}
		 }
		});
		btnRESET.setBounds(919, 30, 35, 30);
		contentPane.add(btnRESET);

		txt_Pwd = new JTextField();
		txt_Pwd.setColumns(10);
		txt_Pwd.setBounds(532, 298, 220, 30);
		contentPane.add(txt_Pwd);

		txt_DBPwd = new JTextField();
		txt_DBPwd.setColumns(10);
		txt_DBPwd.setBounds(532, 398, 220, 30);
		contentPane.add(txt_DBPwd);

		label_1 = new JLabel("");
		label_1.setOpaque(true);
		label_1.setBackground(Color.BLACK);
		label_1.setBounds(0, 557, 954, 15);
		contentPane.add(label_1);

		JLabel lblBack = new JLabel();
		lblBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				try {
					connection.close();
					dispose();
					UI_Frame_Dashboard objdshbrd = new UI_Frame_Dashboard();
					objdshbrd.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		lblBack.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "icon_back.png")));
		lblBack.setBounds(0, 0, 40, 30);
		lblBack.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblBack);

		JLabel lblApplication = new JLabel("APPLICATION");
		lblApplication.setForeground(new Color(255, 140, 0));
		lblApplication.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
		lblApplication.setBounds(267, 88, 106, 30);
		contentPane.add(lblApplication);

		cBox_App = new JComboBox<String>();
		cBox_App.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fill_Env();
			}
		});
		cBox_App.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		cBox_App.setBounds(426, 88, 255, 30);
		contentPane.add(cBox_App);
		Fill_App();

		JLabel lblManageEnvironmentCredentials = new JLabel("MANAGE ENVIRONMENT CREDENTIALS");
		lblManageEnvironmentCredentials.setOpaque(true);
		lblManageEnvironmentCredentials.setHorizontalAlignment(SwingConstants.CENTER);
		lblManageEnvironmentCredentials.setForeground(Color.WHITE);
		lblManageEnvironmentCredentials.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblManageEnvironmentCredentials.setBackground(Color.BLACK);
		lblManageEnvironmentCredentials.setBounds(0, 0, 968, 30);
		contentPane.add(lblManageEnvironmentCredentials);

		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "white1.jpg")));
		label_3.setBounds(0, 0, 968, 562);
		contentPane.add(label_3);
	}

	public void saveRecords()
	{
		try{
			String query0 = "Update ENV set LOGIN_URL =?, USER_NAME =?, PASSWORD =?, DB_USERNAME =?, DB_PASSWORD =? Where TEST_ENVIRONMENT = '"+cBox_Env.getSelectedItem()+"' and APPLICATION = '"+cBox_App.getSelectedItem() + "'";
			PreparedStatement statement = connection.prepareStatement(query0);
			statement.setString(1, txt_Login.getText());
			statement.setString(2, txt_Uname.getText());
			statement.setString(3, txt_Pwd.getText());
			statement.setString(4, txt_DBUname.getText());
			statement.setString(5, txt_DBPwd.getText());
			statement.execute();
			JOptionPane.showMessageDialog(null, "Updated Successfully.");
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}//Method
}

