package com.optum.coliseum.frame;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import net.proteanit.sql.DbUtils;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;

import java.awt.Toolkit;
import javax.swing.event.ChangeListener;

import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.Settings;

import javax.swing.event.ChangeEvent;
import javax.swing.ImageIcon;
import javax.swing.border.SoftBevelBorder;

public class UI_Dialog_AddNewObjectToOR extends JDialog {

	private static final long serialVersionUID = 1L;
	JTextField txt_NewObjRefName;
	JTextField txt_UseXPath;
	JCheckBox ChkBx_UseXPath;
	JCheckBox ChkBx_UseOWTable;
	JTable table_OW;
	String sObjRefForReturn = null;
	private JComboBox<String> cBox_TagTypes;
	private static String sTitle = "";
	private static String sID = "";
	private static String sName = "";
	private static String sLText = "";
	private static String sXpath = "";
	private boolean isObjAttNull = true;
	static Connection connection;
	private JTextField textField;

	public static void main(String[] args) {
		try {
			connection = com.optum.coliseum.generic.DBUtils.DBConnect_Automation();
			String sAUT = Settings.getSetting("AUT", connection);
			UI_Dialog_AddNewObjectToOR dialog = new UI_Dialog_AddNewObjectToOR(sAUT, connection);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void UI_Dialog_AddNewObjectToOR_Handle(String sAUT, Connection connection) {
		try {
			UI_Dialog_AddNewObjectToOR dialog = new UI_Dialog_AddNewObjectToOR(sAUT, connection);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public UI_Dialog_AddNewObjectToOR(final String sAUT, final Connection connection) {
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				JOptionPane.showMessageDialog(null, "CLICKED ");
			}
		});

		try {
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}

		setTitle("COLISEUM - Add new Object");

		setIconImage(Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Dlogo.jpg")));

		getContentPane().setBackground(Color.WHITE);
		setResizable(false);
		setBounds(100, 100, 660, 500);
		setLocationRelativeTo(null);
		getContentPane().setLayout(null);

		JLabel lbl_NewObjRefName = new JLabel("Enter a new Object Reference Name : ");
		lbl_NewObjRefName.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		lbl_NewObjRefName.setBounds(24, 44, 236, 30);
		getContentPane().add(lbl_NewObjRefName);

		JLabel label = new JLabel("");
		label.setOpaque(true);
		label.setBackground(Color.LIGHT_GRAY);
		label.setBounds(0, 89, 654, 4);
		getContentPane().add(label);

		JLabel lbl_HeaderAddNewObject = new JLabel("ADD NEW OBJECT TO REPOSITORY");
		lbl_HeaderAddNewObject.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_HeaderAddNewObject.setForeground(Color.WHITE);
		lbl_HeaderAddNewObject.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 13));
		lbl_HeaderAddNewObject.setOpaque(true);
		lbl_HeaderAddNewObject.setBackground(Color.BLACK);
		lbl_HeaderAddNewObject.setBounds(0, 0, 654, 30);
		getContentPane().add(lbl_HeaderAddNewObject);

		JLabel lbl_FooterAddNewObject = new JLabel("");
		lbl_FooterAddNewObject.setOpaque(true);
		lbl_FooterAddNewObject.setBackground(Color.BLACK);
		lbl_FooterAddNewObject.setBounds(0, 462, 654, 10);
		getContentPane().add(lbl_FooterAddNewObject);

		txt_NewObjRefName = new JTextField();
		txt_NewObjRefName.setFont(new Font("Trebuchet MS", Font.PLAIN, 11));
		txt_NewObjRefName.setBounds(270, 45, 207, 30);
		getContentPane().add(txt_NewObjRefName);

		txt_UseXPath = new JTextField();
		txt_UseXPath.setFont(new Font("Trebuchet MS", Font.PLAIN, 11));
		txt_UseXPath.setBounds(270, 107, 349, 30);
		txt_UseXPath.setEnabled(false);
		getContentPane().add(txt_UseXPath);

		cBox_TagTypes = new JComboBox<String>();
		cBox_TagTypes.setBounds(487, 44, 132, 33);
		getContentPane().add(cBox_TagTypes);
		FillJComboBox_Keywords(connection);

		JScrollPane scrollPane_OW = new JScrollPane();
		scrollPane_OW.setBounds(24, 188, 605, 233);
		getContentPane().add(scrollPane_OW);
		table_OW = new JTable();
		table_OW.setColumnSelectionAllowed(false);
		table_OW.setDefaultEditor(Object.class, null);
		try{
			 Statement st08 = connection.createStatement();
			 ResultSet rs08 = st08.executeQuery("SELECT TITLE, ID, NAME, LINKTEXT FROM OBJ_WH where application = 'C4'");
			 System.out.println("KUMAR "+ "SELECT TITLE, ID, NAME, LINKTEXT FROM OBJ_WH where application = ''");
			 table_OW.setModel(DbUtils.resultSetToTableModel(rs08));
		}
		catch(Exception etc){
			 etc.printStackTrace();
		}
		scrollPane_OW.setViewportView(table_OW);

		ChkBx_UseOWTable = new JCheckBox("   Use the object definitions from the below collection");
		ChkBx_UseOWTable.setOpaque(false);
		ChkBx_UseOWTable.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		ChkBx_UseOWTable.setBounds(62, 144, 548, 23);
		getContentPane().add(ChkBx_UseOWTable);

		ChkBx_UseXPath = new JCheckBox("   Use X-Path");
		ChkBx_UseXPath.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				if (ChkBx_UseXPath.isSelected()){
					txt_UseXPath.setEnabled(true);
				}
				else {
					txt_UseXPath.setEnabled(false);
					txt_UseXPath.setText("");
				}
			}
		});
		ChkBx_UseXPath.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		ChkBx_UseXPath.setOpaque(false);
		ChkBx_UseXPath.setBounds(62, 111, 176, 23);
		getContentPane().add(ChkBx_UseXPath);

		final JLabel lbl_SaveORAdd = new JLabel("ADD");
		lbl_SaveORAdd.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e)
			{lbl_SaveORAdd.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{lbl_SaveORAdd.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{lbl_SaveORAdd.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {lbl_SaveORAdd.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent arg0) {
				if (!isMandatoryValuesAbsent()){
					if (isObjInit(sAUT)){
						try {
							if (!isObjrefDuplicate(sAUT, connection)) {
								if (!isObjRecDuplicate(sAUT, connection)) sObjRefForReturn = insertNewOR(sAUT, connection);
								else Msgbox.msgbox("Object Definition already exists in Repository!");
							}
							else Msgbox.msgbox("Duplicate OBJ_REF!");
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
		});
		lbl_SaveORAdd.setOpaque(true);
		lbl_SaveORAdd.setForeground(Color.WHITE);
		lbl_SaveORAdd.setBackground(Color.BLACK);
		lbl_SaveORAdd.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_SaveORAdd.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 13));
		lbl_SaveORAdd.setBounds(546, 428, 83, 23);
		getContentPane().add(lbl_SaveORAdd);

		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(24, 429, 168, 22);
		getContentPane().add(textField);

		final JLabel lblSearch = new JLabel("Search");
		lblSearch.setHorizontalAlignment(SwingConstants.CENTER);
		lblSearch.setForeground(Color.BLACK);
		lblSearch.setFont(new Font("Segoe UI", Font.ITALIC, 12));
		lblSearch.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		lblSearch.setBounds(202, 430, 49, 21);
		lblSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DisplaySearchResults();
			}
			public void mousePressed(MouseEvent arg0)
			{lblSearch.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {lblSearch.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));}
			public void mouseEntered(MouseEvent arg0)
			{lblSearch.setBorder(new LineBorder(Color.BLUE, 2));}
			public void mouseExited(MouseEvent arg0)
			{lblSearch.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));}
		});
		getContentPane().add(lblSearch);

		JLabel lbl_BGNewOR = new JLabel("");
		lbl_BGNewOR.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "white1.jpg")));

		lbl_BGNewOR.setBounds(0, 89, 654, 383);
		getContentPane().add(lbl_BGNewOR);
	}

	public boolean isMandatoryValuesAbsent(){
		boolean isFailure = true;

		if (txt_NewObjRefName.getText().toString().equals("")){
			Msgbox.msgbox("Please enter Object Reference Name!");
		}
		else if (!ChkBx_UseXPath.isSelected() && !ChkBx_UseOWTable.isSelected()){
			Msgbox.msgbox("Please select at least one check box!");
		}
		else if (ChkBx_UseXPath.isSelected() && txt_UseXPath.getText().toString().equals("")){
			Msgbox.msgbox("Please enter XPath or uncheck the corresponding check box!");
		}
		else if (ChkBx_UseOWTable.isSelected() && table_OW.getSelectedRow()<0){
			Msgbox.msgbox("Please select a row from Table or uncheck the corresponding check box!");
		}
		else if (cBox_TagTypes.getSelectedIndex()==0){
			Msgbox.msgbox("Please select Action type that this object will be associated to!");
		}
		else isFailure = false;
		return isFailure;
	}


	public String insertNewOR(String sAUT, Connection connection) throws Exception{

		String sKeyword = (String)cBox_TagTypes.getSelectedItem();
		String xpath = txt_UseXPath.getText(); String objRef = txt_NewObjRefName.getText();
		//BHARATH --> HANDLING  quote's while adding OBJECTS
		if (xpath.contains("'")) xpath =xpath.replaceAll("'", "''");


		if (objRef.contains("'")) objRef =objRef.replaceAll("'", "''");

		String sSQL = "insert into OBJ_REP(OBJ_REF, title, id, name, linkText, xpath, TAG_TYPE, Application) values ('"+
						objRef + "','" +
						sTitle 						+ "','" +
						sID 						+ "','" +
						sName 						+ "','" +
						sLText 					+ "','" +
						xpath		+ "','" +
						sKeyword 					+ "','" +
						sAUT 						+ "')";
				connection.createStatement().executeUpdate(sSQL);
				Msgbox.msgbox("New OR record inserted successfully");
				ResetNewORUI();
		return txt_NewObjRefName.getText();
	}

	public void ResetNewORUI(){
		txt_NewObjRefName.setText("");
		txt_UseXPath.setText("");
		ChkBx_UseOWTable.setSelected(false);
		ChkBx_UseXPath.setSelected(false);
		table_OW.clearSelection();
	}

	public void FillJComboBox_Keywords(Connection connection)
	{
		try{
			ResultSet rs = connection.prepareStatement("Select DISTINCT KEYWORD from KEYWORDS where KW_TYPE_ID= 1 order by KEYWORD").executeQuery();
			cBox_TagTypes.addItem("--Select Keyword--");
			while(rs.next()){
				cBox_TagTypes.addItem(rs.getString("KEYWORD"));
			}
			rs.close();
		} catch (SQLException e) {System.out.println("################## FAILURE! FillJComboBox_Keywords failed!");}
	}

	public boolean isObjrefDuplicate(String sAUT, Connection connection){

		boolean b = false;String text_OBJREF;
			try {
				//Bharath --> Handling Quotes
				text_OBJREF= txt_NewObjRefName.getText(); if(text_OBJREF.contains("'"))text_OBJREF=text_OBJREF.replaceAll("'", "''");
				ResultSet rs = connection.prepareStatement("Select OBJ_REF from OBJ_REP where OBJ_REF = '"+text_OBJREF+"' and application = '"+sAUT+"'").executeQuery();
				if (rs.next()){b = true;}
				rs.close();
			} catch (SQLException e) {e.printStackTrace();}

		return b;
	}

	public boolean isObjRecDuplicate (String sAUT, Connection connection){

		String  sSQL;
		boolean b = false;

		if (ChkBx_UseOWTable.isSelected()){
			sSQL = "Select OBJ_REF from OBJ_REP where (id = '"+sID+"' and name = '"+ sName + "' and linkText = '"+ sLText +"') and application = '"+sAUT+"'";
			System.out.println(sSQL);
			try {
				ResultSet rs = connection.createStatement().executeQuery(sSQL);
				if (rs.next()){b = true;}
				rs.close();
			} catch (SQLException e) {e.printStackTrace();}
		}

		if (ChkBx_UseXPath.isSelected()){
				if(sXpath.contains("'" )) sXpath=sXpath.replaceAll("'", "''");
				sSQL = "Select OBJ_REF from OBJ_REP where xPath = '"+sXpath+"' and application = '"+sAUT+"'";
				try {
					ResultSet rs1 = connection.createStatement().executeQuery(sSQL);
					if (rs1.next()){b = true;}
					rs1.close();
				} catch (SQLException e) {e.printStackTrace();}
		}

		System.out.println("isObjRecDuplicate returns : "+b);
		return b;
	}

	public boolean isObjInit(String sAUT){
		isObjAttNull = false; boolean b= true; sTitle = ""; sID = ""; sName = ""; sLText = ""; sXpath = "";

		if (ChkBx_UseOWTable.isSelected()){
			int irow = table_OW.getSelectedRow();
			if (!(irow < 1)){
				if (!(table_OW.getModel().getValueAt(irow, 0) == null)) sTitle 	= (table_OW.getModel().getValueAt(irow, 0)).toString();
				if (!(table_OW.getModel().getValueAt(irow, 1) == null))	sID   	= (table_OW.getModel().getValueAt(irow, 1)).toString();
				if (!(table_OW.getModel().getValueAt(irow, 2) == null)) sName  	= (table_OW.getModel().getValueAt(irow, 2)).toString();
				if (!(table_OW.getModel().getValueAt(irow, 3) == null)) sLText 	= (table_OW.getModel().getValueAt(irow, 3)).toString();
			}
		}

		if (ChkBx_UseXPath.isSelected()) sXpath = txt_UseXPath.getText();

		if ((sTitle.equals("") 	|| sTitle.equals("null")) 	&&
			(sID.equals("") 	|| sID.equals("null")	) 	&&
			(sName.equals("") 	|| sName.equals("null")	)	&&
			(sLText.equals("") 	|| sLText.equals("null"))	){
			isObjAttNull = true;
		}

		if (isObjAttNull && sXpath.equals("")){
			b = false;
			Msgbox.msgbox("This is a bad object. Please select another row or enter XPath!");
		}

		if (!txt_NewObjRefName.getText().startsWith(sAUT+"_")){
			b = false;
			Msgbox.msgbox("Incorrect OBJ_REF format. Please use Application name followed by unnderscore and then object name.");
		}

		System.out.println("isObjAttNull returns : "+ isObjAttNull);
		System.out.println("isObjValidForInsert returns : "+ b);

		return b;
	}

	public void DisplaySearchResults()
	{
		try {
			String query = "select TITLE,ID, NAME,LINKTEXT  from OBJ_WH where Application = '"+Settings.getSetting("AUT", connection)+"' and ("
					+ "Title like  '%"+textField.getText()+"%' OR "
					+ "ID like  '%"+textField.getText()+"%' OR "
					+ "Name like  '%"+textField.getText()+"%' OR "
					+ "LinkText like  '%"+textField.getText()+"%')"
					+ "order by TAG_TYPE" ;
			ResultSet rs = connection.prepareStatement(query).executeQuery();
            table_OW.setModel(DbUtils.resultSetToTableModel(rs));

            System.out.println("BHARATH "+query);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}