package com.optum.coliseum.frame;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

import com.optum.coliseum.generic.Constants;

public class SubFrame_AddStep extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SubFrame_AddStep frame = new SubFrame_AddStep();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SubFrame_AddStep() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 680, 393);
		contentPane = new JPanel();


		setLocationRelativeTo(null);
		getContentPane().setLayout(null);
		setLocationRelativeTo(null);
		setIconImage(Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Dlogo.jpg")));

		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		scrollPane.setBounds(20, 34, 602, 249);
		contentPane.add(scrollPane);

		table = new JTable();
		scrollPane.setColumnHeaderView(table);

		final JLabel lbl_Add = new JLabel("");
		lbl_Add.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		lbl_Add.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Add.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_Add.png")));

		lbl_Add.setBounds(630, 64, 29, 29);
		getContentPane().add(lbl_Add);

		JLabel label_Update = new JLabel("");
		label_Update.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			/*	String query1 = "UPDATE OBJ_REP set ID='"+replaceQuote(objId)+"', NAME ='"+replaceQuote(objName)+"', LINKTEXT = '"+replaceQuote(objLinkText)+"', "
						+ "TAG_TYPE ='"+replaceQuote(objTagType)+"' , XPATH ='"+replaceQuote(objXpath)+"', TITLE ='"+replaceQuote(objTitle)+"' where OBJ_REF ='"+replaceQuote(objRef)+"' "
								+ "and application = '"+Settings.getSetting("AUT", connection)+"'";
				System.out.println(query1);
				PreparedStatement pst1  = connection.prepareStatement(query1);
				pst1.executeUpdate();*/
				Msgbox.msgbox("Obj Ref Updated successfully");
			}
		});
		label_Update.setHorizontalAlignment(SwingConstants.CENTER);
		label_Update.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		label_Update.setBounds(632, 104, 29, 29);

		contentPane.add(label_Update);
	}
}
