package com.optum.coliseum.frame;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Desktop;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.border.LineBorder;
import javax.swing.SwingConstants;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.jdbc.JDBCCategoryDataset;

import com.optum.coliseum.driver.DriverLib;
import com.optum.coliseum.driver.OWOR;
import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.DBUtils;
import com.optum.coliseum.generic.Settings;

import javax.swing.border.BevelBorder;
import javax.swing.UIManager;
import javax.swing.JTextField;

import java.awt.Toolkit;
import java.awt.SystemColor;

public class UI_Frame_Dashboard extends JFrame {

		private static final long serialVersionUID = 1L;
		Connection connection =null;
		public Font fontStyle =new Font("Microsoft Sans Serif", Font.PLAIN, 14);
		public Color fontBackground =new Color(105, 105, 105);
		public Color fontBackground_Color =Color.WHITE;
		public Color background_Color =new Color(255, 255, 255);
		public Color MouseEntered_foregroundColor =new Color(255, 165, 0);
		public LineBorder lineBorderColor =new LineBorder(new Color(192, 192, 192));
		public JLabel lbl_ScheduleTests;
		private JPanel contentPane;
		private JTextField txtWelcome;
			/**
			 * Launch the application.
			 */
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						UI_Frame_Dashboard frame = new UI_Frame_Dashboard();
						frame.setVisible(true);
					} catch (Exception e){
						e.printStackTrace();
					}
				}});
			}
		public UI_Frame_Dashboard()  {

			try {
			    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			} catch (Exception e) {
			    e.printStackTrace();
			}

			connection = DBUtils.DBConnect_Automation();
			setTitle("COLESIUM");
			setIconImage(Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Dlogo.jpg")));

			setResizable(false);
				try	{
					UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel	");
				} catch(Exception e){}

			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			setBounds(0, 0, 955, 596);
			setLocationRelativeTo(null);
			contentPane = new JPanel();
			contentPane.setBackground(fontBackground_Color);
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			contentPane.setLayout(null);

			final JLabel lblDevelopeTestCase = new JLabel("Develop Test cases");
			lblDevelopeTestCase.setOpaque(true);
			lblDevelopeTestCase.setBorder(lineBorderColor);
			lblDevelopeTestCase.setBackground(background_Color);
			lblDevelopeTestCase.setHorizontalAlignment(SwingConstants.CENTER);
			lblDevelopeTestCase.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e)
					{lblDevelopeTestCase.setBackground(MouseEntered_foregroundColor);lblDevelopeTestCase.setForeground(fontBackground_Color);}
				public void mouseExited(MouseEvent e)
					{lblDevelopeTestCase.setBackground(fontBackground_Color);lblDevelopeTestCase.setForeground(fontBackground);}
				public void mousePressed(MouseEvent arg0)
					{lblDevelopeTestCase.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
				public void mouseReleased(MouseEvent arg0)
					{lblDevelopeTestCase.setBorder(lineBorderColor);}
				public void mouseClicked(MouseEvent e) {
						Close();
						UI_Frame_AddTestStep.main(null);
				}});

			JLabel lbl_logout = new JLabel("");
			lbl_logout.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
						int action = JOptionPane.showConfirmDialog(null, "Do you really want to Logoff?", "Confirm",JOptionPane.YES_NO_OPTION );
						if(action ==0){
							Close();
							UI_Frame_Login.main(null);
						}
				}
			});
			lbl_logout.setToolTipText("Logout");
			lbl_logout.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_logout1.png")));

			lbl_logout.setBounds(913, 3, 26, 25);
			contentPane.add(lbl_logout);

			lblDevelopeTestCase.setForeground(Color.DARK_GRAY);
			lblDevelopeTestCase.setFont(fontStyle);
			lblDevelopeTestCase.setBounds(360, 135, 215, 30);
			contentPane.add(lblDevelopeTestCase);

			JLabel label = new JLabel((Settings.getSetting("AUT", connection)));
			label.setForeground(Color.DARK_GRAY);
			label.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
			label.setBounds(670, 400, 75, 30);
			contentPane.add(label);

			JLabel label_4 = new JLabel((Settings.getSetting("ENVIRONMENT", connection)));
			label_4.setForeground(Color.DARK_GRAY);
			label_4.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
			label_4.setBounds(787, 400, 68, 30);
			contentPane.add(label_4);

			JLabel lblTestScheduling = new JLabel("    TEST SCHEDULING");
			lblTestScheduling.setHorizontalAlignment(SwingConstants.CENTER);
			lblTestScheduling.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_CheckBox.png")));
			lblTestScheduling.setOpaque(true);
			lblTestScheduling.setForeground(background_Color);
			lblTestScheduling.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
			lblTestScheduling.setBackground(new Color(128, 128, 128));
			lblTestScheduling.setBounds(66, 82, 250, 38);
			contentPane.add(lblTestScheduling);

			final JLabel lblLaunchRegression = new JLabel("");
			lblLaunchRegression.setHorizontalAlignment(SwingConstants.CENTER);
			lblLaunchRegression.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Button.png")));
			lblLaunchRegression.setBounds(632, 430, 75, 70);
			lblLaunchRegression.addMouseListener(new MouseAdapter() {
				@Override
				public void mousePressed(MouseEvent arg0)
					{lblLaunchRegression.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "buttong.png")));}
				public void mouseClicked(MouseEvent e) {
					int action = JOptionPane.showConfirmDialog(null, "Are you sure you want to proceed with the Regression execution", "Confirm",JOptionPane.YES_NO_OPTION );
						if(action ==0){
								try {
									connection.close();
									DriverLib driver = new DriverLib();
									driver.Drive_REGR(1,null,null);
									lblLaunchRegression.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Button.png")));
									connection = DBUtils.DBConnect_Automation();
								} catch (Exception e1) {
									e1.printStackTrace();
								}}
						else {
							System.out.println("Nothing");
							lblLaunchRegression.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Button.png")));
						}
						}});
					contentPane.add(lblLaunchRegression);

				final JLabel lblLaunchSmoke = new JLabel("");
				lblLaunchSmoke.setHorizontalAlignment(SwingConstants.CENTER);
				lblLaunchSmoke.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Button.png")));
				lblLaunchSmoke.setBounds(712, 430, 75, 70);
				lblLaunchSmoke.addMouseListener(new MouseAdapter() {
					@Override
					public void mousePressed(MouseEvent arg0)
						{lblLaunchSmoke.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "buttong.png")));}
					public void mouseClicked(MouseEvent e) {
						int action = JOptionPane.showConfirmDialog(null, "Are you sure you want to proceed with the Smoke execution", "Confirm",JOptionPane.YES_NO_OPTION );
							if(action ==0){
								try {
									connection.close();

									DriverLib Smoke = new DriverLib();
									Smoke.Drive_REGR(2, null, null);
									lblLaunchSmoke.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Button.png")));

									OWOR owToOR = new OWOR();
									owToOR.actionPerform();
									lblLaunchSmoke.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Button.png")));

									connection = DBUtils.DBConnect_Automation();
									Statement st11=connection.createStatement();
									st11.executeQuery("update OBJ_WH set NAME = NULL where NAME = ''");
									st11.executeQuery("update OBJ_WH set NAME = NULL where ID= ''");
									st11.executeQuery("update OBJ_WH set NAME = NULL where LINKTEXT= ''");
									st11.executeQuery("update OBJ_WH set NAME = NULL where TITLE= ''");
									System.out.println("Exeuted string comparison");

								} catch (Exception e1) {
									e1.printStackTrace();
								}}
							else {
								System.out.println("Nothing");
								lblLaunchSmoke.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Button.png")));
							}
							}});
								contentPane.add(lblLaunchSmoke);

				final JLabel lblLaunchSanity = new JLabel("");
				lblLaunchSanity.setHorizontalAlignment(SwingConstants.CENTER);
				lblLaunchSanity.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Button.png")));
				lblLaunchSanity.setBounds(792, 430, 75, 70);
				lblLaunchSanity.addMouseListener(new MouseAdapter() {
					@Override
					public void mousePressed(MouseEvent arg0)
					{lblLaunchSanity.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "buttong.png")));}
					public void mouseClicked(MouseEvent e) {
						int action = JOptionPane.showConfirmDialog(null, "Are you sure you want to proceed with the Build Verify execution", "Confirm",JOptionPane.YES_NO_OPTION );
							if(action ==0){
								try {
									DriverLib Sniff = new DriverLib();
									Sniff.Drive_REGR(4, null, null);
									lblLaunchSmoke.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Button.png")));
								} catch (Exception e1) {
									e1.printStackTrace();
								}}
							else {
								lblLaunchSanity.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Button.png")));
							}
							}});
				contentPane.add(lblLaunchSanity);

				lbl_ScheduleTests = new JLabel("Schedule Tests");
				lbl_ScheduleTests.setBorder(lineBorderColor);
				lbl_ScheduleTests.setHorizontalAlignment(SwingConstants.CENTER);
				lbl_ScheduleTests.setBackground(background_Color);
				lbl_ScheduleTests.setOpaque(true);
				lbl_ScheduleTests.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e)
					{lbl_ScheduleTests.setBackground(MouseEntered_foregroundColor);lbl_ScheduleTests.setForeground(fontBackground_Color);}
				public void mouseExited(MouseEvent e)
					{lbl_ScheduleTests.setBackground(fontBackground_Color);lbl_ScheduleTests.setForeground(fontBackground);}
				public void mousePressed(MouseEvent arg0)
					{lbl_ScheduleTests.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
				public void mouseReleased(MouseEvent arg0)
					{lbl_ScheduleTests.setBorder(lineBorderColor);}
				public void mouseClicked(MouseEvent e){
						Close();
						UI_Frame_Schedule_TestCase.main(null);
				}});
				lbl_ScheduleTests.setForeground(Color.DARK_GRAY);
				lbl_ScheduleTests.setFont(fontStyle);
				lbl_ScheduleTests.setBounds(83, 210, 215, 30);
				contentPane.add(lbl_ScheduleTests);

				final JLabel lblUpdateTestSettings = new JLabel("Update Test Settings");
				lblUpdateTestSettings.setHorizontalAlignment(SwingConstants.CENTER);
				lblUpdateTestSettings.setBorder(lineBorderColor);
				lblUpdateTestSettings.setOpaque(true);
				lblUpdateTestSettings.setBackground(background_Color);
				lblUpdateTestSettings.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e)
					{lblUpdateTestSettings.setBackground(MouseEntered_foregroundColor);lblUpdateTestSettings.setForeground(fontBackground_Color);}
				public void mouseExited(MouseEvent e)
					{lblUpdateTestSettings.setBackground(fontBackground_Color);lblUpdateTestSettings.setForeground(fontBackground);}
				public void mousePressed(MouseEvent arg0)
					{lblUpdateTestSettings.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
				public void mouseReleased(MouseEvent arg0)
					{lblUpdateTestSettings.setBorder(lineBorderColor);}
				public void mouseClicked(MouseEvent e) {
					try {
						Close();
						UI_Frame_Update_TestSettings.main(null);
					} catch (Exception e1) {
						e1.printStackTrace();
				}}});
				lblUpdateTestSettings.setForeground(Color.DARK_GRAY);
				lblUpdateTestSettings.setFont(fontStyle);
				lblUpdateTestSettings.setBounds(83, 135, 215, 30);
				contentPane.add(lblUpdateTestSettings);

				final JLabel lbl_UpdateTestEnv = new JLabel("Update Environments");
				lbl_UpdateTestEnv.setBorder(lineBorderColor);
				lbl_UpdateTestEnv.setBackground(background_Color);
				lbl_UpdateTestEnv.setOpaque(true);
				lbl_UpdateTestEnv.setHorizontalAlignment(SwingConstants.CENTER);
				lbl_UpdateTestEnv.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e)
					{lbl_UpdateTestEnv.setBackground(MouseEntered_foregroundColor);lbl_UpdateTestEnv.setForeground(fontBackground_Color);}
				public void mouseExited(MouseEvent e)
					{lbl_UpdateTestEnv.setBackground(fontBackground_Color);lbl_UpdateTestEnv.setForeground(fontBackground);}
				public void mousePressed(MouseEvent arg0)
					{lbl_UpdateTestEnv.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
				public void mouseReleased(MouseEvent arg0)
					{lbl_UpdateTestEnv.setBorder(lineBorderColor);}
				public void mouseClicked(MouseEvent e) {
						Close();
						UI_Frame_UpdateENV.main(null);
					}});
				lbl_UpdateTestEnv.setForeground(Color.DARK_GRAY);
				lbl_UpdateTestEnv.setFont(fontStyle);
				lbl_UpdateTestEnv.setBounds(83, 173, 215, 30);
				contentPane.add(lbl_UpdateTestEnv);

				JLabel lblDashborad = new JLabel("DASHBOARD");
				lblDashborad.setHorizontalAlignment(SwingConstants.CENTER);
				lblDashborad.setOpaque(true);
				lblDashborad.setBackground(new Color(0, 0, 0));
				lblDashborad.setForeground(background_Color);
				lblDashborad.setFont(new Font("Calibri", Font.PLAIN, 18));
				lblDashborad.setBounds(0, 0, 954, 30);
				contentPane.add(lblDashborad);

				JLabel lblTestDevelopment = new JLabel(" TEST DEVELOPMENT");
				lblTestDevelopment.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_Development.png")));
				lblTestDevelopment.setOpaque(true);
				lblTestDevelopment.setHorizontalAlignment(SwingConstants.CENTER);
				lblTestDevelopment.setForeground(fontBackground_Color);
				lblTestDevelopment.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
				lblTestDevelopment.setBackground(new Color(128, 128, 128));
				lblTestDevelopment.setBounds(340, 82, 250, 38);
				contentPane.add(lblTestDevelopment);

				JLabel lblUpdateTestCase = new JLabel("Develop Templates");
				lblUpdateTestCase.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent arg0) {
						Close();
						UI_Frame_AddTestStep.main(null);
					}});

				lblUpdateTestCase.setBorder(lineBorderColor);
				lblUpdateTestCase.setHorizontalAlignment(SwingConstants.CENTER);
				lblUpdateTestCase.setOpaque(true);
				lblUpdateTestCase.setBackground(background_Color);
				lblUpdateTestCase.setForeground(Color.DARK_GRAY);
				lblUpdateTestCase.setFont(fontStyle);
				lblUpdateTestCase.setBounds(360, 173, 215, 30);
				contentPane.add(lblUpdateTestCase);

				JLabel lblTestManagement = new JLabel("  TEST MANAGEMENT");
				lblTestManagement.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_MGMT.png")));
				lblTestManagement.setOpaque(true);
				lblTestManagement.setHorizontalAlignment(SwingConstants.CENTER);
				lblTestManagement.setForeground(fontBackground_Color);
				lblTestManagement.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
				lblTestManagement.setBackground(Color.GRAY);
				lblTestManagement.setBounds(66, 307, 250, 38);
				contentPane.add(lblTestManagement);

				JLabel lblUserActions = new JLabel("      USER ACTIONS");
				lblUserActions.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_Users.png")));
				lblUserActions.setOpaque(true);
				lblUserActions.setHorizontalAlignment(SwingConstants.CENTER);
				lblUserActions.setForeground(fontBackground_Color);
				lblUserActions.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
				lblUserActions.setBackground(Color.GRAY);
				lblUserActions.setBounds(340, 307, 250, 38);
				contentPane.add(lblUserActions);

				JLabel lblLastTestWas = new JLabel("");
				lblLastTestWas.setFont(new Font("Trebuchet MS", Font.ITALIC, 11));
				lblLastTestWas.setBounds(606, 41, 233, 14);
				contentPane.add(lblLastTestWas);
				lblLastTestWas.setText("Last Test was executed on :"+Settings.getSetting("LAST_REGTEST_DATE", connection));

				JLabel lblPassPercentageWas = new JLabel("");
				lblPassPercentageWas.setFont(new Font("Trebuchet MS", Font.ITALIC, 11));
				lblPassPercentageWas.setBounds(606, 57, 160, 14);
				contentPane.add(lblPassPercentageWas);
				lblPassPercentageWas.setText("Pass percentage was :"+Settings.getSetting("LAST_PASS_PERC", connection));

				JLabel lblLauncher = new JLabel("LAUNCH PAD");
				lblLauncher.setOpaque(true);
				lblLauncher.setHorizontalAlignment(SwingConstants.CENTER);
				lblLauncher.setForeground(fontBackground_Color);
				lblLauncher.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
				lblLauncher.setBackground(Color.GRAY);
				lblLauncher.setBounds(606, 356, 292, 38);
				contentPane.add(lblLauncher);
				JPanel panel_5 = new JPanel();
				panel_5.setOpaque(false);
				panel_5.setForeground(Color.LIGHT_GRAY);
				panel_5.setBorder(new LineBorder(new Color(128, 128, 128)));
				panel_5.setBackground(fontBackground_Color);
				panel_5.setBounds(340, 82, 250, 212);
				contentPane.add(panel_5);

				final JLabel lblManageTestData = new JLabel("Manage Test Data");
				lblManageTestData.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e)
					{lblManageTestData.setBackground(MouseEntered_foregroundColor);lblManageTestData.setForeground(fontBackground_Color);}
				public void mouseExited(MouseEvent e)
					{lblManageTestData.setBackground(fontBackground_Color);lblManageTestData.setForeground(fontBackground);}
				public void mousePressed(MouseEvent arg0)
					{lblManageTestData.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
				public void mouseReleased(MouseEvent arg0)
					{lblManageTestData.setBorder(lineBorderColor);}
				public void mouseClicked(MouseEvent e) {
					Close();
					UI_Frame_DataConfiguration.main(null);
				}});

				lblManageTestData.setOpaque(true);
				lblManageTestData.setHorizontalAlignment(SwingConstants.CENTER);
				lblManageTestData.setForeground(Color.DARK_GRAY);
				lblManageTestData.setFont(fontStyle);
				lblManageTestData.setBorder(lineBorderColor);
				lblManageTestData.setBackground(fontBackground_Color);
				lblManageTestData.setBounds(83, 362, 215, 30);
				contentPane.add(lblManageTestData);

				final JLabel lblVisitExecReports = new JLabel("Visit Execution Reports");
				lblVisitExecReports.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e)
					{lblVisitExecReports.setBackground(MouseEntered_foregroundColor);lblVisitExecReports.setForeground(fontBackground_Color);}
				public void mouseExited(MouseEvent e)
					{lblVisitExecReports.setBackground(fontBackground_Color);lblVisitExecReports.setForeground(fontBackground);}
				public void mousePressed(MouseEvent arg0)
					{lblVisitExecReports.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
				public void mouseReleased(MouseEvent arg0)
					{lblVisitExecReports.setBorder(lineBorderColor);}
				public void mouseClicked(MouseEvent e) {
					try {
//						Desktop.getDesktop().open(new File(Settings.getSetting("REPORT_ROOT", connection)));
						Desktop.getDesktop().open(new File(Constants.PATH_REPORTS_FOLDER));
					} catch (Exception e1) {
						e1.printStackTrace();
					}}});
				lblVisitExecReports.setOpaque(true);
				lblVisitExecReports.setHorizontalAlignment(SwingConstants.CENTER);
				lblVisitExecReports.setForeground(Color.DARK_GRAY);
				lblVisitExecReports.setFont(fontStyle);
				lblVisitExecReports.setBorder(lineBorderColor);
				lblVisitExecReports.setBackground(fontBackground_Color);
				lblVisitExecReports.setBounds(83, 400, 215, 30);
				contentPane.add(lblVisitExecReports);

				final JLabel lblAdminister = new JLabel("Administer Coliseum");
				lblAdminister.setOpaque(true);
				lblAdminister.setHorizontalAlignment(SwingConstants.CENTER);
				lblAdminister.setForeground(Color.DARK_GRAY);
				lblAdminister.setFont(fontStyle);
				lblAdminister.setBorder(lineBorderColor);
				lblAdminister.setBackground(fontBackground_Color);
				lblAdminister.setBounds(360, 362, 215, 30);
				lblAdminister.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e)
					{lblAdminister.setBackground(MouseEntered_foregroundColor);lblAdminister.setForeground(fontBackground_Color);}
				public void mouseExited(MouseEvent e)
					{lblAdminister.setBackground(fontBackground_Color);lblAdminister.setForeground(fontBackground);}
				public void mousePressed(MouseEvent arg0)
					{lblAdminister.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
				public void mouseReleased(MouseEvent arg0)
					{lblAdminister.setBorder(lineBorderColor);}
				public void mouseClicked(MouseEvent e) {
					if (getAuthStatus().equalsIgnoreCase("A")){
							Close();
							UI_Frame_Admin.main(null);
					}
					else {
						Msgbox.msgbox("Insufficient privilleges! Only Admin users can use this feature.");
					}}});
				contentPane.add(lblAdminister);

				final JLabel lblVisitSqlRepo = new JLabel("Visit SQL Repository");
				lblVisitSqlRepo.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e)
					{lblVisitSqlRepo.setBackground(MouseEntered_foregroundColor);lblVisitSqlRepo.setForeground(fontBackground_Color);}
				public void mouseExited(MouseEvent e)
					{lblVisitSqlRepo.setBackground(fontBackground_Color);lblVisitSqlRepo.setForeground(fontBackground);}
				public void mousePressed(MouseEvent arg0)
					{lblVisitSqlRepo.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
				public void mouseReleased(MouseEvent arg0)
					{lblVisitSqlRepo.setBorder(lineBorderColor);}
				public void mouseClicked(MouseEvent e) {
						Close();
					    UI_Frame_VisitSQLRepository.main(null);
					}});
				lblVisitSqlRepo.setOpaque(true);
				lblVisitSqlRepo.setHorizontalAlignment(SwingConstants.CENTER);
				lblVisitSqlRepo.setForeground(Color.DARK_GRAY);
				lblVisitSqlRepo.setFont(fontStyle);
				lblVisitSqlRepo.setBorder(lineBorderColor);
				lblVisitSqlRepo.setBackground(fontBackground_Color);
				lblVisitSqlRepo.setBounds(83, 438, 215, 30);
				contentPane.add(lblVisitSqlRepo);

				final JLabel lblVisitObjectRepository = new JLabel("Visit Object Repository");
				lblVisitObjectRepository.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e)
					{lblVisitObjectRepository.setBackground(MouseEntered_foregroundColor);lblVisitObjectRepository.setForeground(fontBackground_Color);}
				public void mouseExited(MouseEvent e)
					{lblVisitObjectRepository.setBackground(fontBackground_Color);lblVisitObjectRepository.setForeground(fontBackground);}
				public void mousePressed(MouseEvent arg0)
					{lblVisitObjectRepository.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
				public void mouseReleased(MouseEvent arg0)
					{lblVisitObjectRepository.setBorder(lineBorderColor);}
				public void mouseClicked(MouseEvent e) {
						Close();
						UI_Frame_VisitOR.main(null);
					}});
				lblVisitObjectRepository.setOpaque(true);
				lblVisitObjectRepository.setHorizontalAlignment(SwingConstants.CENTER);
				lblVisitObjectRepository.setForeground(Color.DARK_GRAY);
				lblVisitObjectRepository.setFont(fontStyle);
				lblVisitObjectRepository.setBorder(lineBorderColor);
				lblVisitObjectRepository.setBackground(fontBackground_Color);
				lblVisitObjectRepository.setBounds(83, 475, 215, 30);
				contentPane.add(lblVisitObjectRepository);

				JLabel lblNewLabel = new JLabel("");
				lblNewLabel.setBackground(new Color(0, 0, 0));
				lblNewLabel.setOpaque(true);
				lblNewLabel.setBounds(0, 558, 954, 20);
				contentPane.add(lblNewLabel);
				txtWelcome = new JTextField();
				txtWelcome.setEditable(false);
				txtWelcome.setOpaque(false);
				txtWelcome.setBorder(null);
				txtWelcome.setFont(new Font("Trebuchet MS", Font.PLAIN, 11));
				txtWelcome.setBounds(10, 39, 215, 20);
				contentPane.add(txtWelcome);
					try {
						String query0 = "Select FNAME, LNAME from USERS where USER_NAME = (SELECT VALUE FROM SETTINGS WHERE SKEY = 'ACT_USER')";
						PreparedStatement statement = connection.prepareStatement(query0);
						ResultSet resultSet = statement.executeQuery();
				while (resultSet.next()) {
					String F= resultSet.getString("FNAME");
					txtWelcome.setText("Welcome "+F);
					resultSet.close();
				}
				} catch (Exception e2) {}

				JPanel panel_2 = new JPanel();
				panel_2.setBorder(new LineBorder(new Color(128, 128, 128)));
				panel_2.setOpaque(false);
				panel_2.setBounds(66, 307, 250, 224);
				contentPane.add(panel_2);

				JPanel panel_4 = new JPanel();
				panel_4.setOpaque(false);
				panel_4.setBorder(new LineBorder(new Color(128, 128, 128)));
				panel_4.setBounds(66, 82, 250, 212);
				contentPane.add(panel_4);

				JLabel label_5 = new JLabel("");
				label_5.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e){
						Close();
						UI_Frame_Update_TestSettings.main(null);
				}});
				label_5.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_Edit.png")));
				label_5.setBounds(856, 400, 26, 30);
				contentPane.add(label_5);
				JPanel panel_1 = new JPanel();
				panel_1.setOpaque(false);
				panel_1.setBorder(new LineBorder(new Color(128, 128, 128)));
				panel_1.setBounds(606, 356, 292, 175);
				contentPane.add(panel_1);

				JPanel panelforChart = new JPanel();
				panelforChart.setBounds(606, 118, 292, 227);
				contentPane.add(panelforChart);
					try{
						String query="Select top 10 A.TS, (passed/total*100) As Pass_Perc from "+
										"(select EXEC_TIMESTAMP AS TS, Count (RESULT) AS Total from EXEC_SUMMARY GROUP BY EXEC_TIMESTAMP) AS A, "+
										"(select EXEC_TIMESTAMP AS TS, Count (RESULT) AS Passed from EXEC_SUMMARY where RESULT = 'PASS' GROUP BY EXEC_TIMESTAMP) AS B "+
										"where A.TS = B.TS order by A.TS DESC";
						JDBCCategoryDataset dataset=new JDBCCategoryDataset(connection,query);
						JFreeChart chart=ChartFactory.createLineChart("", "", "", dataset, PlotOrientation.VERTICAL, false, true, true);
						ChartPanel myChart = new ChartPanel(chart);
						myChart.setOpaque(false);
						myChart.setFont(new Font("Trebuchet MS", Font.PLAIN, 10));
						myChart.setDisplayToolTips(true);
						myChart.setBorder(null);
			            panelforChart.setLayout(new java.awt.BorderLayout());
			            panelforChart.add(myChart,BorderLayout.CENTER);
			            panelforChart.validate();
			            chart.setBackgroundPaint(null);
					} catch(Exception e1){
						JOptionPane.showConfirmDialog(null, e1);
					}

				JLabel lblProgression = new JLabel("PROGRESSION");
				lblProgression.setOpaque(true);
				lblProgression.setHorizontalAlignment(SwingConstants.CENTER);
				lblProgression.setForeground(fontBackground_Color);
				lblProgression.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
				lblProgression.setBackground(Color.GRAY);
				lblProgression.setBounds(606, 82, 292, 38);
				contentPane.add(lblProgression);

				JLabel lblRegressionTest = new JLabel("Regression Test    Smoke Test      Build Verify");
				lblRegressionTest.setForeground(fontBackground);
				lblRegressionTest.setFont(new Font("Trebuchet MS", Font.PLAIN, 11));
				lblRegressionTest.setBounds(632, 507, 250, 14);
				contentPane.add(lblRegressionTest);

				JPanel panel = new JPanel();
				panel.setOpaque(false);
				panel.setBorder(new LineBorder(new Color(128, 128, 128)));
				panel.setBounds(340, 307, 250, 224);
				contentPane.add(panel);

				JLabel lblApplication = new JLabel("AUT:                     ENV: ");
				lblApplication.setForeground(SystemColor.controlDkShadow);
				lblApplication.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
				lblApplication.setBounds(632, 400, 235, 30);
				contentPane.add(lblApplication);
				JLabel label_2 = new JLabel("");
				label_2.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "white1.jpg")));
				label_2.setBounds(0, 0, 954, 557);
				contentPane.add(label_2);
	}

		public void Close()	{
			try {connection.close();} catch (SQLException e) {e.printStackTrace();}
			dispose();
		}

		public String getAuthStatus(){
		String sPRIV = null;
				try {
					ResultSet resultSet = connection.createStatement().executeQuery("Select PRIVILEGE from USERS where USER_NAME = (SELECT VALUE FROM SETTINGS WHERE SKEY = 'ACT_USER')");
					while (resultSet.next()) {
					sPRIV= resultSet.getString("PRIVILEGE");
				}
				resultSet.close();
				} catch (SQLException e) {e.printStackTrace();}

				return sPRIV;
		}
	}
