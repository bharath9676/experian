package com.optum.coliseum.frame;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import net.proteanit.sql.DbUtils;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;

import com.optum.coliseum.generic.Constants;

import java.awt.Toolkit;
import javax.swing.ImageIcon;

public class UI_Dialog_AddNewModule extends JDialog {

	private static final long serialVersionUID = 1L;
	JTextField txt_NewModName;
	JTable table_ModSch;
	public JScrollPane scrollPane_ModSchedular;
	String sObjRefForReturn = null;

	static Connection connection;
	private JTextField txt_NewModID;
	private JTextField txt_NewModDesc;
	private JLabel lbl_App;

	public static void main(final String sAUT, final Connection con) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					connection = con;
					final UI_Dialog_AddNewModule dialog = new UI_Dialog_AddNewModule(sAUT, connection);
					dialog.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
					dialog.setVisible(true);
					dialog.addWindowListener(new java.awt.event.WindowAdapter() {
					    @Override
					    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
					        if (JOptionPane.showConfirmDialog(dialog,"Are you done adding new Module?", "Really Closing?",JOptionPane.YES_NO_OPTION,
					            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION)
					        	dialog.dispose();
					        else{
					        	dialog.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
					        }
					    }});
					} catch (Exception e) {
					e.printStackTrace();
				}}});}

	/**
	 * Create the dialog.
	 */
	public UI_Dialog_AddNewModule(String sAUT, final Connection connection) {

		try {
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}

		setTitle("COLISEUM - Add new Object");

		setIconImage(Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Dlogo.jpg")));
		getContentPane().setBackground(Color.WHITE);
		setResizable(false);
		setBounds(100, 100, 660, 500);
		setLocationRelativeTo(null);
		getContentPane().setLayout(null);

		JLabel lbl_NewModName = new JLabel("Enter a new Module Name");
		lbl_NewModName.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		lbl_NewModName.setBounds(24, 88, 236, 30);
		getContentPane().add(lbl_NewModName);

		JLabel lbl_HeaderAddNewModule = new JLabel("ADD NEW MODULE");
		lbl_HeaderAddNewModule.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_HeaderAddNewModule.setForeground(Color.WHITE);
		lbl_HeaderAddNewModule.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 13));
		lbl_HeaderAddNewModule.setOpaque(true);
		lbl_HeaderAddNewModule.setBackground(Color.BLACK);
		lbl_HeaderAddNewModule.setBounds(0, 0, 654, 30);
		getContentPane().add(lbl_HeaderAddNewModule);

		JLabel lbl_FooterAddNewModule = new JLabel("");
		lbl_FooterAddNewModule.setOpaque(true);
		lbl_FooterAddNewModule.setBackground(Color.BLACK);
		lbl_FooterAddNewModule.setBounds(0, 462, 654, 10);
		getContentPane().add(lbl_FooterAddNewModule);

		txt_NewModName = new JTextField();
		txt_NewModName.setFont(new Font("Trebuchet MS", Font.PLAIN, 11));
		txt_NewModName.setBounds(270, 89, 352, 30);
		getContentPane().add(txt_NewModName);

		final JLabel lbl_SaveORAdd = new JLabel("SAVE");
		lbl_SaveORAdd.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e)
			{lbl_SaveORAdd.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{lbl_SaveORAdd.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{lbl_SaveORAdd.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {lbl_SaveORAdd.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent arg0) {
				if (ValidateMandatoryFields()){
					try {connection.createStatement().executeUpdate("insert into MOD_SCHEDULER (MODULEID, MODULE_NAME, EXEC_FLAG, APPLICATION, MODULE_DESC) VALUES ('"+txt_NewModID.getText()+"', '"+txt_NewModName.getText()+"', 'NO', '"+lbl_App.getText().toString()+"', '"+txt_NewModDesc.getText()+"')");
						updateTable();
						Msgbox.msgbox("Module added sucessfully!");
					} catch (Exception e) {e.printStackTrace();}
				};
			}
		});
		lbl_SaveORAdd.setOpaque(true);
		lbl_SaveORAdd.setForeground(Color.WHITE);
		lbl_SaveORAdd.setBackground(Color.BLACK);
		lbl_SaveORAdd.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_SaveORAdd.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 13));
		lbl_SaveORAdd.setBounds(546, 428, 83, 23);
		getContentPane().add(lbl_SaveORAdd);

		JLabel lblEnterNewModID = new JLabel("Enter a new Module ID");
		lblEnterNewModID.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		lblEnterNewModID.setBounds(24, 129, 236, 30);
		getContentPane().add(lblEnterNewModID);

		txt_NewModID = new JTextField();
		txt_NewModID.setFont(new Font("Trebuchet MS", Font.PLAIN, 11));
		txt_NewModID.setBounds(270, 130, 352, 30);
		getContentPane().add(txt_NewModID);

		JLabel lblEnterNewModDesc = new JLabel("Enter a new Module Description");
		lblEnterNewModDesc.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		lblEnterNewModDesc.setBounds(24, 170, 236, 30);
		getContentPane().add(lblEnterNewModDesc);

		txt_NewModDesc = new JTextField();
		txt_NewModDesc.setFont(new Font("Trebuchet MS", Font.PLAIN, 11));
		txt_NewModDesc.setBounds(270, 171, 352, 30);
		getContentPane().add(txt_NewModDesc);

		JLabel lbl_Application = new JLabel("Application");
		lbl_Application.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		lbl_Application.setBounds(24, 46, 236, 30);
		getContentPane().add(lbl_Application);

		lbl_App = new JLabel();
		lbl_App.setBackground(Color.WHITE);
		lbl_App.setOpaque(true);
		lbl_App.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		lbl_App.setBounds(270, 47, 352, 30);
		getContentPane().add(lbl_App);
		lbl_App.setText(sAUT);

		/*try{
			PreparedStatement pst  = connection.prepareStatement("Select distinct application from Env");
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				cBox_App.addItem(rs.getString("application"));
			}
			rs.close();
			pst.close();
		}
		catch(Exception e){e.printStackTrace();}

		cBox_App.setSelectedItem(Settings.getSetting("AUT", connection));
		cBox_App.addItem(sAUT);
		cBox_App.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateTable();
			}
		});
*/
		scrollPane_ModSchedular = new JScrollPane();
		scrollPane_ModSchedular.setBounds(24, 233, 605, 185);
		getContentPane().add(scrollPane_ModSchedular);
		table_ModSch = new JTable();
		table_ModSch.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_DELETE){
					try {
						DeleteTestStep();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
			    }
			}
		});
		updateTable();

		JLabel lbl_BGNewMod = new JLabel("");
		lbl_BGNewMod.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "white1.jpg")));

		lbl_BGNewMod.setBounds(0, 212, 654, 329);
		getContentPane().add(lbl_BGNewMod);
	}

	public void DeleteTestStep(){
		   int action = JOptionPane.showConfirmDialog(null, "Are you sure you want to Delete this Record?", "CONFIRMATION",JOptionPane.YES_NO_OPTION );
		   if(action ==0){
			  int row = table_ModSch.getSelectedRow();
		      try {
				connection.createStatement().executeUpdate("Delete from MOD_SCHEDULER where MODULEID = '"+(table_ModSch.getModel().getValueAt(row, 0)).toString()+"'");
		      } catch (SQLException e) {e.printStackTrace();}
		      updateTable();
		      Msgbox.msgbox("Record Deleted!");
		   }
	}

	public void updateTable(){
		try{
			 Statement st08 = connection.createStatement();
			 ResultSet rs08 = st08.executeQuery("Select MODULEID, MODULE_NAME, MODULE_DESC from MOD_SCHEDULER where application = '"+lbl_App.getText()+"'");
			 table_ModSch.setModel(DbUtils.resultSetToTableModel(rs08));
		}
		catch(Exception etc){
			 etc.printStackTrace();
		}
		scrollPane_ModSchedular.setViewportView(table_ModSch);
	}

	public boolean ValidateMandatoryFields(){
		boolean ireturn = false;

		if (txt_NewModName.getText().toString().equals("")){
			Msgbox.msgbox("Please enter Module Name!");
		}
		else if (txt_NewModID.getText().toString().equals("")){
			Msgbox.msgbox("Please enter Module ID!");
		}
		else if (txt_NewModDesc.getText().toString().equals("")){
			Msgbox.msgbox("Please enter Module Description!");
		}
		else if (!txt_NewModID.getText().toString().startsWith(lbl_App.getText().toString())){
			Msgbox.msgbox("Please follow the convention for adding ModuleID. It should start with 2 charecters long Application ID (the one in the Application dropdown).");
		}
		else if (!(txt_NewModID.getText().length()==5)){
			Msgbox.msgbox("Please follow the convention for adding ModuleID. It's length should be 5 charecters.");
		}
		else if (txt_NewModName.getText().length()>49){
			Msgbox.msgbox("Please follow the convention for adding Module Name. It's length should not exceed 50 charecters.");
		}
		else {
			try {
				ResultSet rs08 = connection.createStatement().executeQuery("Select MODULEID from MOD_SCHEDULER where MODULEID = '"+txt_NewModID.getText()+"'" );
				if (rs08.next()){
					Msgbox.msgbox("Module ID already exists. Please enter new Module ID");
				}
				else ireturn = true;
			} catch (SQLException e) {e.printStackTrace();}
		}

		return ireturn;
	}

}
