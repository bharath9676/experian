package com.optum.coliseum.frame;


import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.DBUtils;

import javax.swing.ImageIcon;

public class UI_Frame_Admin extends JFrame {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private static Connection connection;

	Vector<Vector<Object>> data;
	DefaultTableModel tb2model;
	Vector<Vector<Object>> data1;
	JScrollPane scrollPane_3;
	DefaultTableModel tb2model1;
	Box horizontalBox1;
	JScrollPane scrollPane5;
	Box horizontalBox_1;
	Box horizontalBox_3;
	DefaultTableModel tb2model5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				connection = DBUtils.DBConnect_Automation();
				try {	final UI_Frame_Admin frame = new UI_Frame_Admin();
						frame.setVisible(true);
						frame.addWindowListener(new java.awt.event.WindowAdapter() {
						    @Override
						    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
						        if (JOptionPane.showConfirmDialog(frame,"Are you sure to close this window?", "Really Closing?",JOptionPane.YES_NO_OPTION,
						            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
						        	try {
						        		connection.close();
							        	frame.dispose();
						        		UI_Frame_Dashboard homePage = new UI_Frame_Dashboard();
						        		homePage.setVisible(true);
									} catch (Exception e) {
										e.printStackTrace();
									}
						        }
						        else{
						        	frame.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
						        }
						    }
						});
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}

	/**
	 * Create the frame.
	 * @throws SQLException
	 */

	public UI_Frame_Admin() {

		try {
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}

		setIconImage(Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Dlogo.jpg")));

		setResizable(false);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 960, 600);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblScheduleModules = new JLabel("ACTION ITEMS");
		lblScheduleModules.setHorizontalAlignment(SwingConstants.CENTER);
		lblScheduleModules.setBackground(Color.GRAY);
		lblScheduleModules.setOpaque(true);
		lblScheduleModules.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblScheduleModules.setForeground(Color.WHITE);
		lblScheduleModules.setBounds(81, 70, 333, 30);
		contentPane.add(lblScheduleModules);

		JLabel lblScheduleTestCases = new JLabel("MANAGE USERS");
		lblScheduleTestCases.setHorizontalAlignment(SwingConstants.CENTER);
		lblScheduleTestCases.setBackground(Color.GRAY);
		lblScheduleTestCases.setOpaque(true);
		lblScheduleTestCases.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblScheduleTestCases.setForeground(Color.WHITE);
		lblScheduleTestCases.setBounds(441, 70, 468, 30);
		contentPane.add(lblScheduleTestCases);

		Vector<Object> cols = new Vector<Object>();
		cols.addElement("User Name");
		//cols.addElement("Last Name");
		cols.addElement("Approve?");
		Vector<Vector<Object>> rows = null;

		try {
			PreparedStatement statement = connection.prepareStatement("select USER_NAME,AUTHORIZED from USERS where AUTHORIZED = 'N'");
			ResultSet rs = statement.executeQuery();
			rows = new Vector<Vector<Object>>();
			while (rs.next()) {
				Vector<Object> newRow = new Vector<Object>();
				newRow.addElement(rs.getString(1));
				String flag = rs.getString(2);
				if ("Y".equals(flag)) {
					newRow.addElement(Boolean.TRUE);
				} else {
					newRow.addElement(Boolean.FALSE);
				}
				rows.add(newRow);
			}
		} catch (SQLException e) {
			e.printStackTrace();

		}

		DefaultTableModel model = new DefaultTableModel(rows, cols);

		table = new JTable(model) {

			private static final long serialVersionUID = 1L;

			@Override
			public Class<?> getColumnClass(int column) {
				switch (column) {
				case 0:
					return String.class;
				default:
					return Boolean.class;
				}
			}
		};
		table.setPreferredScrollableViewportSize(table.getPreferredSize());
		JScrollPane SM_scrollPane = new JScrollPane(table);
		SM_scrollPane.setBounds(81, 144, 333, 117);
		contentPane.add(SM_scrollPane);

		Box horizontalBox_1 = Box.createHorizontalBox();
		SM_scrollPane.setColumnHeaderView(horizontalBox_1);

		final JLabel SM_btnSave = new JLabel("APPROVE SELECTED");
		SM_btnSave.setHorizontalAlignment(SwingConstants.CENTER);
		SM_btnSave.setOpaque(true);
		SM_btnSave.setBackground(new Color(0, 0, 0));
		SM_btnSave.setForeground(new Color(255, 255, 255));
		SM_btnSave.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		SM_btnSave.setBounds(143, 281, 180, 30);
		SM_btnSave.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e)
			{SM_btnSave.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{SM_btnSave.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{SM_btnSave.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {SM_btnSave.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent e) {
				TableModel model = table.getModel();
				for (int i = 0; i < model.getRowCount(); i++) {
					String mode = (String) model.getValueAt(i, 0);
					String flag = "N";
					if ((boolean) model.getValueAt(i, 1)) {
						flag = "Y";
					}
					try {
						PreparedStatement st = connection.prepareStatement(
								"update USER_DETAILS set AUTHORIZED='" + flag + "' where USER_NAME='" + mode + "'");
						st.execute();
						st.close();
						Msgbox.msgbox("User Status updated successfully!");
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		contentPane.add(SM_btnSave);

		JLabel lblNewUserRequests = new JLabel("New user requests :");
		lblNewUserRequests.setForeground(Color.DARK_GRAY);
		lblNewUserRequests.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblNewUserRequests.setBounds(81, 108, 132, 30);
		contentPane.add(lblNewUserRequests);

		JLabel lblBack = new JLabel();
		lblBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				try {
					connection.close();
					dispose();
					UI_Frame_Dashboard objdshbrd = new UI_Frame_Dashboard();
					objdshbrd.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		lblBack.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "icon_back.png")));

		lblBack.setBounds(0, 0, 40, 30);
		lblBack.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblBack);

		JLabel label = new JLabel("");
		label.setOpaque(true);
		label.setBackground(Color.BLACK);
		label.setBounds(0, 557, 954, 15);
		contentPane.add(label);

		JLabel lblAdminCenter = new JLabel("ADMIN CENTER");
		lblAdminCenter.setOpaque(true);
		lblAdminCenter.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdminCenter.setForeground(Color.WHITE);
		lblAdminCenter.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblAdminCenter.setBackground(Color.BLACK);
		lblAdminCenter.setBounds(0, 0, 954, 30);
		contentPane.add(lblAdminCenter);

		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "white1.jpg")));

		label_1.setBounds(0, 0, 954, 572);
		contentPane.add(label_1);

		getTable(null);
		contentPane.revalidate();
		contentPane.repaint();


	}

	private void getTable(String item) {
	if (horizontalBox1 != null) {
		contentPane.remove(horizontalBox1);
	}
//	connection1 = sqliteConnection.DBConnect_Automation();

}

}

