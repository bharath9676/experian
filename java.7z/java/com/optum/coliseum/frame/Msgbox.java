package com.optum.coliseum.frame;

import javax.swing.JDialog;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;

import com.optum.coliseum.generic.Constants;

public class Msgbox extends JDialog {
	public Msgbox() {
	}
	public static String sText = null;
	private static final long serialVersionUID = 1L;
	public static Msgbox dialog;
	public static int iRet = 0;
	/**
	 * Launch the application.
	 * @return
	 */
	public static void msgbox(String sText){
		try {
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}

		dialog = new Msgbox();
		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		dialog.setResizable(false);
		dialog.setTitle("ACTION MESSAGE FROM COLISEUM");
		dialog.getContentPane().setBackground(Color.WHITE);
		dialog.getContentPane().setLayout(null);
		dialog.setBounds(0, 0, 404, 130);
		dialog.setLocationRelativeTo(null);
		{
			JLabel label = new JLabel("");
			label.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "dice2.png")));

			label.setBounds(319, 0, 79, 103);
			dialog.getContentPane().add(label);
		}
		{
			JTextArea lbl_MESSAGEBODY = new JTextArea(sText);
			lbl_MESSAGEBODY.setWrapStyleWord(true);
			lbl_MESSAGEBODY.setEditable(false);
			lbl_MESSAGEBODY.setLineWrap(true);
			lbl_MESSAGEBODY.setRows(3);
			lbl_MESSAGEBODY.setBorder(null);
			lbl_MESSAGEBODY.setOpaque(false);
			//lbl_MESSAGEBODY.setHorizontalAlignment(SwingConstants.CENTER);
			lbl_MESSAGEBODY.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
			lbl_MESSAGEBODY.setBounds(10, 11, 311, 44);
			dialog.getContentPane().add(lbl_MESSAGEBODY);
		}

		final JLabel lblOk = new JLabel("OK");
		lblOk.setForeground(Color.WHITE);
		lblOk.setOpaque(true);
		lblOk.setBackground(Color.BLACK);
		lblOk.setHorizontalAlignment(SwingConstants.CENTER);
		lblOk.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 13));
		lblOk.setBounds(164, 66, 70, 25);
		lblOk.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e)
			{lblOk.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{lblOk.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{lblOk.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {lblOk.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent e) {
				dialog.dispose();
				iRet = 1;
			}
		});
		dialog.getContentPane().add(lblOk);
		dialog.setVisible(true);
	}

	public static int decisionbox(String sText){
		dialog = new Msgbox();
		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		dialog.setResizable(false);
		dialog.setTitle("ACTION MESSAGE FROM COLISEUM");
		dialog.getContentPane().setBackground(Color.WHITE);
		dialog.getContentPane().setLayout(null);
		dialog.setBounds(0, 0, 404, 130);
		dialog.setLocationRelativeTo(null);
		{
			JLabel label = new JLabel("");
			label.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "dice2.png")));

			label.setBounds(319, 0, 79, 103);
			dialog.getContentPane().add(label);
		}
		{
			JTextArea lbl_MESSAGEBODY = new JTextArea(sText);
			lbl_MESSAGEBODY.setWrapStyleWord(true);
			lbl_MESSAGEBODY.setEditable(false);
			lbl_MESSAGEBODY.setLineWrap(true);
			lbl_MESSAGEBODY.setRows(3);
			lbl_MESSAGEBODY.setBorder(null);
			lbl_MESSAGEBODY.setOpaque(false);
			//lbl_MESSAGEBODY.setHorizontalAlignment(SwingConstants.CENTER);
			lbl_MESSAGEBODY.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
			lbl_MESSAGEBODY.setBounds(10, 11, 311, 44);
			dialog.getContentPane().add(lbl_MESSAGEBODY);
		}

		final JLabel lblOk = new JLabel("OK");
		lblOk.setForeground(Color.WHITE);
		lblOk.setOpaque(true);
		lblOk.setBackground(Color.BLACK);
		lblOk.setHorizontalAlignment(SwingConstants.CENTER);
		lblOk.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 13));
		lblOk.setBounds(164, 66, 70, 25);
		lblOk.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e)
			{lblOk.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{lblOk.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{lblOk.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {lblOk.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent e) {
				dialog.dispose();
				iRet = 1;
			}
		});
		dialog.getContentPane().add(lblOk);

		final JLabel lblCancel = new JLabel("CANCEL");
		lblCancel.setForeground(Color.WHITE);
		lblCancel.setOpaque(true);
		lblCancel.setBackground(Color.BLACK);
		lblCancel.setHorizontalAlignment(SwingConstants.CENTER);
		lblCancel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 13));
		lblCancel.setBounds(244, 66, 70, 25);
		lblCancel.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e)
			{lblCancel.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{lblCancel.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{lblCancel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {lblCancel.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent e) {
				dialog.dispose();
			}
		});
		dialog.getContentPane().add(lblCancel);
		dialog.setVisible(true);
		return iRet;
	}

}
