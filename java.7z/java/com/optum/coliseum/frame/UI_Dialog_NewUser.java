package com.optum.coliseum.frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;

import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.DBUtils;

public class UI_Dialog_NewUser extends JDialog {

	private static final long serialVersionUID = 1L;
	private JTextField txt_FName;
	private JTextField txt_MSID;
	private JTextField txt_Proj;
	private JTextArea  txt_justification;
	private JTextField txt_SecurityQuestion;
	private JTextField txt_SecurityAnswer;
	private JTextField txt_EmailID;
	private JTextField txt_EmailID2;
	private JTextField txt_LName;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UI_Dialog_NewUser dialog = new UI_Dialog_NewUser();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public UI_Dialog_NewUser() {

		try {
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}

		setTitle("Coliseum - Request access");
		setResizable(false);
		getContentPane().setBackground(Color.WHITE);
		setBounds(100, 100, 450, 529);
		setLocationRelativeTo(null);
		getContentPane().setLayout(null);

		JLabel lblRequestersName = new JLabel("Requester's Name");
		lblRequestersName.setForeground(Color.DARK_GRAY);
		lblRequestersName.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		lblRequestersName.setBounds(27, 38, 130, 30);
		getContentPane().add(lblRequestersName);

		JLabel lblRequestersProject = new JLabel("Requester's Project");
		lblRequestersProject.setForeground(Color.DARK_GRAY);
		lblRequestersProject.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		lblRequestersProject.setBounds(27, 138, 130, 30);
		getContentPane().add(lblRequestersProject);

		JLabel lblRequestJustification = new JLabel("Request justification");
		lblRequestJustification.setForeground(Color.DARK_GRAY);
		lblRequestJustification.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		lblRequestJustification.setBounds(27, 379, 130, 30);
		getContentPane().add(lblRequestJustification);

		JLabel lblRequestersMsid = new JLabel("Requester's MSID");
		lblRequestersMsid.setForeground(Color.DARK_GRAY);
		lblRequestersMsid.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		lblRequestersMsid.setBounds(27, 97, 130, 30);
		getContentPane().add(lblRequestersMsid);

		txt_FName = new JTextField();
		txt_FName.setBorder(new LineBorder(Color.LIGHT_GRAY));
		txt_FName.setBounds(165, 39, 118, 30);
		getContentPane().add(txt_FName);
		txt_FName.setColumns(10);

		txt_MSID = new JTextField();
		txt_MSID.setBorder(new LineBorder(Color.LIGHT_GRAY));
		txt_MSID.setColumns(10);
		txt_MSID.setBounds(165, 97, 235, 30);
		getContentPane().add(txt_MSID);

		txt_Proj = new JTextField();
		txt_Proj.setBorder(new LineBorder(Color.LIGHT_GRAY));
		txt_Proj.setColumns(10);
		txt_Proj.setBounds(165, 138, 235, 30);
		getContentPane().add(txt_Proj);

		txt_justification = new JTextArea ();
		txt_justification.setBorder(new LineBorder(Color.LIGHT_GRAY));
		txt_justification.setRows(4);
		txt_justification.setColumns(10);
		txt_justification.setBounds(165, 153, 235, 65);
		txt_justification.setLineWrap(true);  //this tells it to break the string to fit the TextArea
		txt_justification.setWrapStyleWord(true);  //this tells it to break at the word instead of at the character
		JScrollPane jp = new JScrollPane(txt_justification);
		jp.setBorder(new LineBorder(Color.LIGHT_GRAY));
		jp.setBounds(165, 383, 235, 65);
		getContentPane().add(jp);

		JLabel lblColiseumRegistrationForm = new JLabel("COLISEUM REGISTRATION FORM");
		lblColiseumRegistrationForm.setHorizontalAlignment(SwingConstants.CENTER);
		lblColiseumRegistrationForm.setForeground(Color.WHITE);
		lblColiseumRegistrationForm.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 13));
		lblColiseumRegistrationForm.setBackground(Color.BLACK);
		lblColiseumRegistrationForm.setOpaque(true);
		lblColiseumRegistrationForm.setBounds(0, 0, 444, 27);
		getContentPane().add(lblColiseumRegistrationForm);

		JLabel label_1 = new JLabel("");
		label_1.setOpaque(true);
		label_1.setBackground(Color.BLACK);
		label_1.setBounds(0, 491, 444, 10);
		getContentPane().add(label_1);

		final JLabel lblSubmit = new JLabel("SUBMIT REQUEST");
		lblSubmit.setBackground(Color.BLACK);
		lblSubmit.setForeground(Color.WHITE);
		lblSubmit.setOpaque(true);
		lblSubmit.setHorizontalAlignment(SwingConstants.CENTER);
		lblSubmit.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		lblSubmit.setBounds(250, 459, 150, 22);
		lblSubmit.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e)
			{lblSubmit.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{lblSubmit.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{lblSubmit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {lblSubmit.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent e) {
				int iFlag = 1;
				try {
					if (txt_FName.getText().equals("")){
						Msgbox.msgbox("Please enter requester's First Name!");
						 iFlag = 0;
					}
					else if (txt_LName.getText().equals("")){
						Msgbox.msgbox("Please enter requester's Last Name!");
						 iFlag = 0;
					}
					else if (txt_MSID.getText().equals("")){
						Msgbox.msgbox("Please enter MSID!");
						 iFlag = 0;
		       	   	}
					else if (txt_Proj.getText().equals("")){
						Msgbox.msgbox("Please enter requester's Project Name!");
						 iFlag = 0;
					}
					else if (txt_SecurityQuestion.getText().equals("")){
						Msgbox.msgbox("Please enter your Sequrity Question!");
						 iFlag = 0;
					}
					else if (txt_SecurityAnswer.getText().equals("")){
						Msgbox.msgbox("Please enter your Security Answer!");
						 iFlag = 0;
					}
					else if (txt_EmailID.getText().equals("")){
						Msgbox.msgbox("Please enter your email ID!");
						 iFlag = 0;
					}
					else if (txt_EmailID2.getText().equals("")){
						Msgbox.msgbox("Please re-enter your email ID!");
						 iFlag = 0;
					}
					else if (txt_justification.getText().equals("")){
						Msgbox.msgbox("Please enter a business justification!");
						 iFlag = 0;
					}
					if (iFlag == 1) {
						if (txt_EmailID2.getText().contains("@")){
							if (txt_EmailID2.getText().equals(txt_EmailID.getText())){
								UpdateDBwithNewUser();}
							else{
								Msgbox.msgbox("Email IDs do not match!");
							}
						}
						else {
							Msgbox.msgbox("Invalid Email ID!");
						}
					}
				} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
				}
			}
		});
		getContentPane().add(lblSubmit);

		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "dice2.png")));

		label_2.setBounds(355, 210, 89, 108);
		getContentPane().add(label_2);

		JLabel lbl_SecurityQuestion = new JLabel("Security Question");
		lbl_SecurityQuestion.setForeground(Color.DARK_GRAY);
		lbl_SecurityQuestion.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		lbl_SecurityQuestion.setBounds(27, 197, 130, 30);
		getContentPane().add(lbl_SecurityQuestion);

		txt_SecurityQuestion = new JTextField();
		txt_SecurityQuestion.setBorder(new LineBorder(Color.LIGHT_GRAY));
		txt_SecurityQuestion.setColumns(10);
		txt_SecurityQuestion.setBounds(165, 197, 235, 30);
		getContentPane().add(txt_SecurityQuestion);

		JLabel lbl_SecurityAnswer = new JLabel("Security Answer");
		lbl_SecurityAnswer.setForeground(Color.DARK_GRAY);
		lbl_SecurityAnswer.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		lbl_SecurityAnswer.setBounds(27, 240, 130, 30);
		getContentPane().add(lbl_SecurityAnswer);

		txt_SecurityAnswer = new JTextField();
		txt_SecurityAnswer.setBorder(new LineBorder(Color.LIGHT_GRAY));
		txt_SecurityAnswer.setColumns(10);
		txt_SecurityAnswer.setBounds(165, 240, 235, 30);
		getContentPane().add(txt_SecurityAnswer);

		JLabel lblEmailId = new JLabel("Email ID");
		lblEmailId.setForeground(Color.DARK_GRAY);
		lblEmailId.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		lblEmailId.setBounds(27, 281, 130, 30);
		getContentPane().add(lblEmailId);

		txt_EmailID = new JTextField();
		txt_EmailID.setBorder(new LineBorder(Color.LIGHT_GRAY));
		txt_EmailID.setColumns(10);
		txt_EmailID.setBounds(165, 281, 235, 30);
		getContentPane().add(txt_EmailID);

		JLabel lblReenterEmailId = new JLabel("Re-enter Email ID");
		lblReenterEmailId.setForeground(Color.DARK_GRAY);
		lblReenterEmailId.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		lblReenterEmailId.setBounds(27, 322, 130, 30);
		getContentPane().add(lblReenterEmailId);

		txt_EmailID2 = new JTextField();
		txt_EmailID2.setBorder(new LineBorder(Color.LIGHT_GRAY));
		txt_EmailID2.setColumns(10);
		txt_EmailID2.setBounds(165, 322, 235, 30);
		getContentPane().add(txt_EmailID2);

		JLabel label_5 = new JLabel("");
		label_5.setVerifyInputWhenFocusTarget(false);
		label_5.setOpaque(true);
		label_5.setBorder(null);
		label_5.setBackground(Color.LIGHT_GRAY);
		label_5.setBounds(0, 363, 444, 5);
		getContentPane().add(label_5);

		txt_LName = new JTextField();
		txt_LName.setBorder(new LineBorder(Color.LIGHT_GRAY));
		txt_LName.setColumns(10);
		txt_LName.setBounds(293, 39, 107, 30);
		getContentPane().add(txt_LName);

		JLabel lblFirstName = new JLabel("First Name");
		lblFirstName.setFont(new Font("Trebuchet MS", Font.ITALIC, 10));
		lblFirstName.setBounds(165, 72, 107, 14);
		getContentPane().add(lblFirstName);

		JLabel lblLastName = new JLabel("Last Name");
		lblLastName.setFont(new Font("Trebuchet MS", Font.ITALIC, 10));
		lblLastName.setBounds(293, 72, 107, 14);
		getContentPane().add(lblLastName);

		JLabel lblAllFieldsAre = new JLabel("All fields are mandatory");
		lblAllFieldsAre.setForeground(Color.RED);
		lblAllFieldsAre.setFont(new Font("Trebuchet MS", Font.ITALIC, 10));
		lblAllFieldsAre.setBounds(18, 464, 139, 14);
		getContentPane().add(lblAllFieldsAre);

		JLabel label_4 = new JLabel("");
		label_4.setBorder(null);
		label_4.setOpaque(true);
		label_4.setVerifyInputWhenFocusTarget(false);
		label_4.setBackground(Color.LIGHT_GRAY);
		label_4.setBounds(0, 179, 444, 7);
		getContentPane().add(label_4);

		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "white1.jpg")));

		label_3.setBounds(0, 367, 444, 134);
		getContentPane().add(label_3);
	}

	public void UpdateDBwithNewUser() throws Exception{
		Connection Tcon = null;
		Tcon = DBUtils.DBConnect_Automation();
		String sVal = "'"+ txt_MSID.getText()+"','DEFAULT','"+txt_FName.getText()+"','"+txt_LName.getText()+"','"+txt_EmailID.getText()+"','"+txt_SecurityQuestion.getText()+"','"+txt_SecurityAnswer.getText()+"','"+txt_Proj.getText()+"','N','U'";
		String sQuery = "INSERT INTO USERS (USER_NAME,PASSWORD,FNAME,LNAME,EMAIL,SECURITY_Q,SECURITY_A,PROJECT,AUTHORIZED,PRIVILEGE) VALUES ("+sVal+")";
		try {
			PreparedStatement statement = Tcon.prepareStatement(sQuery);
			statement.executeUpdate();
			sendMail();
		} catch (SQLException e) {e.printStackTrace();}
		Tcon.close();
	}

	public void sendMail(){
		PrintWriter writer;

	String mailBody = txt_FName.getText() + " " +txt_LName.getText() +" (MSID: " + txt_MSID.getText()+ ") has requested access to Coliseum for Project: "+txt_Proj.getText()+". Reason: " +txt_justification.getText();
	System.out.println(mailBody);

		try {
			writer = new PrintWriter(Constants.PATH_DRIVERS_TEMP, "UTF-8");
			writer.println("Set objOutlook = CreateObject(\"Outlook.Application\")");
			writer.println("Set objMail = objOutlook.CreateItem(0)");
			writer.println("objMail.Recipients.Add (\"ashutosh_jain@optum.com\")");
			writer.println("objMail.Recipients.Add (\"lakkapatini_santhoshkumar@optum.com\")");
			writer.println("objMail.Subject = \"Colisuem | New user request\"");
			writer.println("strbody = \"New user request received from: "+txt_FName.getText()+" "+txt_LName.getText()+"\" & vbNewLine & vbNewLine & _");
			writer.println("\"MSID: "+txt_MSID.getText()+ "\" & vbNewLine & _");
			writer.println("\"Project Name: "+txt_Proj.getText()+ "\" & vbNewLine & _");
			writer.println("\"Business Justification: "+txt_justification.getText()+ "\" & vbNewLine & vbNewLine & _");
			writer.println("\"Thanks!\"");
			writer.println("objMail.Body = strbody");
			writer.println("objMail.Send");
			writer.println("Set objMail = Nothing");
			writer.println("Set objOutlook = Nothing");
			writer.close();
		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
		      Runtime.getRuntime().exec( "wscript " + Constants.PATH_DRIVERS_TEMP);
		      dispose();
		      Msgbox.msgbox("Request sent to Coliseum Admin");
		   }
		   catch( IOException e ) {
		      System.out.println(e);
		      System.exit(0);
		   }
	}

}
