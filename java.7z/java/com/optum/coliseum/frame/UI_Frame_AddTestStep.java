package com.optum.coliseum.frame;

import java.awt.Color;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import org.apache.commons.lang3.StringUtils;

import com.optum.coliseum.driver.DriverLib;
import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.DBUtils;
import com.optum.coliseum.generic.Settings;

import net.proteanit.sql.DbUtils;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import java.awt.Toolkit;
import javax.swing.border.EtchedBorder;
import java.awt.SystemColor;
import javax.swing.border.MatteBorder;
public class UI_Frame_AddTestStep extends JFrame {

	private static final long serialVersionUID = 1L;
	public int deleteFalg =1;
	static Connection connection = null;
	private int obj_row;
	public String obj_objRef="";
	private String  obj_objId="";
	private String obj_objName="";
	private String obj_objLinkText="";
	private String obj_objTagType="";
	private String obj_objTitle="";
	private String obj_objXpath="";
	public String getSelectedValue;
	public String objReference;
	public String ow_Title;
	public String ow_Id;
	public String ow_Name;
	public String ow_Linktext;
	public JTextField txt_NewObjRefName;
	JTextField txt_UseXPath;
	JCheckBox ChkBx_UseXPath;
	JCheckBox ChkBx_UseOWTable;
	JTable table_OW;
	public String sObjRefForReturn = null;
	public JFrame  visitOR;
	public JDialog visitKeywords;
	private JTable table_OR;
	public String objRef;
	public boolean isNewTC;
	public int rowOR = 0;
	public int rowOW = 0;
	public int rowDrv = -1;
	public JFrame addNewObject;
	public int step_ID;
	public int row_ID;
	public int iNewStepId;
	public String oLinkText;
	public String ocssSelector;
	public String oxpath;
	public String testCaseID;
	public String moduleID = "0";
	public String max_dmID;
	public String SelectedObj;
	private JLabel lbl_StepInfo;
	private JLabel btnAddTestStep;
	private JTable table_Sql;
	private JRadioButton rdbtn_ISTemplate;
	private JRadioButton rdbtn_isTC;
	private JRadioButton rb_NewName;
	private JRadioButton rb_SelectExisting;
	private JLabel lbl_SelectedID;
	JCheckBox chckbxScreenshot;
	JTabbedPane tabbedPane;
	private JComboBox<String> cBox_ApplicationName;
	private JComboBox<String> cBox_ExistingName;
	private JComboBox<String> cBox_SelectKeyword;
	private JComboBox<String> cBox_SelectobjRef;
	private JComboBox<String> cbox_moduleName;
	private JComboBox<String> cBox_RTVAL;
	private JLabel lblModID;
	private JLabel  lbl_ModDesc2;
	private JLabel lblAllottedID;
	private JLabel lbl_FrameForTemplates;
	private JLabel lbl_OBJREF_BANK;
	private JLabel lbl_VisitModules;
	private JPanel contentPane;
	private JTextArea txt_Description;
	private JTextField txt_TextDataValue;
	private JTable table_Driver;
	private JTextField txt_NewName;
	private JTextField txt_refTPK;
	private JTextField txt_StepDescInput;
	private JTable table_Sql1;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					connection = DBUtils.DBConnect_Automation();
					final UI_Frame_AddTestStep frame = new UI_Frame_AddTestStep();
					frame.setVisible(true);
					frame.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
					frame.addWindowListener(new java.awt.event.WindowAdapter() {
				    @Override
				    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				        if (JOptionPane.showConfirmDialog(frame,"Are you sure to close this window?", "Really Closing?",JOptionPane.YES_NO_OPTION,
				            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
				        	try {
				        		connection.close();
					        	frame.dispose();
				        		UI_Frame_Dashboard homePage = new UI_Frame_Dashboard();
				        		homePage.setVisible(true);
							} catch (Exception e) {e.printStackTrace();}
				        }
				        else{frame.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);}
				    }});
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public UI_Frame_AddTestStep()  {

		try {
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}

		setIconImage(Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Dlogo.jpg")));

		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 960, 600);
		setLocationRelativeTo(null);

		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lbl_Footer = new JLabel("");
		lbl_Footer.setOpaque(true);
		lbl_Footer.setBackground(Color.BLACK);
		lbl_Footer.setBounds(0, 561, 954, 11);
		contentPane.add(lbl_Footer);

		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
//		tabbedPane.setUI(new AquaBarTabbedPaneUI());
//		tabbedPane.setUI(new CWTabbedPaneUI());
		tabbedPane.setBounds(0, 60, 954, 512);
		contentPane.add(tabbedPane);
		
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel.setToolTipText("Add Test Case");
		tabbedPane.addTab("ADD OR UPDATE TEST CASE", null, panel, null);
		
		tabbedPane.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (!(ProceedValidations()==2)){
					tabbedPane.setSelectedIndex(0);
					
				}
			}});
		panel.setLayout(null);

		cBox_ApplicationName = new JComboBox<String>();
		cBox_ApplicationName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (rdbtn_isTC.isSelected()) FillJComboBox_Module();
					rb_NewName.setSelected(false);
					rb_SelectExisting.setSelected(false);
					rdbtn_ISTemplate.setSelected(false);
					rdbtn_isTC.setSelected(false);
					lblModID.setText("");
					lblAllottedID.setText("");
					lbl_SelectedID.setText("");
				}
				catch (Exception e1) {}
			}
		});

		final JLabel lbl_VisitSqlRep = new JLabel("");
		lbl_VisitSqlRep.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_VisitSqlRep.setBorder(new LineBorder(Color.LIGHT_GRAY));
		lbl_VisitSqlRep.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_options.png")));
		lbl_VisitSqlRep.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				createGenericDialog(5);
			}
		});
		lbl_VisitSqlRep.setBounds(806, 358, 18, 30);
		panel.add(lbl_VisitSqlRep);

		txt_refTPK = new JTextField();
		txt_refTPK.setColumns(10);
		txt_refTPK.setBounds(572, 358, 231, 30);
		panel.add(txt_refTPK);

		cBox_ApplicationName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		cBox_ApplicationName.setBorder(null);
		cBox_ApplicationName.setBounds(190, 40, 119, 30);
		panel.add(cBox_ApplicationName);
		FillAppDropDown();
		cBox_ApplicationName.setSelectedItem(Settings.getSetting("AUT", connection));

		cbox_moduleName = new JComboBox<String>();
		cbox_moduleName.setBorder(null);
		cbox_moduleName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				isNewTC = true;
				if(!(cbox_moduleName.getSelectedIndex()<=0)){
					try{
						ResetAllUIFields();
						rb_SelectExisting.setSelected(false);
						cBox_ExistingName.setEnabled(false);
						rb_NewName.setSelected(true);
						Statement st = connection.createStatement();
						//Adam SPlit Moudle ID
						String []parts = ((String)cbox_moduleName.getSelectedItem()).split("_");
						ResultSet rs = st.executeQuery("select * from MOD_SCHEDULER where MODULEID= '"+parts[0]+"'");
						while(rs.next())
						{
							moduleID = rs.getString("MODULEID");
							lblModID.setText(moduleID);
							testCaseID = GenerateAllottedTCID(2);
							lblAllottedID.setText(testCaseID);
							lbl_ModDesc2.setText(rs.getString("MODULE_DESC"));
							FillTCDropDown();
						}
					}
					catch(Exception eee)
					{
						eee.printStackTrace();
						Msgbox.msgbox("Error occured while selecting Module!");
					}
				}
			}
		});

		cbox_moduleName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		cbox_moduleName.setBounds(572, 40, 231, 30);
		panel.add(cbox_moduleName);
		FillJComboBox_Module();

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBorder(new LineBorder(Color.GRAY));
		scrollPane_1.setBounds(572, 223, 252, 124);
		panel.add(scrollPane_1);

		txt_Description = new JTextArea();
		txt_Description.setBorder(new LineBorder(Color.LIGHT_GRAY));
		scrollPane_1.setViewportView(txt_Description);
		txt_Description.setWrapStyleWord(true);
		txt_Description.setLineWrap(true);
		txt_Description.setRows(3);
		txt_Description.setForeground(Color.BLACK);
		txt_Description.setFont(new Font("Tahoma", Font.PLAIN, 11));
		txt_Description.setColumns(1);

		final JLabel btnProceed = new JLabel("PROCEED");
		btnProceed.setHorizontalAlignment(SwingConstants.CENTER);
		btnProceed.setBorder(null);
		btnProceed.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e)
			{btnProceed.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{btnProceed.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{btnProceed.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {btnProceed.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent e) {
				try {
					if (ProceedValidations()==2){
						if (!isNewTC) UpdateDM();
						tabbedPane.setSelectedIndex(1);
						tabbedPane.setEnabledAt(1, true);
						DisplayTable();
						//Bharath New Story
						FillJComboBox_Objrefs(cBox_SelectobjRef);
						FillJComboBox_Keywords(cBox_SelectKeyword);
					}
				} catch (Exception e1) {e1.printStackTrace();}
			}});
		btnProceed.setForeground(Color.WHITE);
		btnProceed.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		btnProceed.setBackground(Color.BLACK);
		btnProceed.setOpaque(true);
		btnProceed.setBounds(828, 430, 100, 30);
		panel.add(btnProceed);

		final JLabel lbl_ModName = new JLabel("Select Module");
		lbl_ModName.setForeground(Color.BLACK);
		lbl_ModName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lbl_ModName.setBounds(432, 40, 119, 30);
		panel.add(lbl_ModName);

		final JLabel lbl_ModDesc = new JLabel("Module Description");
		lbl_ModDesc.setForeground(Color.BLACK);
		lbl_ModDesc.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lbl_ModDesc.setBounds(432, 81, 155, 30);
		panel.add(lbl_ModDesc);

		lbl_ModDesc2 = new JLabel("---");
		lbl_ModDesc2.setForeground(new Color(105, 105, 105));
		lbl_ModDesc2.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lbl_ModDesc2.setBounds(572, 81, 342, 30);
		panel.add(lbl_ModDesc2);

		JLabel lbl_Descripton = new JLabel("Description");
		lbl_Descripton.setForeground(Color.BLACK);
		lbl_Descripton.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lbl_Descripton.setBounds(432, 230, 119, 30);
		panel.add(lbl_Descripton);

		lblModID = new JLabel("---");
		lblModID.setForeground(Color.BLACK);
		lblModID.setFont(new Font("Segoe UI", Font.ITALIC, 13));
		lblModID.setBounds(834, 39, 68, 30);
		panel.add(lblModID);

		lblAllottedID = new JLabel("---");
		lblAllottedID.setForeground(Color.BLACK);
		lblAllottedID.setFont(new Font("Segoe UI", Font.ITALIC, 13));
		lblAllottedID.setBounds(834, 130, 94, 30);
		panel.add(lblAllottedID);

		final JLabel lbl_TestDataRef = new JLabel("Test Data Refrence");
		lbl_TestDataRef.setForeground(Color.BLACK);
		lbl_TestDataRef.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lbl_TestDataRef.setBounds(432, 356, 155, 30);
		panel.add(lbl_TestDataRef);

		txt_NewName = new JTextField();
		txt_NewName.setBounds(572, 133, 252, 30);
		panel.add(txt_NewName);
		txt_NewName.setColumns(10);

		lbl_SelectedID = new JLabel("---");
		lbl_SelectedID.setForeground(new Color(105, 105, 105));
		lbl_SelectedID.setFont(new Font("Segoe UI", Font.ITALIC, 13));
		lbl_SelectedID.setBounds(834, 171, 94, 30);
		panel.add(lbl_SelectedID);

		cBox_ExistingName = new JComboBox<String>();
		cBox_ExistingName.setBorder(null);
		cBox_ExistingName.addItem("--Select existing--");
		cBox_ExistingName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					 if(cBox_ExistingName.getSelectedIndex()>0){

						lbl_SelectedID.setText(StringUtils.substring((String)cBox_ExistingName.getSelectedItem(), 0, 6) );
						testCaseID = lbl_SelectedID.getText();

						if (rdbtn_isTC.isSelected()){
							String query8 = "select TC_DESC from TC_SCHEDULER WHERE MODULEID = '"+lblModID.getText()+"' AND TCID = '"+testCaseID+"'";
							ResultSet rs8 = connection.prepareStatement(query8).executeQuery();
							while(rs8.next()){txt_Description.setText(rs8.getString("TC_DESC"));}
							rs8.close();

							String query = "Select DMID from DM_MAP WHERE MODULEID = '"+lblModID.getText()+"' AND TCID = '"+testCaseID+"'";
							ResultSet rs = connection.prepareStatement(query).executeQuery();
							if(rs.next()){txt_refTPK.setText(rs.getString("DMID"));}
							rs.close();
						}
						else if (rdbtn_ISTemplate.isSelected()){
							String query9 = "select TMPL_DESC from TEMPLATE_DETAILS WHERE TMPLID = '"+testCaseID+"'";
							ResultSet rs9 = connection.prepareStatement(query9).executeQuery();
							while(rs9.next()){txt_Description.setText(rs9.getString("TMPL_DESC"));}
							rs9.close();
						}
					 }
				}
				catch(Exception eee){eee.printStackTrace();}
			}
		});
		cBox_ExistingName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		cBox_ExistingName.setBounds(572, 170, 252, 30);
		panel.add(cBox_ExistingName);

		rb_NewName = new JRadioButton("   New Name");
		rb_NewName.setOpaque(false);
		rb_NewName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		rb_NewName.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent arg0) {
		 		if (rdbtn_isTC.isSelected() && moduleID.equals("0")){
			 			Msgbox.msgbox("Please select Module!");
			 			rb_NewName.setSelected(false);
			 		}
		 		else {
		 			isNewTC = true;
		 			cBox_ExistingName.setEnabled(false);
		 			rb_SelectExisting.setSelected(false);
			 		if (cBox_ExistingName.getItemCount()>0) cBox_ExistingName.setSelectedIndex(0);
			 		lbl_SelectedID.setText("");
			 		txt_refTPK.setText("");
			 		txt_Description.setText("");
			 		try {
			 			if (rdbtn_isTC.isSelected()) testCaseID = GenerateAllottedTCID(2);
			 			else testCaseID = GenerateAllottedTCID(3);
						lblAllottedID.setText(testCaseID);
					}
			 		catch (Exception e) {e.printStackTrace();}
				}

		 	}
		 });
		rb_NewName.setBackground(null);
		rb_NewName.setBounds(432, 133, 146, 30);
		panel.add(rb_NewName);

		rb_SelectExisting = new JRadioButton("   Select existing");
		rb_SelectExisting.setOpaque(false);
		rb_SelectExisting.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		rb_SelectExisting.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (rdbtn_isTC.isSelected() && moduleID.equals("0")){
		 			Msgbox.msgbox("Please select Module!");
		 			rb_SelectExisting.setSelected(false);
		 		}
				else {
					cBox_ExistingName.setEnabled(true);
					rb_NewName.setSelected(false);
					txt_NewName.setText("");
					lblAllottedID.setText("");
					txt_refTPK.setText("");
			 		txt_Description.setText("");
			 		isNewTC = false;
				}
				if (rdbtn_ISTemplate.isSelected()){
					try {
						FillTmplDropDown();
						isNewTC = false;}
					catch (Exception e1) {e1.printStackTrace();}
				}
			}
		});
		rb_SelectExisting.setBackground(null);
		rb_SelectExisting.setBounds(432, 170, 155, 30);
		panel.add(rb_SelectExisting);




	  /*############################################################################################
		############################################################################################

						ADD TEST STEPS: Next Tab starts here.

		############################################################################################
		############################################################################################*/



		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		tabbedPane.addTab("ADD OR UPDATE TEST STEPS", null, panel_1, null);
		tabbedPane.setEnabledAt(1, false);
		panel_1.setLayout(null);

/*		############################################################################################
        TEXT LABELS AND BOXES
		############################################################################################			*/

		JLabel label_12 = new JLabel("Select Object");
		label_12.setForeground(Color.BLACK);
		label_12.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		label_12.setBounds(69, 23, 105, 30);
		panel_1.add(label_12);

		JLabel label_13 = new JLabel("Select Action");
		label_13.setForeground(Color.BLACK);
		label_13.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		label_13.setBounds(69, 64, 105, 30);
		panel_1.add(label_13);

		JLabel label_15 = new JLabel("Enter Test Data Value");
		label_15.setForeground(Color.BLACK);
		label_15.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		label_15.setBounds(69, 105, 143, 30);
		panel_1.add(label_15);

		JLabel label_19 = new JLabel("");
		label_19.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				createGenericDialog(3);
			}
		});
		label_19.setHorizontalAlignment(SwingConstants.CENTER);
		label_19.setBorder(new LineBorder(Color.LIGHT_GRAY));
		label_19.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_options1.png")));

		label_19.setForeground(new Color(255, 140, 0));
		label_19.setFont(new Font("Calibri", Font.ITALIC, 12));
		label_19.setBounds(475, 105, 18, 30);
		//label_19.setBorder(arg0);
		panel_1.add(label_19);

		JLabel lblSelectApplication = new JLabel("Select Application");
		lblSelectApplication.setForeground(Color.BLACK);
		lblSelectApplication.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblSelectApplication.setBounds(50, 40, 119, 30);
		panel.add(lblSelectApplication);

		rdbtn_isTC = new JRadioButton("   TEST CASE");
		rdbtn_isTC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (rdbtn_isTC.isSelected()){
					if (rdbtn_ISTemplate.isSelected()) rdbtn_ISTemplate.setSelected(false);
					lbl_ModName.setVisible(true);
					cbox_moduleName.setVisible(true);
					lblModID.setVisible(true);
					lbl_ModDesc.setVisible(true);
					lbl_ModDesc2.setVisible(true);
					lbl_TestDataRef.setVisible(true);
					txt_refTPK.setVisible(true);
					lbl_VisitSqlRep.setVisible(true);
					lbl_VisitModules.setVisible(true);
					cBox_ExistingName.removeAllItems();
					lbl_FrameForTemplates.setVisible(false);
					lblAllottedID.setText("");
					lbl_SelectedID.setText("");
					txt_Description.setText("");
					txt_refTPK.setText("");
					txt_NewName.setText("");
			}}}
		);
		rdbtn_isTC.setSelected(true);
		rdbtn_isTC.setOpaque(false);
		rdbtn_isTC.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		rdbtn_isTC.setBackground((Color) null);
		rdbtn_isTC.setBounds(61, 149, 146, 30);
		panel.add(rdbtn_isTC);

		rdbtn_ISTemplate = new JRadioButton("   TEMPLATE");
		rdbtn_ISTemplate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (rdbtn_ISTemplate.isSelected()){
					rdbtn_isTC.setSelected(false);
					lbl_ModName.setVisible(false);
					cbox_moduleName.setVisible(false);
					lblModID.setVisible(false);
					lbl_VisitModules.setVisible(false);
					lbl_ModDesc.setVisible(false);
					lbl_ModDesc2.setVisible(false);
					lbl_TestDataRef.setVisible(false);
					txt_refTPK.setVisible(false);
					lbl_VisitSqlRep.setVisible(false);
					lbl_FrameForTemplates.setVisible(true);
					rb_NewName.setSelected(true);
					rb_SelectExisting.setSelected(false);
					lblAllottedID.setText("");
					lbl_SelectedID.setText("");
					txt_Description.setText("");
					txt_refTPK.setText("");
					txt_NewName.setText("");
					cBox_ExistingName.removeAllItems();
					testCaseID = GenerateAllottedTCID(3);
					lblAllottedID.setText(testCaseID);
				}
			}
		});
		rdbtn_ISTemplate.setOpaque(false);
		rdbtn_ISTemplate.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		rdbtn_ISTemplate.setBackground((Color) null);
		rdbtn_ISTemplate.setBounds(61, 188, 146, 30);
		panel.add(rdbtn_ISTemplate);

		JLabel lblPleaseMakeSelection = new JLabel("What do you want to develop today?");
		lblPleaseMakeSelection.setForeground(Color.BLACK);
		lblPleaseMakeSelection.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblPleaseMakeSelection.setBounds(50, 107, 245, 30);
		panel.add(lblPleaseMakeSelection);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBounds(37, 25, 298, 363);
		panel.add(lblNewLabel);

		lbl_FrameForTemplates = new JLabel("");
		lbl_FrameForTemplates.setVisible(false);
		lbl_FrameForTemplates.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		lbl_FrameForTemplates.setBounds(408, 117, 520, 246);
		panel.add(lbl_FrameForTemplates);

		lbl_VisitModules = new JLabel("");
		lbl_VisitModules.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_VisitModules.setBorder(new LineBorder(Color.LIGHT_GRAY));
		lbl_VisitModules.setBounds(806, 40, 18, 30);
		lbl_VisitModules.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_options.png")));

		lbl_VisitModules.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				createGenericDialog(6);
			}
		});
		panel.add(lbl_VisitModules);

		cBox_SelectKeyword = new JComboBox<String>();
		
		cBox_SelectKeyword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		cBox_SelectKeyword.setBounds(222, 64, 250, 30);
		panel_1.add(cBox_SelectKeyword);
		//Bharath New story
		cBox_SelectobjRef = new JComboBox<String>();
		cBox_SelectobjRef.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ResultSet rs=null;
				if(cBox_SelectobjRef.getSelectedIndex()>0){
					System.out.println(cBox_SelectobjRef.getSelectedItem().toString());
					try {
						if(table_Driver.getSelectedRow()<1)
						rs= connection.prepareStatement("SELECT TAG_TYPE FROM OBJ_REP WHERE OBJ_REF ='"+cBox_SelectobjRef.getSelectedItem().toString()+"'").executeQuery();
						System.out.println("SELECT TAG_TYPE FROM OBJ_REP WHERE OBJ_REF ='"+cBox_SelectobjRef.getSelectedItem().toString()+"'");
						if(rs.next()){
							System.out.println(rs.getString("TAG_TYPE"));
							if(rs.getString("TAG_TYPE")==null||rs.getString("TAG_TYPE").isEmpty() || rs.getString("TAG_TYPE").equals("") || rs.getString("TAG_TYPE").equalsIgnoreCase("null") || rs.getString("TAG_TYPE")==null)
								cBox_SelectKeyword.setSelectedItem("--Select Keyword--");
							else if(rs.getString("TAG_TYPE").equalsIgnoreCase("Set"))
								cBox_SelectKeyword.setSelectedItem("Set");
							else if (rs.getString("TAG_TYPE").equalsIgnoreCase("Click")) 
								cBox_SelectKeyword.setSelectedItem("Click");
							else if (rs.getString("TAG_TYPE").equalsIgnoreCase("ClickTable")) 
								cBox_SelectKeyword.setSelectedItem("ClickTable");
							else if (rs.getString("TAG_TYPE").equalsIgnoreCase("VerfyTable")) 
								cBox_SelectKeyword.setSelectedItem("VerfyTable");
							else if (rs.getString("TAG_TYPE").equalsIgnoreCase("Select")) 
								cBox_SelectKeyword.setSelectedItem("Select");
							else if (rs.getString("TAG_TYPE").equalsIgnoreCase("SelectList")) 
								cBox_SelectKeyword.setSelectedItem("SelectList");
							else if (rs.getString("TAG_TYPE").equalsIgnoreCase("VerifyList")) 
								cBox_SelectKeyword.setSelectedItem("VerifyList");
							else if (rs.getString("TAG_TYPE").equalsIgnoreCase("Verify")) 
								cBox_SelectKeyword.setSelectedItem("Verify");
							else
								cBox_SelectKeyword.setSelectedItem("--Select Keyword--");
						}
					} catch (NullPointerException e) {
						
					}
					catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		});
		cBox_SelectobjRef.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		cBox_SelectobjRef.setBounds(222, 23, 250, 30);
		
		panel_1.add(cBox_SelectobjRef);
		cBox_SelectobjRef.addItem("--Please Select--");

		txt_TextDataValue = new JTextField();
		txt_TextDataValue.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		txt_TextDataValue.setColumns(10);
		txt_TextDataValue.setBounds(222, 105, 187, 30);
		panel_1.add(txt_TextDataValue);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(22, 215, 905, 245);
		panel_1.add(scrollPane);
		table_Driver = new JTable();
		table_Driver.setDefaultEditor(Object.class, null);
		table_Driver.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					rowDrv = table_Driver.getSelectedRow();
					step_ID = Integer.parseInt((table_Driver.getModel().getValueAt(rowDrv, 0)).toString());
					row_ID  = Integer.parseInt((table_Driver.getModel().getValueAt(rowDrv, 7)).toString());
					if (rdbtn_isTC.isSelected())  		lbl_StepInfo.setText("Step ID :"+step_ID+" | MODULE ID : "+moduleID+" | TCID : "+testCaseID );
                    else  								lbl_StepInfo.setText("Step ID :"+step_ID+" | TEMPLATE ID : "+testCaseID );

					cBox_SelectKeyword.setSelectedItem((table_Driver.getModel().getValueAt(rowDrv, 1)).toString());
					
					if(((table_Driver.getModel().getValueAt(rowDrv, 2))==null) ||(table_Driver.getModel().getValueAt(rowDrv, 2)).equals(""))
						cBox_SelectobjRef.setSelectedItem("--Please Select--");
					else
						cBox_SelectobjRef.setSelectedItem((table_Driver.getModel().getValueAt(rowDrv, 2)).toString());
					
					if((table_Driver.getModel().getValueAt(rowDrv, 3))==null || (table_Driver.getModel().getValueAt(rowDrv, 3).equals("")))
						txt_TextDataValue.setText("");
					else
						txt_TextDataValue.setText((table_Driver.getModel().getValueAt(rowDrv, 3)).toString());
					
					if((table_Driver.getModel().getValueAt(rowDrv, 5))!=null)
						txt_StepDescInput.setText((table_Driver.getModel().getValueAt(rowDrv, 5)).toString());
					else
						txt_StepDescInput.setText("");
					
					chckbxScreenshot.setSelected(true);
					if(table_Driver.getModel().getValueAt(rowDrv, 6)!=null)
					if ((table_Driver.getModel().getValueAt(rowDrv, 6)).toString().equals("Y")) chckbxScreenshot.setSelected(true); else chckbxScreenshot.setSelected(false);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		table_Driver.setDragEnabled(true);
		table_Driver.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table_Driver.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_DELETE){
					try {
						DeleteTestStep();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
			    }
			}
		});
		scrollPane.setViewportView(table_Driver);

		btnAddTestStep = new JLabel("ADD STEP");
		btnAddTestStep.setOpaque(true);
		btnAddTestStep.setHorizontalAlignment(SwingConstants.CENTER);
		btnAddTestStep.setBorder(null);
		btnAddTestStep.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e)
			{btnAddTestStep.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{btnAddTestStep.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{btnAddTestStep.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {btnAddTestStep.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent e) {
				try{
					if (ValidateAddTestStepFields() == 1){
						if (isNewTC){
							if (rdbtn_isTC.isSelected()){
								insertNewTCSchedule();
								isNewTC=false;
							}
							else {
								insertNewTemplateDetails();
								isNewTC=false;
							}
						}
	                   AddTestStep();
                       DisplayTable();
                       fillRTVALDropDown();
                       ResetUIFieldsforAddingStep();

	           		/*
                       if (rdbtn_isTC.isSelected()) lbl_StepInfo.setText("Step ID :"+iNewStepId+" | MODULE ID : "+moduleID+" | TCID : "+testCaseID );
                       else  lbl_StepInfo.setText("Step ID :"+iNewStepId+" | TEMPLATE ID : "+testCaseID );*/
					} //}
               }
               catch(Exception exe){
		    	   exe.printStackTrace();
               }
			}
		});
		btnAddTestStep.setForeground(Color.WHITE);
		btnAddTestStep.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		btnAddTestStep.setBackground(new Color(0, 0, 0));
		btnAddTestStep.setBounds(854, 182, 73, 24);
		panel_1.add(btnAddTestStep);

		lbl_OBJREF_BANK = new JLabel("");
		lbl_OBJREF_BANK.setBorder(new LineBorder(Color.LIGHT_GRAY));
		lbl_OBJREF_BANK.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_OBJREF_BANK.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_options1.png")));

		lbl_OBJREF_BANK.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (cBox_SelectKeyword.getSelectedItem().toString().equals("CallTemplate")) createGenericDialog(2);
				else createGenericDialog(4);
			}});
		lbl_OBJREF_BANK.setForeground(new Color(255, 140, 0));
		lbl_OBJREF_BANK.setFont(new Font("Calibri", Font.ITALIC, 12));
		lbl_OBJREF_BANK.setBounds(475, 23, 18, 30);
		panel_1.add(lbl_OBJREF_BANK);

		JLabel btnDelete = new JLabel(" DELETE STEPS");
		btnDelete.setBackground(new Color(255, 102, 0));
		btnDelete.setForeground(new Color(255, 255, 255));
		btnDelete.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		btnDelete.setOpaque(true);
		btnDelete.setBorder(null);
		btnDelete.setToolTipText("Delete all steps within Test case body. Use Keyboard's delete control for deleting particular step.");
		btnDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
		         	try {
		         		DeleteAllSteps();
				  }catch (Exception e1) {
						e1.printStackTrace();}
			}//else
		});
		btnDelete.setBounds(770, 57, 83, 24);
		panel_1.add(btnDelete);
		
		JLabel lblDeleteTestCase = new JLabel("  DELETE");
		lblDeleteTestCase.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblDeleteTestCase.setForeground(new Color(255, 255, 255));
		lblDeleteTestCase.setBackground(new Color(255, 102, 0));
		lblDeleteTestCase.setOpaque(true);
		lblDeleteTestCase.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
                  try {
                  	DeleteEntireTestCase();  
                  	deleteFalg = 0;
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		lblDeleteTestCase.setBorder(null);
		lblDeleteTestCase.setToolTipText("Delete entire Test Case");
		lblDeleteTestCase.setBounds(706, 109, 51, 24);
		//panel_1.add(lblDeleteTestCase);
		
		JLabel btnReset = new JLabel("  NEW TC");
		btnReset.setBackground(new Color(255, 102, 0));
		btnReset.setForeground(new Color(255, 255, 255));
		btnReset.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		btnReset.setOpaque(true);
		btnReset.setToolTipText("Add new test case");
		btnReset.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				   ResetAllUIFields();
			}
		});
		btnReset.setBorder(null);
		btnReset.setBounds(874, 57, 53, 24);
		panel_1.add(btnReset);
		
		JLabel btnUpdate_1 = new JLabel(" UPDATE");
		btnUpdate_1.setOpaque(true);
		btnUpdate_1.setBackground(new Color(255, 102, 0));
		//btnUpdate_1.setToolTipText("Overwrite data on a row from below table.");
		btnUpdate_1.setToolTipText("Update step");
		//btnUpdate_1.setIcon(new ImageIcon("src\\main\\resources\\Media\\Icon_repair.png"));
		btnUpdate_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {UpdatetestStep();} 
				catch (Exception e1) {e1.printStackTrace();}
			}
		});
		btnUpdate_1.setForeground(Color.WHITE);
		btnUpdate_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		btnUpdate_1.setBorder(null);
		btnUpdate_1.setBounds(697, 57, 53, 24);
		panel_1.add(btnUpdate_1);
		
		lbl_StepInfo = new JLabel("");
        lbl_StepInfo.setBounds(634, 37, 320, 14);
        contentPane.add(lbl_StepInfo);
		
		JLabel lblRun = new JLabel("RUN ");
		lblRun.setToolTipText("Execute current prepared script");
		lblRun.setOpaque(true);
		lblRun.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					 int action = JOptionPane.showConfirmDialog(null, "Are you sure you want to proceed with Execution", "CONFIRMATION",JOptionPane.YES_NO_OPTION );
						if(action ==0){
							connection.createStatement().executeUpdate("Update Settings Set VALUE = '"+(String)cBox_ApplicationName.getSelectedItem()+"' where SKEY = 'AUT'");
							DriverLib driver = new DriverLib();
							if (rdbtn_isTC.isSelected())  driver.Drive_REGR(3, moduleID, testCaseID);
							else Msgbox.msgbox("A Template can only playback when it is associated with a test case."); 								
						}
				} catch (Exception e1) {e1.printStackTrace();}
			}
		});
		lblRun.setHorizontalAlignment(SwingConstants.CENTER);
		lblRun.setForeground(new Color(255, 255, 255));
		lblRun.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblRun.setBorder(null);
		lblRun.setBackground(new Color(255, 102, 0));
		lblRun.setBounds(785, 105, 53, 24);
		panel_1.add(lblRun);
		
		JLabel lblRec = new JLabel("Rec");
		lblRec.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
			}
		});
		lblRec.setBounds(760, 105, 28, 28);

		JLabel label_3_1 = new JLabel("");
		label_3_1.setBackground(Color.WHITE);
		label_3_1.setOpaque(true);
		label_3_1.setBounds(749, 29, 200, 52);
		panel_1.add(label_3_1);

		JLabel label_3 = new JLabel("");
		label_3.setOpaque(true);
		label_3.setBackground(Color.WHITE);
		label_3.setBounds(749, 92, 200, 52);
		panel_1.add(label_3);

		JLabel ctrl_Keywords = new JLabel("");
		ctrl_Keywords.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
							createGenericDialog(1);
			}
		});
		ctrl_Keywords.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_options.png")));

		ctrl_Keywords.setHorizontalAlignment(SwingConstants.CENTER);
		ctrl_Keywords.setForeground(new Color(255, 140, 0));
		ctrl_Keywords.setFont(new Font("Calibri", Font.ITALIC, 12));
		ctrl_Keywords.setBorder(new LineBorder(Color.LIGHT_GRAY));
		ctrl_Keywords.setBounds(475, 64, 18, 30);
		panel_1.add(ctrl_Keywords);

		chckbxScreenshot = new JCheckBox("  Screenshot");
		chckbxScreenshot.setOpaque(false);
		chckbxScreenshot.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		chckbxScreenshot.setBounds(511, 151, 135, 23);
		panel_1.add(chckbxScreenshot);

		txt_StepDescInput = new JTextField();
		txt_StepDescInput.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		txt_StepDescInput.setColumns(10);
		txt_StepDescInput.setBounds(222, 146, 271, 30);
		panel_1.add(txt_StepDescInput);

		JLabel lblEnterStepDescription = new JLabel("Enter Step Description");
		lblEnterStepDescription.setForeground(Color.BLACK);
		lblEnterStepDescription.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblEnterStepDescription.setBounds(69, 146, 143, 30);
		panel_1.add(lblEnterStepDescription);

		cBox_RTVAL = new JComboBox<String>();
		cBox_RTVAL.setBorder(null);
		cBox_RTVAL.setBounds(412, 105, 60, 30);
		panel_1.add(cBox_RTVAL);
		cBox_RTVAL.addItem("---");
		fillRTVALDropDown();

		JLabel lbl_BG2 = new JLabel("");
		lbl_BG2.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "white1.jpg")));

		lbl_BG2.setBounds(0, 30, 954, 531);
		contentPane.add(lbl_BG2);

		JLabel lblBack = new JLabel();
		lblBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					connection.close();
					dispose();
					UI_Frame_Dashboard objdshbrd = new UI_Frame_Dashboard();
					objdshbrd.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		lblBack.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "icon_back.png")));

		lblBack.setBounds(0, 0, 40, 30);
		lblBack.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblBack);

		JLabel lbl_Header = new JLabel("TEST CASE OR TEMPLATE DEVELOPER");
		lbl_Header.setOpaque(true);
		lbl_Header.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Header.setForeground(Color.WHITE);
		lbl_Header.setFont(new Font("Calibri", Font.PLAIN, 18));
		lbl_Header.setBackground(new Color(0, 0, 0));
		lbl_Header.setBounds(0, 0, 954, 30);
		contentPane.add(lbl_Header);

		JLabel lblKWHelp = new JLabel("");
		lblKWHelp.setBounds(926, 0, 28, 30);
		contentPane.add(lblKWHelp);
		lblKWHelp.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "icon_what2.png")));
	}

	//############################################################################################
	//############################################################################################
	//
	//                     SUPPORTING METHODS LIBRARY BEGINS HERE
	//
	//############################################################################################
	//############################################################################################

	public void fillRTVALDropDown(){
		cBox_RTVAL.removeAllItems();
		cBox_RTVAL.addItem("---");
		try {
			for (int t = 1;t<10;t++){
				ResultSet rs1 = connection.createStatement().executeQuery("Select 1 from Driver where RTVAL_REF = '"+"RTVAL"+t+"' and ModuleID = '"+moduleID+"' and TCID = '"+testCaseID+"'");
				if (!rs1.next()) cBox_RTVAL.addItem("RTVAL"+t);
			}
		} catch (SQLException e) {e.printStackTrace();;}
	}

	public void FillAppDropDown() {
		try {
			ResultSet rs1 = connection.createStatement().executeQuery("Select distinct application from Env");
			while(rs1.next()){cBox_ApplicationName.addItem(rs1.getString("application"));}
		} catch (SQLException e) {}
	}

	public void FillJComboBox_Module() {
		cbox_moduleName.removeAllItems();
		cbox_moduleName.addItem("--Select Module Name--");
		try {
			//Adam Passing Module ID along with Name
			ResultSet rs1 = connection.createStatement()
					.executeQuery("Select MODULEID, MODULE_NAME from MOD_SCHEDULER where APPLICATION = '"+ cBox_ApplicationName.getSelectedItem() + "' order by MODULEID");
			while(rs1.next()){
				cbox_moduleName.addItem(rs1.getString("MODULEID") + "_" + rs1.getString("MODULE_NAME"));
			}
			rs1.close();
		} catch (SQLException e) {e.printStackTrace();;}
	}

	public void fillObjDropDown(){
		cBox_SelectobjRef.removeAllItems();
		try {
			ResultSet rs = connection.createStatement().executeQuery("SELECT OBJ_REF FROM OBJ_REP WHERE TAG_TYPE = '"+(String)cBox_SelectKeyword.getSelectedItem()+"' and APPLICATION = '"+cBox_ApplicationName.getSelectedItem()+"'");
			while(rs.next()){
				cBox_SelectobjRef.addItem(rs.getString("OBJ_REF"));
			}
		} catch (SQLException e) {e.printStackTrace();}
	}

	public void fillObjDropDownWithTemplateID(){
		cBox_SelectobjRef.removeAllItems();
		try {
			ResultSet rs = connection.createStatement().executeQuery("SELECT DISTINCT OBJ_REF FROM DRIVER WHERE OBJ_REF LIKE'TM%' AND MODULEID ='"+lblModID.getText()+"' AND APPLICATION ='"+cBox_ApplicationName.getSelectedItem()+"'");
			while(rs.next()){
				cBox_SelectobjRef.addItem(rs.getString("OBJ_REF"));
			}
		} catch (SQLException e) {e.printStackTrace();}
	}

	public void FillTCDropDown() {
		cBox_ExistingName.removeAllItems();
		cBox_ExistingName.addItem("--Select Test Case--");
		try {
			ResultSet rs1 = connection.createStatement().executeQuery("SELECT TCID, TC_NAME  FROM TC_SCHEDULER WHERE MODULEID = '"+lblModID.getText()+"' and Application = '"+cBox_ApplicationName.getSelectedItem()+"'");
			while(rs1.next()){
				cBox_ExistingName.addItem(rs1.getString("TCID")+"_"+rs1.getString("TC_NAME"));
			}
		} catch (SQLException e) {System.out.println("################## FAILURE! FillTCDropDown failed!");}
	}

	public void FillTmplDropDown() {
		cBox_ExistingName.removeAllItems();
		cBox_ExistingName.addItem("--Select Template--");
		try{
			ResultSet rs1 = connection.createStatement().executeQuery("SELECT TMPLID, TMPL_NAME  FROM TEMPLATE_DETAILS WHERE Application LIKE '"+cBox_ApplicationName.getSelectedItem()+"' order by TMPLID");
			while(rs1.next()){
				cBox_ExistingName.addItem(rs1.getString("TMPLID")+"_"+rs1.getString("TMPL_NAME"));
			}
		} catch (SQLException e) {System.out.println("################## FAILURE! FillTmplDropDown failed!");}
	}

	public void FillJComboBox_Keywords(JComboBox<String> comboBoxK)
	{
		try{
			ResultSet rs = connection.prepareStatement("Select DISTINCT KEYWORD from KEYWORDS where KW_TYPE_ID IN (1,2) order by KEYWORD").executeQuery();
			comboBoxK.addItem("--Select Keyword--");
			while(rs.next()){
				comboBoxK.addItem(rs.getString("KEYWORD"));
			}
			rs.close();
		} catch (SQLException e) {e.printStackTrace();System.out.println("################## FAILURE! FillJComboBox_Keywords failed!");}
	}
	//Bharath New Story
	public void FillJComboBox_Objrefs(JComboBox<String> comboBoxK)
	{
		String query="SELECT DISTINCT OBJ_REF FROM DRIVER WHERE APPLICATION = '"+cBox_ApplicationName.getSelectedItem()+"'";
		try{
			if (!rdbtn_isTC.isSelected()) 	query = "SELECT OBJ_REF FROM TEMPLATES WHERE TMPLID = '"+testCaseID+"'";
			ResultSet rs = connection.prepareStatement(query).executeQuery();
			while(rs.next()){
				if(rs.getString("OBJ_REF")!=null)
					if(!rs.getString("OBJ_REF").equals("") && !rs.getString("OBJ_REF").equalsIgnoreCase("NA")  && !rs.getString("OBJ_REF").equalsIgnoreCase("NULL"))
						cBox_SelectobjRef.addItem(rs.getString("OBJ_REF"));
			}
			rs.close();
		} catch (SQLException e) {e.printStackTrace();System.out.println("################## FAILURE! FillJComboBox_Objrefs failed!");}
	}

	public void UpdateDM (){
		try {connection.createStatement().executeUpdate("Update DM_MAP Set DMID = '"+txt_refTPK.getText()+"' where ModuleID = '"+moduleID+"' and TCID = '"+testCaseID+"'");}
		catch (SQLException e) {e.printStackTrace();}
	}

	public void insertNewTCSchedule()  {
		try {
			connection.createStatement().executeUpdate("INSERT INTO TC_SCHEDULER (MODULEID, TCID, TC_NAME, TC_DESC, EXEC_FLAG, APPLICATION) VALUES ('"+moduleID+"', '"+testCaseID+"', '"+txt_NewName.getText()+ "', '"+txt_Description.getText()+"', 'NO', '"+cBox_ApplicationName.getSelectedItem()+"') ");
			connection.createStatement().executeUpdate("INSERT INTO DM_MAP (DM_MAP_ID, MODULEID, TCID, DMID) VALUES ('"+GenerateAllottedTCID(4)+"', '"+moduleID+"', '"+testCaseID+"', '"+txt_refTPK.getText()+ "') ");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void insertNewTemplateDetails()  {
		String tc_query1 = "INSERT INTO TEMPLATE_DETAILS (TMPLID, TMPL_NAME, TMPL_DESC, APPLICATION) VALUES ('"+testCaseID+"', '"+txt_NewName.getText()+ "', '"+txt_Description.getText()+"', '"+cBox_ApplicationName.getSelectedItem()+"') ";
	    try{ connection.prepareStatement(tc_query1).execute();}
	    catch (SQLException e) {System.out.println("################## FAILURE! insertNewTemplateDetails failed!");}
	}

	public String GenerateAllottedTCID(int iIDType) //	idType = 1 for DMID
													//	idType = 2 for TCID
													//	idType = 3 for TMPLID
													//	idType = 4 for DMMAPID
	{
		String allotedTCID = null; String query = null; String prefix = null;

		if (iIDType == 1)		{prefix = "DM"; 	query = "SELECT MAX(SQLID) AS MAXX FROM SQLS WHERE SQLID like 'DM%'";}
		else if (iIDType == 2) 	{prefix = "TC"; 	query = "SELECT MAX(TCID) AS MAXX FROM TC_SCHEDULER WHERE MODULEID = '"+moduleID+"' and application = '"+cBox_ApplicationName.getSelectedItem()+"'";}
		else if (iIDType == 3)	{prefix = "TM"; 	query = "SELECT MAX(TMPLID) AS MAXX FROM TEMPLATES WHERE TMPLID LIKE 'TM%'";}
		else if (iIDType == 4)	{prefix = "DP"; 	query = "SELECT MAX(DM_MAP_ID) AS MAXX FROM DM_MAP WHERE DM_MAP_ID LIKE 'DP%'";}

		try{
			System.out.println(query);
			ResultSet rs05 = connection.createStatement().executeQuery(query);
			while (rs05.next()){
				allotedTCID = rs05.getString("MAXX");

			int fin;
			if(allotedTCID == null) allotedTCID = prefix + "0001";
			else {
				fin = Integer.parseInt(allotedTCID.substring(2))+1;
				int length = (int)(Math.log10(fin)+1);
				allotedTCID = allotedTCID.substring(0,6-length)+fin;
			}
			}
			rs05.close();

		} catch (SQLException e) {e.printStackTrace();System.out.println("################## FAILURE! GenerateAllotted"+prefix+"failed!");}
		return allotedTCID;
	}

	public void DeleteTestStep(){
		String query8;
		   int action = JOptionPane.showConfirmDialog(null, "Are you sure you want to Delete this step?", "CONFIRMATION",JOptionPane.YES_NO_OPTION );
		   if(action ==0)
		   {
			   try{
				   if (rdbtn_isTC.isSelected()) 	query8 = "Delete from DRIVER where DRV_REC_ID = '"+row_ID+"'";
				   else 								query8 = "Delete from TEMPLATES where TMP_REC_ID = '"+row_ID+"'";

				   connection.createStatement().executeUpdate(query8);
			       RearrangeSteps();
			       DisplayTable();
			       fillRTVALDropDown();
			   }
			   catch (SQLException e) {System.out.println("################## FAILURE! DeleteTestStep() failed!");}
		   }
	}

	public void DeleteAllSteps(){
		String query8;
		 if (ProceedValidations() == 2){
			   int action = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete all the steps?", "CONFIRMATION",JOptionPane.YES_NO_OPTION );
			   if(action ==0){
				   try {
					   if (rdbtn_isTC.isSelected()) 	query8 = "Delete from DRIVER where MODULEID = '"+moduleID+"' and TCID = '"+testCaseID+"' and application = '"+cBox_ApplicationName.getSelectedItem()+"'";
					   else 								query8 = "Delete from TEMPLATES where TMPLID = '"+testCaseID+"'";
					   connection.createStatement().executeUpdate(query8);
					   DisplayTable();
					   fillRTVALDropDown();
					   JOptionPane.showMessageDialog(null, "Deleted Test steps successfully");
				   }
				   catch (SQLException e1) {System.out.println("################## FAILURE! Delete unsucessful!");}
			   }
		 }
	}

	public void DeleteEntireTestCase()
	{
		   int action = JOptionPane.showConfirmDialog(null, "Are you sure you want to Delete entirely?", "CONFIRMATION",JOptionPane.YES_NO_OPTION );
		   if(action ==0)
		   {
			   try {
				Statement st01 = connection.createStatement();

				   if (rdbtn_isTC.isSelected()){
				       st01.executeUpdate("Delete from DM_MAP where MODULEID = '"+moduleID+"' and TCID = '"+testCaseID+"'");
				       st01.executeUpdate("Delete from TC_SCHEDULER where MODULEID = '"+moduleID+"' and TCID = '"+testCaseID+"' and application = '"+cBox_ApplicationName.getSelectedItem()+"'");
				       st01.executeUpdate("Delete from DRIVER where MODULEID = '"+moduleID+"' and TCID = '"+testCaseID+"' and application = '"+cBox_ApplicationName.getSelectedItem()+"'");
				       FillTCDropDown();
				   }
				   else{
					   st01.executeUpdate("Delete from TEMPLATES where TMPLID = '"+testCaseID+"'");
					   st01.executeUpdate("Delete from TEMPLATE_DETAILS where TMPLID = '"+testCaseID+"'");
					   FillTmplDropDown();
				   }
			   } catch (Exception e) {System.out.println("################## FAILURE! Delete unsucessful!");}

			   DisplayTable();
	           ResetAllUIFields();
	           Msgbox.msgbox("Test Case/Template Deleted Sucessfully");
		   }
	}

	public int GetNewStepId() {
		int NewStepId = 0; String query;
		if (rdbtn_isTC.isSelected())  query = "SELECT COUNT(1) AS COUNT from DRIVER where MODULEID = '"+moduleID+"' AND TCID ='"+testCaseID+"' ";
		else 								query = "SELECT COUNT(1) AS COUNT from TEMPLATES where TMPLID ='"+testCaseID+"' ";

        try {
			ResultSet rs11 = connection.createStatement().executeQuery(query);
			while (rs11.next()){
				NewStepId = Integer.parseInt(rs11.getString("COUNT")) + 1;
			}
		} catch (Exception e) {System.out.println("################## FAILURE! New Step ID cant be generated by GetNewStepId()");}
        return NewStepId;
	}

	public void AddTestStep() {
		String query1; String sScrSht="N"; String sRTVal = "''";String txt_stepDesc = txt_StepDescInput.getText(); String txt_stepData = ((String)txt_TextDataValue.getText());
		String txt_ObjRef = (String)cBox_SelectobjRef.getSelectedItem();
		if (table_Driver.getRowCount()==0) iNewStepId = 1;
		else {
			if	(rowDrv==-1)	iNewStepId = GetNewStepId();
			else 				iNewStepId = step_ID;
		}

		if (chckbxScreenshot.isSelected()) sScrSht = "Y";
		if (cBox_RTVAL.getSelectedIndex()>0) sRTVal = "'"+cBox_RTVAL.getSelectedItem().toString()+"'";

		if(txt_StepDescInput.getText().contains("'"))
    		txt_stepDesc= txt_StepDescInput.getText().replaceAll("'", "''");
		if(txt_ObjRef.contains("'"))
			txt_ObjRef= txt_ObjRef.replaceAll("'", "''");

    	if(((String)txt_TextDataValue.getText()).contains("'"))
    		txt_stepData= ((String)txt_TextDataValue.getText()).replaceAll("'", "''");

    	System.out.println("Add Step "+txt_ObjRef);

    	if(txt_ObjRef.equals("--Please Select--"))txt_ObjRef="NA";

		query1 = "insert into DRIVER (STEPID, KEYWORD, OBJ_REF, DATA_REF, RTVAL_REF, DRV_REC_ID, APPLICATION, MODULEID, TCID, SCREENSHOT, STEP_DESC) values ('"+iNewStepId+"', '"+(String)cBox_SelectKeyword.getSelectedItem()+"','"+txt_ObjRef+"', '"+txt_stepData+"', "+sRTVal+", '"+GetNewRecID()+"', '"+(String)cBox_ApplicationName.getSelectedItem()+"', '"+moduleID+"', '"+testCaseID+"' , '"+sScrSht+"', '"+txt_stepDesc+"') ";
		if (!rdbtn_isTC.isSelected())  query1 = "insert into TEMPLATES (STEPID, KEYWORD, OBJ_REF, DATA_REF, RTVAL_REF, TMP_REC_ID, TMPLID, SCREENSHOT, STEP_DESC) values ('"+iNewStepId+"', '"+(String)cBox_SelectKeyword.getSelectedItem()+"','"+txt_ObjRef+"', '"+txt_stepData+"', "+sRTVal+", '"+GetNewRecID()+"', '"+testCaseID+"', '"+sScrSht+"', '"+txt_stepDesc+"') ";
		System.out.println("Insert Query used: "+query1);
		try {connection.createStatement().executeUpdate(query1);} catch (SQLException e) {e.printStackTrace();}

		int iKW = getKeywordType();
		if (iKW==1 || (iKW==0 && cBox_SelectobjRef.getSelectedIndex()>0) || cBox_SelectKeyword.getSelectedItem().toString().equalsIgnoreCase("CallTemplate")){
			query1 = "Update Driver Set OBJ_REF = '"+txt_ObjRef+"' where application = '"+(String)cBox_ApplicationName.getSelectedItem()+"' and moduleID = '"+moduleID+"' and TCID = '"+testCaseID+"' and StepID ="+iNewStepId;
			if (!rdbtn_isTC.isSelected())  query1 = "Update TEMPLATES Set OBJ_REF = '"+txt_ObjRef+"' where TMPLID = '"+testCaseID+"' and StepID = "+iNewStepId;
			System.out.println("Update Query used: "+query1);
			try {connection.createStatement().executeUpdate(query1);} catch (SQLException e) {e.printStackTrace();}
		}

		rowDrv = -1;

	   RearrangeSteps();
	   System.out.println("New step (stepID = "+iNewStepId+") added successfully");
	}

	public int GetNewRecID(){
		int i = 0; String query;
		if (rdbtn_isTC.isSelected())  query = "Select max(DRV_REC_ID) AS MD from DRIVER";
		else 								query = "Select max(TMP_REC_ID) AS MD from TEMPLATES";
		try {
			ResultSet rs = connection.createStatement().executeQuery(query);
			while (rs.next()){
				i = rs.getInt("MD")+1;
			}
		} catch (SQLException e) {System.out.println("##################### Failure! New Rec ID cant be generated by GetNewRecID()");}
		return i;
	}

	public void UpdatetestStep()
	{
		String query1; String sScrSht="N";  String sRTVal = "''";String txt_stepDesc = txt_StepDescInput.getText(); String txt_stepData = ((String)txt_TextDataValue.getText());
		String txt_ObjRef = (String)cBox_SelectobjRef.getSelectedItem();
		if (!(rowDrv == -1)){
			if (ValidateAddTestStepFields()==1){
				if(chckbxScreenshot.isSelected()) sScrSht = "Y";
				int action = JOptionPane.showConfirmDialog(null, "You are attempting an update to step : "+ step_ID, "CONFIRMATION",JOptionPane.YES_NO_OPTION );
	            if(action ==0){
	            	if (cBox_RTVAL.getSelectedIndex()>0) sRTVal = "'"+cBox_RTVAL.getSelectedItem().toString()+"'";

	            	if(txt_StepDescInput.getText().contains("'"))
	            		txt_stepDesc= txt_StepDescInput.getText().replaceAll("'", "''");

	            	if(((String)txt_TextDataValue.getText()).contains("'"))
	            		txt_stepData= ((String)txt_TextDataValue.getText()).replaceAll("'", "''");

	            	if(txt_ObjRef.contains("'"))
	            		txt_ObjRef= txt_ObjRef.replaceAll("'", "''");
	            	System.out.println("KEYWORD NAME " +txt_ObjRef);

	            	if(txt_ObjRef.equals("--Please Select--")) txt_ObjRef="NA";
	            	query1 = "UPDATE DRIVER SET KEYWORD='"+(String)cBox_SelectKeyword.getSelectedItem()+"',OBJ_REF='"+txt_ObjRef+"', RTVAL_REF = "+sRTVal+", DATA_REF = '"+txt_stepData+"', STEP_DESC = '"+txt_stepDesc+"', SCREENSHOT = '"+sScrSht+"' where DRV_REC_ID = "+row_ID;
	        		if (!rdbtn_isTC.isSelected()) query1 = "UPDATE TEMPLATES SET KEYWORD='"+(String)cBox_SelectKeyword.getSelectedItem()+"', OBJ_REF='"+txt_ObjRef+"', DATA_REF = '"+txt_stepData+"', STEP_DESC = '"+txt_stepDesc+"', SCREENSHOT = '"+sScrSht+"' where TMP_REC_ID = "+row_ID;
	        		try {connection.createStatement().executeUpdate(query1);} catch (SQLException e) {System.out.println(e.getMessage());}

	        		//BHARATH --> BELOW CODE IS NOT REQUIRED. HERE YOU ARE OVERRIDING THE VALUES
	        		/*iKW = getKeywordType();
	        		if (iKW==1 || (iKW==0 && cBox_SelectobjRef.getSelectedIndex()>0) || cBox_SelectKeyword.getSelectedItem().toString().equalsIgnoreCase("CallTemplate")){        			query1 = "UPDATE DRIVER SET KEYWORD='"+(String)cBox_SelectKeyword.getSelectedItem()+"', OBJ_REF='"+(String)cBox_SelectobjRef.getSelectedItem()+"', DATA_REF = '"+txt_stepData+"', STEP_DESC = '"+txt_stepDesc+"', SCREENSHOT = '"+sScrSht+"' where DRV_REC_ID = "+row_ID;
	        			query1 = "UPDATE DRIVER SET OBJ_REF= '"+(String)cBox_SelectobjRef.getSelectedItem()+"' where DRV_REC_ID = "+row_ID;
		            	if(!rdbtn_isTC.isSelected()) query1 = "UPDATE TEMPLATES SET OBJ_REF='"+(String)cBox_SelectobjRef.getSelectedItem()+"' where TMP_REC_ID = "+row_ID;
		            	try {connection.createStatement().executeUpdate(query1);}
		        		catch (SQLException e) {System.out.println(e.getMessage());}
	        		}*/
	        		System.out.println("QUERY "+query1);
		            DisplayTable();
		      		ResetUIFieldsforAddingStep();
		      		rowDrv = -1;
	            }
			}
		}
		else Msgbox.msgbox("Please select a row to update!");
    }

	public void ResetAllUIFields(){
			//Raised a flag  for getting the moduleId Label in another Method
			if(deleteFalg!=0){	        lblModID.setText("");        lbl_ModDesc2.setText(""); }
	        lblAllottedID.setText("");
	        lbl_SelectedID.setText("");
	        lbl_StepInfo.setText("");
	        if (cBox_ExistingName.getSelectedIndex()>0) cBox_ExistingName.setSelectedIndex(0);
	        txt_NewName.setText("");
	        txt_Description.setText("");
	        txt_refTPK.setText("");
	        if (cBox_SelectKeyword.getSelectedIndex()>0)    cBox_SelectKeyword.setSelectedIndex(0);
	        if (cBox_SelectobjRef.getSelectedIndex()>0 )    cBox_SelectobjRef.setSelectedIndex(0);
	        txt_TextDataValue.setText("");
	        DefaultTableModel model = (DefaultTableModel) table_Driver.getModel();
	        model.setRowCount(0);
	        tabbedPane.setSelectedIndex(0);
	}

	public void ResetUIFieldsforAddingStep(){
		   cBox_SelectKeyword.setSelectedIndex(0);
		   cBox_SelectobjRef.setSelectedIndex(0);
		   txt_TextDataValue.setText("");
		   txt_StepDescInput.setText("");
		   chckbxScreenshot.setSelected(false);
	}

	public int ValidateAddTestStepFields(){
	int iFlag = 0;

		if(rdbtn_isTC.isSelected() & cbox_moduleName.getSelectedIndex()==0)
			   Msgbox.msgbox("Please select Module Name");
		else {
			if (rb_NewName.isSelected() & txt_NewName.getText().equals(""))
				Msgbox.msgbox("Please enter Test Case Name");
			else if (rb_SelectExisting.isSelected() & cBox_ExistingName.getSelectedIndex()<1)
			   Msgbox.msgbox("Please select Test Case from Dropdown");
			else if (cBox_SelectKeyword.getSelectedIndex() == 0)
			  	Msgbox.msgbox("Please select a Keyword");
			else if (getKeywordType()==1 & cBox_SelectobjRef.getSelectedIndex() == 0 )
				Msgbox.msgbox("Please select an Object Refernce");
			else if (txt_TextDataValue.getText().equals(""))
			   Msgbox.msgbox("Please enter Test Data Value");
			else iFlag = 1;
		}
		return iFlag;
	}

	public int ProceedValidations() {
		int iFlag = 0;

		if (rdbtn_isTC.isSelected() && cbox_moduleName.getSelectedIndex()==0){
			 Msgbox.msgbox("Please select Module!");
		}
		else iFlag = 1;

		if (iFlag == 1){
			if (rb_NewName.isSelected()){
				if (txt_NewName.getText().equals("")){
					Msgbox.msgbox("Please enter Name of the New Testcase/Template!");
				}
				else {
					if (txt_Description.getText().equals("")){
						Msgbox.msgbox("Please enter Description of the New Testcase/Template!");
					}
					else iFlag = 3;
				}
			}
			else if (rb_SelectExisting.isSelected()){
				if (cBox_ExistingName.getSelectedIndex()==0){
					Msgbox.msgbox("Please make a selection from the dropdown!");
				}
				else {iFlag = 3;}
			}
		}
		if (iFlag == 3){
			if (rdbtn_isTC.isSelected()){
				if (txt_refTPK.getText().equals("")){
					Msgbox.msgbox("Please enter a DMID. If DM Query is not applicable enter 'NA'.");
				}
				else if (txt_refTPK.getText().toUpperCase().equals("NA")){
					iFlag = 2;
				}
				else if (!txt_refTPK.getText().toUpperCase().startsWith("DM")){
					Msgbox.msgbox("Please enter a DMID. If DM Query is not applicable enter 'NA'.");
				}
				else if (!ValidateDMID()){
					Msgbox.msgbox("Incorrect DMID entered. Please use the control to the right of Test Data Reference box to get the correct DMID");
				}
				else iFlag = 2;
			}
			else iFlag = 2;
		}
		return iFlag;
	}

	public void RearrangeSteps(){
		String query;
		if (rdbtn_isTC.isSelected()) query = "select DRV_REC_ID, STEPID from DRIVER WHERE MODULEID = '"+moduleID+"' AND TCID = '"+testCaseID+"' ORDER BY STEPID, DRV_REC_ID";
	   	else 						 query = "select TMP_REC_ID, STEPID from TEMPLATES WHERE TMPLID = '"+testCaseID+"' ORDER BY STEPID, TMP_REC_ID";

		try {
			ResultSet rs02 = connection.createStatement().executeQuery(query);
			   int iStepCount = 1;
			   while (rs02.next()){
				  int irowID = rs02.getInt(1);
				  if (rdbtn_isTC.isSelected())  connection.createStatement().executeUpdate("Update Driver set STEPID = '"+iStepCount+"' where DRV_REC_ID = "+irowID +" and MODULEID = '"+moduleID+"' AND TCID = '"+testCaseID+"'");
				  else 							connection.createStatement().executeUpdate("Update TEMPLATES set STEPID = '"+iStepCount+"' where TMP_REC_ID = "+irowID +" and TMPLID = '"+testCaseID+"'");
				  iStepCount = iStepCount + 1;
			   }
		} catch (Exception e) {System.out.println("################## FAILURE! Steps cant be rearranged by RearrangeSteps()!");}
	}

	public void DisplayTable() {

		RearrangeSteps();
		String query;
	   	if (rdbtn_isTC.isSelected())  query = "Select STEPID, KEYWORD, OBJ_REF, DATA_REF, RTVAL_REF, STEP_DESC, SCREENSHOT, DRV_REC_ID as ROWID  from Driver where MODULEID LIKE '"+moduleID+"' AND  TCID  = '"+testCaseID+"' ORDER BY STEPID";
	   	else 								query = "Select STEPID, KEYWORD, OBJ_REF, DATA_REF, RTVAL_REF, STEP_DESC, SCREENSHOT, TMP_REC_ID as ROWID  from Templates where TMPLID  = '"+testCaseID+"' ORDER BY STEPID";
	   	try {
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table_Driver.setModel(DbUtils.resultSetToTableModel(rs));//917
			table_Driver.getColumnModel().getColumn(0).setPreferredWidth(70);
			table_Driver.getColumnModel().getColumn(1).setPreferredWidth(90);
			table_Driver.getColumnModel().getColumn(2).setPreferredWidth(160);
			table_Driver.getColumnModel().getColumn(3).setPreferredWidth(160);
			table_Driver.getColumnModel().getColumn(4).setPreferredWidth(70);
			table_Driver.getColumnModel().getColumn(5).setPreferredWidth(330);
			table_Driver.getColumnModel().getColumn(6).setMinWidth(0);

			table_Driver.getColumnModel().getColumn(7).setMinWidth(0);
			table_Driver.getColumnModel().getColumn(7).setMaxWidth(0);
			//table_Driver.removeColumn(table_Driver.getColumnModel().getColumn(5));

			/*Can Use Below Statement as well to Hide the Column from Driver Table.
			 * table_Driver.getColumnModel().getColumn(5).setWidth(0);
			table_Driver.getColumnModel().getColumn(5).setMinWidth(0);
			table_Driver.getColumnModel().getColumn(5).setMaxWidth(0);*/
   pst.close();
   rs.close();
		} catch (SQLException e) {System.out.println("################ Failure! Table cant be displayed by DisplayTable()");}

	 RefreshLabel();
	}

	public void RefreshLabel() {
		if (rdbtn_isTC.isSelected()){
			if (rowDrv==-1) 	lbl_StepInfo.setText("Step id : 1 | MODULE ID : "+moduleID+" | TCID : "+testCaseID);
			else 		lbl_StepInfo.setText("Step id : "+GetNewStepId()		+" | MODULE ID : "+moduleID+" | TCID : "+testCaseID);
		}
		else {
			if (rowDrv==0) 	lbl_StepInfo.setText("Step id : 1 | TEMPLATE ID : "+testCaseID);
			else 		lbl_StepInfo.setText("Step id : "+GetNewStepId()		+" | TEMPLATE ID : "+testCaseID);
		}
	}

	public void DisplayObjectRepository(){
		try {
			ResultSet rs = connection.prepareStatement("select TAG_TYPE, OBJ_REF, Title, id, name, linkText, xpath from OBJ_REP where APPLICATION = '"+cBox_ApplicationName.getSelectedItem().toString()+"'").executeQuery();
			//DI
//			table_OR.setDefaultEditor(Object.class, null);
            table_OR.setModel(DbUtils.resultSetToTableModel(rs));
            table_OR.removeColumn(table_OR.getColumnModel().getColumn(0));
		} catch (Exception ex) {ex.printStackTrace();}
	}

	public void DisplayTMPLRepository(){
		try {
			ResultSet rs = connection.prepareStatement("select * from TEMPLATE_DETAILS").executeQuery();
            table_OR.setModel(DbUtils.resultSetToTableModel(rs));
		} catch (Exception ex) {ex.printStackTrace();}
	}


	public void updateDMSQLsTable(){
		try{
			ResultSet rs8 = connection.createStatement().executeQuery("SELECT SQLID AS DMID, ESQL FROM SQLS WHERE SQLID LIKE 'DM%' and application = '"+cBox_ApplicationName.getSelectedItem().toString()+"'");
			table_Sql.setModel(DbUtils.resultSetToTableModel(rs8));
		}
		catch(Exception etc){
			etc.printStackTrace();
		}
	}

	public boolean ValidateDMID(){
		boolean b = false;
		try{
			ResultSet rs8 = connection.createStatement().executeQuery("SELECT SQLID from SQLS WHERE SQLID = '"+txt_refTPK.getText()+"'");
			if (rs8.next()) if (rs8.getString("SQLID").equals(txt_refTPK.getText())) b = true;
		}
		catch(Exception etc){
			etc.printStackTrace();
		}
		return b;
	}

	public int getKeywordType(){
		int sKWTypeID = 10;
		try {
			ResultSet rs8 = connection.createStatement().executeQuery("SELECT COUNT(KW_TYPE_ID) AS CNT from KEYWORDS WHERE KEYWORD = '"+cBox_SelectKeyword.getSelectedItem().toString()+"'");
			if (rs8.next()) {
				if (Integer.parseInt(rs8.getString("CNT"))>1) sKWTypeID = 0;
			}
			else {
				rs8 = connection.createStatement().executeQuery("SELECT KW_TYPE_ID from KEYWORDS WHERE KEYWORD = '"+cBox_SelectKeyword.getSelectedItem().toString()+"'");
				if (rs8.next()) sKWTypeID = Integer.parseInt(rs8.getString("KW_TYPE_ID"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sKWTypeID;
	}

	public void createGenericDialog(final int dialogPurpose){		//dialogPurpose = 1 for Action Keywords
																	//dialogPurpose = 2 for Templates
																	//dialogPurpose = 3 for Data Keywords
																	//dialogPurpose = 4 for ObjRep
																	//dialogPurpose = 5 for SQLRep
																	//dialogPurpose = 6 for Modules

		try {UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());} catch (Exception e) {e.printStackTrace();}

		visitKeywords = new JDialog();
		visitKeywords.setVisible(true);
		visitKeywords.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		visitKeywords.getContentPane().setBackground(Color.WHITE);
		visitKeywords.setResizable(false);
		visitKeywords.setBounds(100, 100, 680, 393);
		visitKeywords.setLocationRelativeTo(null);
		visitKeywords.getContentPane().setLayout(null);
		visitKeywords.setIconImage(Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Dlogo.jpg")));


		JScrollPane scrollPane_sql1 = new JScrollPane();
		scrollPane_sql1.setBackground(Color.WHITE);
		if (dialogPurpose == 4 || dialogPurpose == 5 || dialogPurpose == 6) scrollPane_sql1.setBounds(20, 34, 602, 249);
		else scrollPane_sql1.setBounds(20, 34, 630, 249);
		visitKeywords.getContentPane().add(scrollPane_sql1);

		final JTextField txt_SelectedDMID1 = new JTextField();
		txt_SelectedDMID1.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		txt_SelectedDMID1.setBounds(134, 294, 347, 30);
		visitKeywords.getContentPane().add(txt_SelectedDMID1);
		txt_SelectedDMID1.setColumns(10);

		table_Sql1 = new JTable();
		table_Sql1.setBackground(Color.WHITE);
		if(dialogPurpose!=4)		table_Sql1.setDefaultEditor(Object.class, null);
		table_Sql1.setColumnSelectionAllowed(true);
		table_Sql1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try{txt_SelectedDMID1.setText((table_Sql1.getModel().getValueAt(table_Sql1.getSelectedRow(), 0)).toString());}
				catch(Exception e1){e1.printStackTrace();}
				if(dialogPurpose==4) {

					obj_row = table_Sql1.getSelectedRow();

					if( (table_Sql1.getModel().getValueAt(obj_row, 0))!=null)	obj_objRef=(table_Sql1.getModel().getValueAt(obj_row, 0)).toString();

					if((table_Sql1.getModel().getValueAt(obj_row, 1))!=null) 	obj_objTagType=(table_Sql1.getModel().getValueAt(obj_row, 1)).toString();
					if((table_Sql1.getModel().getValueAt(obj_row, 2))!=null)  	obj_objTitle=(table_Sql1.getModel().getValueAt(obj_row, 2)).toString();
					if((table_Sql1.getModel().getValueAt(obj_row, 3))!=null) 	obj_objId=(table_Sql1.getModel().getValueAt(obj_row, 3)).toString();

					if((table_Sql1.getModel().getValueAt(obj_row, 4))!=null) 	obj_objName=(table_Sql1.getModel().getValueAt(obj_row, 4)).toString();

					if((table_Sql1.getModel().getValueAt(obj_row, 5))!=null) 	obj_objLinkText=(table_Sql1.getModel().getValueAt(obj_row, 5)).toString();

					if((table_Sql1.getModel().getValueAt(obj_row, 6))!=null) 	obj_objXpath=(table_Sql1.getModel().getValueAt(obj_row, 6)).toString();
				}
			}

		});
		scrollPane_sql1.setViewportView(table_Sql1);
		DisplayGenericTable(dialogPurpose);

		String b = "Selected Keyword";
		if (dialogPurpose == 2) b = "Selected Template";
		if (dialogPurpose == 4) b = "Selected Object";
		if (dialogPurpose == 5) b = "Selected DMID";
		if (dialogPurpose == 6) b = "Selected Module";
		JLabel lblSelectedObject1 = new JLabel(b);
		lblSelectedObject1.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		lblSelectedObject1.setBounds(20, 294, 143, 30);
		visitKeywords.getContentPane().add(lblSelectedObject1);

		final JLabel btnProceed1 = new JLabel("PROCEED");
		btnProceed1.setBackground(Color.BLACK);
		btnProceed1.setForeground(Color.WHITE);
		btnProceed1.setHorizontalAlignment(SwingConstants.CENTER);
		btnProceed1.setOpaque(true);
		btnProceed1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 13));
		btnProceed1.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (dialogPurpose == 1) cBox_SelectKeyword.setSelectedItem(txt_SelectedDMID1.getText().toString());
				if (dialogPurpose == 2) cBox_SelectobjRef.setSelectedItem(txt_SelectedDMID1.getText().toString());
				if (dialogPurpose == 3) txt_TextDataValue.setText(txt_SelectedDMID1.getText());
				if (dialogPurpose == 4) {fillObjDropDown(); cBox_SelectobjRef.setSelectedItem(txt_SelectedDMID1.getText().toString());}
				if (dialogPurpose == 5) txt_refTPK.setText(txt_SelectedDMID1.getText().toString());
				if (dialogPurpose == 6) {FillJComboBox_Module(); cbox_moduleName.setSelectedItem(txt_SelectedDMID1.getText().toString());}
				visitKeywords.dispose();
			}
			public void mouseEntered(MouseEvent e)
			{btnProceed1.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{btnProceed1.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{btnProceed1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {btnProceed1.setBorder(new LineBorder(new Color(192, 192, 192)));}
		});

		btnProceed1.setBounds(512, 294, 100, 30);
		visitKeywords.getContentPane().add(btnProceed1);

		String a = null;
		if (dialogPurpose == 1) a = "ADD TEST CASE - SELECT ACTION KEYWORD";
		else if (dialogPurpose == 2) a = "ADD TEST CASE - SELECT TEMPLATE";
		else if (dialogPurpose == 3) a = "ADD TEST CASE - SELECT DATA KEYWORD";
		else if (dialogPurpose == 4) a = "ADD TEST CASE - SELECT OBJECT";
		else if (dialogPurpose == 5) a = "ADD TEST CASE - SELECT TPK REFERENCE";
		else if (dialogPurpose == 6) a = "ADD TEST CASE - SELECT MODULE";
		JLabel lblAddTestCase1 = new JLabel(a);
		lblAddTestCase1.setOpaque(true);
		lblAddTestCase1.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddTestCase1.setForeground(Color.WHITE);
		lblAddTestCase1.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblAddTestCase1.setBackground(new Color(105, 105, 105));
		lblAddTestCase1.setBounds(0, 0, 680, 23);
		visitKeywords.getContentPane().add(lblAddTestCase1);

		JLabel label = new JLabel("");
		label.setOpaque(true);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setForeground(Color.WHITE);
		label.setFont(new Font("Calibri", Font.PLAIN, 18));
		label.setBackground(SystemColor.controlDkShadow);
		label.setBounds(0, 351, 680, 14);
		visitKeywords.getContentPane().add(label);

		if (dialogPurpose == 4 || dialogPurpose == 5 || dialogPurpose == 6){
			final JLabel lbl_Refresh = new JLabel("");
			lbl_Refresh.addMouseListener(new MouseAdapter() {
				@Override
				public void mousePressed(MouseEvent arg0)
				{lbl_Refresh.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));}
		        public void mouseReleased(MouseEvent arg0)
		        {lbl_Refresh.setBorder(null);}
				public void mouseEntered(MouseEvent arg0)
				{lbl_Refresh.setBorder(new LineBorder(Color.LIGHT_GRAY, 1));}
				public void mouseExited(MouseEvent arg0)
				{lbl_Refresh.setBorder(null);}
				public void mouseClicked(MouseEvent e) {
					DisplayGenericTable(dialogPurpose);
				}
			});
			lbl_Refresh.setBorder(null);
			lbl_Refresh.setHorizontalAlignment(SwingConstants.CENTER);
			lbl_Refresh.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "icon_refresh.png")));

			lbl_Refresh.setBounds(630, 34, 29, 29);
			visitKeywords.getContentPane().add(lbl_Refresh);
		}

		if (dialogPurpose == 4 || dialogPurpose == 5 || dialogPurpose == 6){
				final JLabel lbl_Add = new JLabel("");
				lbl_Add.addMouseListener(new MouseAdapter() {
					@Override
					public void mousePressed(MouseEvent arg0)
					{lbl_Add.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));}
			        public void mouseReleased(MouseEvent arg0)
			        {lbl_Add.setBorder(null);}
					public void mouseEntered(MouseEvent arg0)
					{lbl_Add.setBorder(new LineBorder(Color.LIGHT_GRAY, 1));}
					public void mouseExited(MouseEvent arg0)
					{lbl_Add.setBorder(null);}
					public void mouseClicked(MouseEvent e) {
						if (dialogPurpose == 4) com.optum.coliseum.frame.UI_Dialog_AddNewObjectToOR.UI_Dialog_AddNewObjectToOR_Handle(cBox_ApplicationName.getSelectedItem().toString(), connection);
						if (dialogPurpose == 5) {
							UI_Frame_VisitSQLRepository.UI_Frame_VisitSQLRepository_Handle(cBox_ApplicationName.getSelectedItem().toString(), connection);
						}
						if (dialogPurpose == 6) {UI_Dialog_AddNewModule.main(cBox_ApplicationName.getSelectedItem().toString(), connection);}
					}
				});
				lbl_Add.setBorder(null);
				lbl_Add.setHorizontalAlignment(SwingConstants.CENTER);
				lbl_Add.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_Add.png")));

				lbl_Add.setBounds(630, 64, 29, 29);
				visitKeywords.getContentPane().add(lbl_Add);


				if(dialogPurpose==4){
				JLabel label_Update = new JLabel("");
				label_Update.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						try {
							if(obj_row==-1){Msgbox.msgbox("Please select a row");}
							else{
								String query1 = "UPDATE OBJ_REP set ID='"+replaceQuote(obj_objId)+"', NAME ='"+replaceQuote(obj_objName)+"', LINKTEXT = '"+replaceQuote(obj_objLinkText)+"', "
										+ "TAG_TYPE ='"+replaceQuote(obj_objTagType)+"' , XPATH ='"+replaceQuote(obj_objXpath)+"', TITLE ='"+replaceQuote(obj_objTitle)+"' where OBJ_REF ='"+replaceQuote(obj_objRef)+"' "
												+ "and application = '"+Settings.getSetting("AUT", connection)+"'";
								PreparedStatement pst1  = connection.prepareStatement(query1);
								pst1.executeUpdate();
								DisplayGenericTable(4);
								Msgbox.msgbox("Obj Ref Updated successfully");
							}
						} catch (Exception e1) {
							e1.printStackTrace();
						}

					}
				});
				label_Update.setHorizontalAlignment(SwingConstants.CENTER);
				label_Update.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "icon_update.png")));

				label_Update.setBounds(630, 94, 29, 29);
				visitKeywords.getContentPane().add(label_Update);
				}
		}
	}

	public void DisplayGenericTable(int dialogPurpose){
		try{
			String query = null;
			if (dialogPurpose == 1) query = "SELECT K.KEYWORD, k.KEYWORD_DESC, K.EXAMPLE, k.KW_TYPE_ID FROM Keywords K where KW_TYPE_ID IN (1,2) order by KEYWORD";
			if (dialogPurpose == 2) query = "Select T.TMPLID, T.TMPL_NAME, T.TMPL_DESC from Template_Details T where APPLICATION = '"+cBox_ApplicationName.getSelectedItem().toString()+"'";
			if (dialogPurpose == 3) query = "SELECT K.KEYWORD, k.KEYWORD_DESC, K.EXAMPLE FROM Keywords K where KW_TYPE_ID = 3 order by KEYWORD";
			//BHARATH __> removed displaying href
			if (dialogPurpose == 4) query = "Select OBJ_REF,TAG_TYPE,TITLE,ID, NAME,LINKTEXT,XPATH from OBJ_REP where TAG_TYPE = '"+(String)cBox_SelectKeyword.getSelectedItem()+"' and APPLICATION = '"+cBox_ApplicationName.getSelectedItem()+"' order by TAG_TYPE";
			if (dialogPurpose == 5) query = "Select SQLID, ESQL from SQLS where SQLID LIKE 'DM%' and APPLICATION = '"+cBox_ApplicationName.getSelectedItem().toString()+"'";
			if (dialogPurpose == 6) query = "Select MODULE_NAME, MODULE_DESC, MODULEID from MOD_SCHEDULER where APPLICATION = '"+cBox_ApplicationName.getSelectedItem().toString()+"'";
			ResultSet rs8 = connection.createStatement().executeQuery(query);
			table_Sql1.setModel(DbUtils.resultSetToTableModel(rs8));

		}
			catch(Exception etc){etc.printStackTrace();}
	}
	public String replaceQuote(String relaceVal){
		if(relaceVal.contains("'")) relaceVal= relaceVal.replaceAll("'", "''");
		return relaceVal;
	}

}
