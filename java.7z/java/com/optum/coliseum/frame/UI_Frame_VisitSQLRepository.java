
package com.optum.coliseum.frame;

import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import net.proteanit.sql.DbUtils;
import java.awt.Color;
import java.sql.*;
import javax.swing.*;
import java.awt.Font;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;

import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.DBUtils;
import com.optum.coliseum.generic.Settings;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Toolkit;
import java.awt.SystemColor;

public class UI_Frame_VisitSQLRepository extends JFrame {

	private static final long serialVersionUID = 1L;
	static Connection connection=null;
	private JLabel btnNewButton;
	private String dmID = "-1";
	private String esql;
	private String app;
	private JLabel btnRefresh;
	private JPanel contentPane;
	private JTable table_SQL;
	public JCheckBox ckbx_RefreshDM;
	public JPanel contentpane;
	public String query;
	private JCheckBox chckbxDisplayDmSqls;
	private JCheckBox chckbxDisplaySqSqls;
	private JComboBox<String> cBox_AppName;
	private JLabel lblApplication;
	private JScrollPane scrollPane_2;
	private JLabel lblAddSql;
	private JTextArea txt_NewSQL;
	private JComboBox<String> cBox_SQLType;
	private JLabel lblNewLabel;
	private JTextField textField;
	private static boolean isDrivenByMain = false;

	public static void main(String[] args) {
		isDrivenByMain = true;
				try {
					connection=DBUtils.DBConnect_Automation();
					final UI_Frame_VisitSQLRepository frame = new UI_Frame_VisitSQLRepository(Settings.getSetting("AUT",  connection), connection);
					frame.setVisible(true);
					frame.addWindowListener(new java.awt.event.WindowAdapter() {
					    @Override
					    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
					        if (JOptionPane.showConfirmDialog(frame,"Are you sure to close this window?", "Really Closing?",JOptionPane.YES_NO_OPTION,
					            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
					        	frame.dispose();
					        	try {
					        		connection.close();
					        		UI_Frame_Dashboard homePage = new UI_Frame_Dashboard();
					        		homePage.setVisible(true);
								} catch (Exception e) {
									e.printStackTrace();
								}}
					        else{
					        	frame.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
					        }  }});
					} catch (Exception e) {e.printStackTrace();}
	}

	public static void UI_Frame_VisitSQLRepository_Handle(final String sAUT, final Connection con){
		connection = con;
		final UI_Frame_VisitSQLRepository frame = new UI_Frame_VisitSQLRepository(sAUT, connection);
		frame.setVisible(true);
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
		    @Override
		    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
		        if (JOptionPane.showConfirmDialog(frame,"Are you sure to close this window?", "Really Closing?",JOptionPane.YES_NO_OPTION,
		            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
		        	frame.dispose();
		        }
		        else frame.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		        }});
	}

	public UI_Frame_VisitSQLRepository(final String sAUT, final Connection con) {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Dlogo.jpg")));

		try {
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}

		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 960, 600);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		lblAddSql = new JLabel("Add SQL");
		lblAddSql.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e)
			{lblAddSql.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{lblAddSql.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{lblAddSql.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {lblAddSql.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent arg0) {
				String insertNewSQL = InsertNewSQL();
				if (insertNewSQL!=null) { DisplaySQlTable(true); Msgbox.msgbox("New SQL created: "+insertNewSQL);}
			}
		});
		lblAddSql.setOpaque(true);
		lblAddSql.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddSql.setForeground(Color.WHITE);
		lblAddSql.setFont(new Font("Calibri", Font.PLAIN, 14));
		lblAddSql.setBackground(Color.BLACK);
		lblAddSql.setBounds(766, 502, 125, 23);
		contentPane.add(lblAddSql);

		cBox_AppName = new JComboBox<String>();
		cBox_AppName.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		cBox_AppName.setBounds(445, 52, 131, 30);
		contentPane.add(cBox_AppName);
		try{
			if (isDrivenByMain){
				ResultSet rs = connection.prepareStatement("Select distinct application from Env").executeQuery();
				while(rs.next()){
					cBox_AppName.addItem(rs.getString("application"));
				}
				rs.close();
				cBox_AppName.setSelectedItem(Settings.getSetting("AUT", connection));
			}
			else {
				cBox_AppName.addItem(sAUT);
				cBox_AppName.setSelectedItem(sAUT);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}


		chckbxDisplayDmSqls = new JCheckBox(" Data Manager (DM)");
		chckbxDisplayDmSqls.setOpaque(false);
		chckbxDisplayDmSqls.setForeground(new Color(105, 105, 105));
		chckbxDisplayDmSqls.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		chckbxDisplayDmSqls.setBounds(698, 105, 151, 23);
		contentPane.add(chckbxDisplayDmSqls);

		chckbxDisplaySqSqls = new JCheckBox("Other SQLS (SQ)");
		chckbxDisplaySqSqls.setOpaque(false);
		chckbxDisplaySqSqls.setForeground(new Color(105, 105, 105));
		chckbxDisplaySqSqls.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		chckbxDisplaySqSqls.setBounds(698, 131, 142, 23);
		contentPane.add(chckbxDisplaySqSqls);

		lblApplication = new JLabel("Application");
		lblApplication.setForeground(Color.GRAY);
		lblApplication.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		lblApplication.setBounds(356, 49, 79, 37);
		contentPane.add(lblApplication);

		if (isDrivenByMain){
		JLabel lblBack = new JLabel();
		lblBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				try {
					connection.close();
					dispose();
					UI_Frame_Dashboard objdshbrd = new UI_Frame_Dashboard();
					objdshbrd.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		lblBack.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "icon_back.png")));
		lblBack.setBounds(0, 0, 40, 30);
		lblBack.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblBack);
		}

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBorder(new LineBorder(new Color(130, 135, 144)));
		scrollPane.setBounds(44, 97, 631, 394);
		contentPane.add(scrollPane);

		table_SQL = new JTable();
		DisplaySQlTable(true);
		table_SQL.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table_SQL.getSelectedRow();
				dmID = (table_SQL.getModel().getValueAt(row, 0)).toString();
				esql = (table_SQL.getModel().getValueAt(row, 1)).toString();
				app = (table_SQL.getModel().getValueAt(row,2)).toString();
			}});
		table_SQL.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_DELETE){
					if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this Query?", "CONFIRMATION",JOptionPane.YES_NO_OPTION ) == 0){
					   try{
						   	connection.createStatement().executeUpdate("Delete from SQLS where SQLID = '"+dmID+"' and application = '"+cBox_AppName.getSelectedItem().toString()+"'");
						    System.out.println(dmID + " deleted");
						    DisplaySQlTable(true);
					   }
					   catch(Exception e1){e1.printStackTrace();}
					}
			    }
			}});
		scrollPane.setViewportView(table_SQL);

		JLabel lblSqlBank = new JLabel("SQL BANK");
		lblSqlBank.setOpaque(true);
		lblSqlBank.setHorizontalAlignment(SwingConstants.CENTER);
		lblSqlBank.setForeground(Color.WHITE);
		lblSqlBank.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblSqlBank.setBackground(Color.BLACK);
		lblSqlBank.setBounds(0, 0, 954, 30);
		contentPane.add(lblSqlBank);

		JLabel label_1 = new JLabel("");
		label_1.setOpaque(true);
		label_1.setBackground(Color.BLACK);
		label_1.setBounds(0, 557, 954, 15);
		contentPane.add(label_1);

		btnRefresh = new JLabel("Refresh View");
		btnRefresh.setHorizontalAlignment(SwingConstants.CENTER);
		btnRefresh.setFont(new Font("Calibri", Font.PLAIN, 14));
		btnRefresh.setOpaque(true);
		btnRefresh.setForeground(Color.WHITE);
		btnRefresh.setBackground(Color.BLACK);
		btnRefresh.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e)
			{btnRefresh.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{btnRefresh.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{btnRefresh.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {btnRefresh.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent arg0) {
				DisplaySQlTable(true);
			}
		});
		btnRefresh.setBounds(698, 172, 126, 23);
		contentPane.add(btnRefresh);

		btnNewButton = new JLabel("Update");
		btnNewButton.setBackground(Color.BLACK);
		btnNewButton.setHorizontalAlignment(SwingConstants.CENTER);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e)
			{btnNewButton.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{btnNewButton.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{btnNewButton.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {btnNewButton.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent arg0) {
				if (!dmID.equals("-1")){
					 if (JOptionPane.showConfirmDialog(null,"Are you sure you want to update SQL: "+dmID+"?", "Please confirm?",JOptionPane.YES_NO_OPTION,
					            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
						try {
							//Bharath ---> Handled Quotes
							if(esql.contains("'")) esql= esql.replaceAll("'", "''");
							String queryStatement = "Update SQLS set SQLID ='"+dmID+"', ESQL =?, APPLICATION='"+app+"'  WHERE SQLID = '"+dmID+"'";
							PreparedStatement statement = connection.prepareStatement(queryStatement);
							statement.setString(1, esql);
							statement.execute();
							statement.close();
							Msgbox.msgbox("Updated successfully");
						} catch (Exception e1) {e1.printStackTrace();}
					 }
				 } else Msgbox.msgbox("Please select a row to update");
			}});
		btnNewButton.setBounds(310, 502, 125, 23);
		btnNewButton.setFont(new Font("Calibri", Font.PLAIN, 14));
		btnNewButton.setOpaque(true);
		btnNewButton.setForeground(Color.WHITE);
		contentPane.add(btnNewButton);

		scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(716, 325, 209, 166);
		contentPane.add(scrollPane_2);

		txt_NewSQL = new JTextArea();
		txt_NewSQL.setWrapStyleWord(true);
		txt_NewSQL.setRows(5);
		scrollPane_2.setViewportView(txt_NewSQL);

		JLabel lblSqlType = new JLabel("SQL Type  ");
		lblSqlType.setForeground(Color.BLACK);
		lblSqlType.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		lblSqlType.setBounds(715, 286, 79, 37);
		contentPane.add(lblSqlType);

		cBox_SQLType = new JComboBox<String>();
		cBox_SQLType.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		cBox_SQLType.setBounds(793, 289, 125, 30);
		contentPane.add(cBox_SQLType);

		lblNewLabel = new JLabel("");
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBackground(SystemColor.menu);
		lblNewLabel.setBounds(663, 97, 209, 113);
		contentPane.add(lblNewLabel);
		cBox_SQLType.addItem("DM");
		cBox_SQLType.addItem("SQ");
		cBox_SQLType.addItem("FQ");
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(29, 65, 188, 24);
		contentPane.add(textField);
		
		final JLabel lblSearch = new JLabel("Search");
		lblSearch.setHorizontalAlignment(SwingConstants.CENTER);
		lblSearch.setForeground(Color.BLACK);
		lblSearch.setFont(new Font("Segoe UI", Font.ITALIC, 12));
		lblSearch.setBounds(227, 66, 49, 23);
		lblSearch.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		lblSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DisplaySQlTable(false);
			}
			public void mousePressed(MouseEvent arg0)
			{lblSearch.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {lblSearch.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));}
			public void mouseEntered(MouseEvent arg0)
			{lblSearch.setBorder(new LineBorder(Color.BLUE, 2));}
			public void mouseExited(MouseEvent arg0)
			{lblSearch.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));}
		});

		contentPane.add(lblSearch);
	}

	protected String InsertNewSQL() {
		String newSQLID = null;
		String text_newSQL = txt_NewSQL.getText();
		if(text_newSQL.contains("'")) text_newSQL=text_newSQL.replaceAll("'", "''");
		try {
			ResultSet rs = connection.createStatement().executeQuery("Select MAX(SQLID) as MAXX from SQLS where SQLID LIKE '"+cBox_SQLType.getSelectedItem().toString()+"%'");
			while (rs.next()){newSQLID = rs.getString("MAXX");}

			int fin = 0;
			if(newSQLID == null) newSQLID = cBox_SQLType.getSelectedItem().toString() + "0001";
			else {
				try {
					//Here we are  facing Number format Exception when we have any alphabet present   --> Bharath
					fin = Integer.parseInt(newSQLID.substring(2))+1;
				} catch (NumberFormatException e) {
					newSQLID = null;
					Msgbox.msgbox("Incorrect project set up detected. Please fix the SQLIDs for your project.");
				}

				if(newSQLID!=null){
					try {
					int length = (int)(Math.log10(fin)+1);
					newSQLID = newSQLID.substring(0,6-length)+fin;
						connection.createStatement().executeUpdate("Insert into SQLS (SQLID, ESQL, APPLICATION) VALUES ('"+newSQLID+"', '"+text_newSQL+"', '"+cBox_AppName.getSelectedItem().toString()+"')");
					} catch (SQLException e) {
						newSQLID = null;
						Msgbox.msgbox("SQL cant be inserted. Please analyze the repository with the help of Tool Admins.");

					}
				}
			}

		} catch (SQLException e1) {e1.printStackTrace();}

		return newSQLID;
	}

	public void DisplaySQlTable(boolean flag){
		String sSQL = "";
		if(flag==true) sSQL ="select SQLID, eSQL,APPLICATION from SQLS where application = '"+cBox_AppName.getSelectedItem().toString()+"'";
		else if(flag ==false)sSQL ="select SQLID, ESQL,APPLICATION from SQLS where application = "
				+ "'"+cBox_AppName.getSelectedItem().toString()+"' and "
				+ "( SQLID like '%"+textField.getText()+"%' OR"
						+ " ESQL like '%"+textField.getText()+"%')";
		try {
			if (!(chckbxDisplayDmSqls.isSelected() && chckbxDisplaySqSqls.isSelected())) {
				if (chckbxDisplayDmSqls.isSelected()) sSQL = sSQL + " and SQLID like 'DM%'";
				else if (chckbxDisplaySqSqls.isSelected()) sSQL = sSQL + " and SQLID like 'SQ%'";
				sSQL= sSQL+" order by SQLID";
				System.out.println(sSQL);
			}
			try {
			    PreparedStatement pst = connection.prepareStatement(sSQL);
			    ResultSet rs = pst.executeQuery();
			    table_SQL.setModel(DbUtils.resultSetToTableModel(rs));
			    table_SQL.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			    table_SQL.getColumnModel().getColumn(0).setPreferredWidth(80);
			    table_SQL.getColumnModel().getColumn(1).setPreferredWidth(450);
			    table_SQL.getColumnModel().getColumn(2).setPreferredWidth(80);
			   rs.close();
			} catch (SQLException e) {e.printStackTrace();}
		}
		catch (Exception ex) {ex.printStackTrace();}
	}
}
