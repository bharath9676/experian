package com.optum.coliseum.frame;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;

import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.DBUtils;
import com.optum.coliseum.generic.Settings;

import net.proteanit.sql.DbUtils;

public class UI_Frame_VisitOR extends JFrame {
	private static final long serialVersionUID = 1L;
	static Connection connection = null;
	private JPanel contentPane;
	private JTable table_OR;
	private int row;
	public String objRef = "";
	private String objId = "";
	private String objName = "";
	private String objLinkText = "";
	private String objTagType = "";
	private String objTitle = "";
	private String objXpath = "";
	private JLabel label_BG;

	private JTextField textField;
	private String CSVquery = "";
	private boolean isAscending = true;
	private JLabel label_BG2;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					connection = DBUtils.DBConnect_Automation();
					final UI_Frame_VisitOR frame = new UI_Frame_VisitOR(Settings.getSetting("AUT", connection),
							connection);
					frame.setVisible(true);
					frame.addWindowListener(new java.awt.event.WindowAdapter() {
						@Override
						public void windowClosing(java.awt.event.WindowEvent windowEvent) {
							if (JOptionPane.showConfirmDialog(frame, "Are you sure to close window?", "Really Closing?",
									JOptionPane.YES_NO_OPTION,
									JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION) {
								try {
									connection.close();
									frame.dispose();
									UI_Frame_Dashboard.main(null);
								} catch (Exception e) {
									e.printStackTrace();
								}
							} else {
								frame.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
							}
						}
					});
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public UI_Frame_VisitOR(final String sAUT, final Connection connection) {

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Dlogo.jpg")));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1500, 600);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnNullTagtype = new JButton("NULL TAG_TYPE");
		btnNullTagtype.setBounds(352, 65, 142, 25);
		contentPane.add(btnNullTagtype);

		JButton btnNONullTypes = new JButton("No Null or Empty TAG_TYPES");
		btnNONullTypes.setBounds(500, 65, 200, 25);
		contentPane.add(btnNONullTypes);

		JButton btnPrintCsv = new JButton("Print CSV");
		btnPrintCsv.setBounds(333, 505, 97, 25);
		contentPane.add(btnPrintCsv);

		JButton sortByObjRef = new JButton("Sort By OBJ REF");
		sortByObjRef.setBounds(450, 505, 150, 25);
		contentPane.add(sortByObjRef);

		JButton sortByTagTye = new JButton("Sort By TAG TYPE");
		sortByTagTye.setBounds(615, 505, 150, 25);
		contentPane.add(sortByTagTye);

		// contentPane.add(JT_fname);
		// contentPane.add(JT_lname);
		// contentPane.add(JT_age);

		final JLabel lblSearch = new JLabel("Search");
		lblSearch.setHorizontalAlignment(SwingConstants.CENTER);
		lblSearch.setForeground(Color.BLACK);
		lblSearch.setFont(new Font("Segoe UI", Font.ITALIC, 12));
		lblSearch.setBounds(227, 66, 49, 23);
		lblSearch.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		lblSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DisplayTable(false);
			}

			public void mousePressed(MouseEvent arg0) {
				lblSearch.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
			}

			public void mouseReleased(MouseEvent arg0) {
				lblSearch.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
			}

			public void mouseEntered(MouseEvent arg0) {
				lblSearch.setBorder(new LineBorder(Color.BLUE, 2));
			}

			public void mouseExited(MouseEvent arg0) {
				lblSearch.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
			}
		});

		contentPane.add(lblSearch);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBackground(Color.WHITE);
		scrollPane.setBounds(29, 99, 1450, 397);
		contentPane.add(scrollPane);

		table_OR = new JTable();
		table_OR.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {

			}
		});
		table_OR.putClientProperty("terminateEditOnFoucsLost", true);
		table_OR.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_DELETE) {
					try {
						deleteORRecord();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		table_OR.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					row = table_OR.getSelectedRow();
					if ((table_OR.getModel().getValueAt(row, 0)) != null)
						objRef = (table_OR.getModel().getValueAt(row, 0)).toString();

					if ((table_OR.getModel().getValueAt(row, 1)) != null)
						objTagType = (table_OR.getModel().getValueAt(row, 1)).toString();

					if ((table_OR.getModel().getValueAt(row, 2)) != null)
						objTitle = (table_OR.getModel().getValueAt(row, 2)).toString();

					if ((table_OR.getModel().getValueAt(row, 3)) != null)
						objId = (table_OR.getModel().getValueAt(row, 3)).toString();

					if ((table_OR.getModel().getValueAt(row, 4)) != null)
						objName = (table_OR.getModel().getValueAt(row, 4)).toString();

					if ((table_OR.getModel().getValueAt(row, 5)) != null)
						objLinkText = (table_OR.getModel().getValueAt(row, 5)).toString();

					if ((table_OR.getModel().getValueAt(row, 6)) != null)
						objXpath = (table_OR.getModel().getValueAt(row, 6)).toString();
					// System.out.println(objRef+",,,"+objTagType+",,,,"+objTitle+",,,,,"+objId+",,,,"+objName+",,,,"+objLinkText+",,,,"+objXpath);
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("ERRRRRR");
				}
			}
		});
		table_OR.setOpaque(false);
		DisplayTable(true);
		scrollPane.setViewportView(table_OR);

		// Adam changes
		btnNullTagtype.addMouseListener(new MouseAdapter() {

			public void mouseClicked(MouseEvent e) {

				try {
					System.out.println("NULL");
					CSVquery = "select OBJ_REF,TAG_TYPE,TITLE,ID, NAME,LINKTEXT,XPATH from OBJ_REP where Application = '"
							+ Settings.getSetting("AUT", connection) + "'" + " and (tag_type is null or tag_type = '')"
							+ " order by TAG_TYPE";

					PreparedStatement pst = connection.prepareStatement(CSVquery);
					ResultSet rs = pst.executeQuery();
					table_OR.setModel(DbUtils.resultSetToTableModel(rs));
					table_OR.getColumnModel().getColumn(0)
							.setPreferredWidth(table_OR.getColumnModel().getColumn(0).getPreferredWidth() + 500);
					rs.close();
					pst.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});

		btnNONullTypes.addMouseListener(new MouseAdapter() {

			public void mouseClicked(MouseEvent e) {
				try {
					System.out.println("NOT NULL");
					CSVquery = "select OBJ_REF,TAG_TYPE,TITLE,ID, NAME,LINKTEXT,XPATH from OBJ_REP where Application = '"
							+ Settings.getSetting("AUT", connection) + "' and (tag_type is not null and tag_type <> '')"
							+ " and tag_type <> 'NULL'" + " order by TAG_TYPE";

					PreparedStatement pst = connection.prepareStatement(CSVquery);
					ResultSet rs = pst.executeQuery();
					table_OR.setModel(DbUtils.resultSetToTableModel(rs));
					table_OR.getColumnModel().getColumn(0)
							.setPreferredWidth(table_OR.getColumnModel().getColumn(0).getPreferredWidth() + 500);
					rs.close();
					pst.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}

			}

		});

		sortByObjRef.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				try {
					if (isAscending == true) { // asc
						CSVquery = "select OBJ_REF,TAG_TYPE,TITLE,ID, NAME,LINKTEXT,XPATH from OBJ_REP where Application = '"
								+ Settings.getSetting("AUT", connection) + "' order by OBJ_REF";
						PreparedStatement pst = connection.prepareStatement(CSVquery);
						ResultSet rs = pst.executeQuery();
						table_OR.setModel(DbUtils.resultSetToTableModel(rs));
						table_OR.getColumnModel().getColumn(0)
								.setPreferredWidth(table_OR.getColumnModel().getColumn(0).getPreferredWidth() + 500);
						rs.close();
						pst.close();
						isAscending = false;
					} else if (isAscending == false) { // desc
						CSVquery = "select OBJ_REF,TAG_TYPE,TITLE,ID, NAME,LINKTEXT,XPATH from OBJ_REP where Application = '"
								+ Settings.getSetting("AUT", connection) + "' order by OBJ_REF DESC";
						PreparedStatement pst = connection.prepareStatement(CSVquery);
						ResultSet rs = pst.executeQuery();
						table_OR.setModel(DbUtils.resultSetToTableModel(rs));
						table_OR.getColumnModel().getColumn(0)
								.setPreferredWidth(table_OR.getColumnModel().getColumn(0).getPreferredWidth() + 500);
						rs.close();
						pst.close();
						isAscending = true;
					}

				} catch (Exception ex) {
					ex.printStackTrace();
				}

			}
		});

		sortByTagTye.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				try {
					if (isAscending == true) { // asc
						CSVquery = "select OBJ_REF,TAG_TYPE,TITLE,ID, NAME,LINKTEXT,XPATH from OBJ_REP where Application = '"
								+ Settings.getSetting("AUT", connection) + "' order by TAG_TYPE";
						PreparedStatement pst = connection.prepareStatement(CSVquery);
						ResultSet rs = pst.executeQuery();
						table_OR.setModel(DbUtils.resultSetToTableModel(rs));
						table_OR.getColumnModel().getColumn(0)
								.setPreferredWidth(table_OR.getColumnModel().getColumn(0).getPreferredWidth() + 500);
						rs.close();
						pst.close();
						isAscending = false;

					} else if (isAscending == false) { // desc
						CSVquery = "select OBJ_REF,TAG_TYPE,TITLE,ID, NAME,LINKTEXT,XPATH from OBJ_REP where Application = '"
								+ Settings.getSetting("AUT", connection) + "' order by TAG_TYPE DESC";
						PreparedStatement pst = connection.prepareStatement(CSVquery);
						ResultSet rs = pst.executeQuery();
						table_OR.setModel(DbUtils.resultSetToTableModel(rs));
						table_OR.getColumnModel().getColumn(0)
								.setPreferredWidth(table_OR.getColumnModel().getColumn(0).getPreferredWidth() + 500);
						rs.close();
						pst.close();
						isAscending = true;

					}

				} catch (Exception ex) {
					ex.printStackTrace();
				}

			}
		});

		btnPrintCsv.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				try {
					getCSV(CSVquery);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});

		final JLabel btnUpdate = new JLabel("UPDATE");
		btnUpdate.setHorizontalAlignment(SwingConstants.CENTER);
		btnUpdate.setForeground(Color.WHITE);
		btnUpdate.setBackground(Color.BLACK);
		btnUpdate.setOpaque(true);
		btnUpdate.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
		btnUpdate.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseEntered(MouseEvent e) {
				btnUpdate.setBackground(new Color(255, 165, 0));
			}

			public void mouseExited(MouseEvent e) {
				btnUpdate.setBackground(Color.BLACK);
			}

			public void mousePressed(MouseEvent arg0) {
				btnUpdate.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
			}

			public void mouseReleased(MouseEvent arg0) {
				btnUpdate.setBorder(new LineBorder(new Color(192, 192, 192)));
			}

			public void mouseClicked(MouseEvent arg0) {
				try {

					String query1 = "UPDATE OBJ_REP set ID='" + replaceQuote(objId) + "', NAME ='"
							+ replaceQuote(objName) + "', LINKTEXT = '" + replaceQuote(objLinkText) + "', "
							+ "TAG_TYPE ='" + replaceQuote(objTagType) + "' , XPATH ='" + replaceQuote(objXpath)
							+ "', TITLE ='" + replaceQuote(objTitle) + "' where OBJ_REF ='" + replaceQuote(objRef)
							+ "' " + "and application = '" + Settings.getSetting("AUT", connection) + "'";
					System.out.println(query1);
					PreparedStatement pst1 = connection.prepareStatement(query1);
					pst1.executeUpdate();
					pst1.close();
					Msgbox.msgbox("Obj Ref Updated successfully");

				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnUpdate.setBounds(829, 507, 85, 21);
		contentPane.add(btnUpdate);

		JLabel lblBack = new JLabel();
		lblBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				try {
					connection.close();
					dispose();
					UI_Frame_Dashboard.main(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		lblBack.setIcon(
				new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "icon_back.png")));
		lblBack.setBounds(0, 0, 40, 30);
		lblBack.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblBack);

		JLabel lblObjectRepository = new JLabel("OBJECT REPOSITORY");
		lblObjectRepository.setOpaque(true);
		lblObjectRepository.setHorizontalAlignment(SwingConstants.CENTER);
		lblObjectRepository.setForeground(Color.WHITE);
		lblObjectRepository.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblObjectRepository.setBackground(Color.BLACK);
		lblObjectRepository.setBounds(0, 0, 1500, 30);
		contentPane.add(lblObjectRepository);

		JLabel label_bottom = new JLabel("");
		label_bottom.setOpaque(true);
		label_bottom.setBackground(Color.BLACK);
		label_bottom.setBounds(0, 561, 1500, 11);
		contentPane.add(label_bottom);

		final JLabel lbl_AddNewObjectICon = new JLabel("");
		lbl_AddNewObjectICon.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				UI_Dialog_AddNewObjectToOR.UI_Dialog_AddNewObjectToOR_Handle(sAUT, connection);
			}

			@Override
			public void mousePressed(MouseEvent arg0) {
				lbl_AddNewObjectICon.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
			}

			public void mouseReleased(MouseEvent arg0) {
				lbl_AddNewObjectICon.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
			}

			public void mouseEntered(MouseEvent arg0) {
				lbl_AddNewObjectICon.setBorder(new LineBorder(Color.BLUE, 2));
			}

			public void mouseExited(MouseEvent arg0) {
				lbl_AddNewObjectICon.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
			}
		});
		lbl_AddNewObjectICon.setToolTipText("Add new Object");
		lbl_AddNewObjectICon.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		lbl_AddNewObjectICon.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_AddNewObjectICon.setIcon(
				new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_Add.png")));
		lbl_AddNewObjectICon.setBounds(847, 59, 29, 29);
		contentPane.add(lbl_AddNewObjectICon);

		final JLabel lbl_Refresh = new JLabel("");
		lbl_Refresh.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				lbl_Refresh.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
			}

			public void mouseReleased(MouseEvent arg0) {
				lbl_Refresh.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
			}

			public void mouseEntered(MouseEvent arg0) {
				lbl_Refresh.setBorder(new LineBorder(Color.BLUE, 2));
			}

			public void mouseExited(MouseEvent arg0) {
				lbl_Refresh.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
			}

			public void mouseClicked(MouseEvent e) {
				DisplayTable(true);
			}
		});
		lbl_Refresh.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		lbl_Refresh.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Refresh.setIcon(
				new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "icon_refresh.png")));
		lbl_Refresh.setBounds(886, 59, 29, 29);
		contentPane.add(lbl_Refresh);

		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(29, 65, 188, 24);
		contentPane.add(textField);
		lbl_Refresh.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent arg0) {
				lblSearch.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
			}

			public void mouseReleased(MouseEvent arg0) {
				lblSearch.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
			}

			public void mouseEntered(MouseEvent arg0) {
				lblSearch.setBorder(new LineBorder(Color.BLUE, 2));
			}

			public void mouseExited(MouseEvent arg0) {
				lblSearch.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
			}

			public void mouseClicked(MouseEvent e) {
				DisplayTable(false);
			}
		});

		label_BG = new JLabel("");
		label_BG.setIcon(
				new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "white11.jpg")));
		label_BG.setBounds(700, 0, 1600, 561);
		// label_BG.setMaximumSize(getMaximumSize());
		// label_BG.setBounds(0, 0, 1500, 561);
		contentPane.add(label_BG);
		label_BG2 = new JLabel("");
		label_BG2.setIcon(
				new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "white11.jpg")));
		label_BG2.setBounds(0, 0, 700, 561);
		contentPane.add(label_BG2);
	}

	public void DisplayTable(boolean flag) {
		if (flag == true)
			CSVquery = "select OBJ_REF,TAG_TYPE,TITLE,ID, NAME,LINKTEXT,XPATH from OBJ_REP where Application = '"
					+ Settings.getSetting("AUT", connection) + "' order by TAG_TYPE";
		else if (flag == false)
			CSVquery = "select OBJ_REF,TAG_TYPE,TITLE,ID, NAME,LINKTEXT,XPATH from OBJ_REP where Application = '"
					+ Settings.getSetting("AUT", connection) + "' and (" + "OBJ_REF like  '%" + textField.getText()
					+ "%' OR " + "ID like  '%" + textField.getText() + "%' OR " + "Name like  '%" + textField.getText()
					+ "%' OR " + "LinkText like  '%" + textField.getText() + "%')" + "order by TAG_TYPE";
		try {
			PreparedStatement pst = connection.prepareStatement(CSVquery);
			ResultSet rs = pst.executeQuery();
			table_OR.setModel(DbUtils.resultSetToTableModel(rs));
			table_OR.getColumnModel().getColumn(0)
					.setPreferredWidth(table_OR.getColumnModel().getColumn(0).getPreferredWidth() + 500);
			rs.close();
			pst.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public String replaceQuote(String relaceVal) {
		if (relaceVal.contains("'"))
			relaceVal = relaceVal.replaceAll("'", "''");
		return relaceVal;
	}

	public void deleteORRecord() {
		int action = JOptionPane.showConfirmDialog(null, "Are you sure you want to Delete this record?", "CONFIRMATION",
				JOptionPane.YES_NO_OPTION);
		if (action == 0) {
			try {
				connection.createStatement()
						.executeUpdate("Delete from OBJ_REP where OBJ_REF = '" + replaceQuote(objRef) + "'");
				DisplayTable(true);
			} catch (SQLException e) {
				System.out.println("################## FAILURE! DeleteTestStep() failed!");
			}
		}
	}

	// Bharath New Story
	void getCSV(String query) throws Exception {
		String filePath = Settings.getSetting("CSV_root", connection) + "\\ObjectRep.csv";
		StringBuilder stB = new StringBuilder();

		PrintWriter pw = new PrintWriter(new File(filePath));
		stB.append("OBJ_REF").append(',').append("TAG_TYPE").append(',').append("TITLE").append(',').append("ID")
				.append(',').append("NAME").append(',').append("LINKTEXT").append(',').append("XPATH").append('\n');
		System.out.println(query);
		ResultSet rs = connection.createStatement().executeQuery(query);
		while (rs.next()) {
			String OBJ_REF = rs.getString("OBJ_REF");

			if (!OBJ_REF.equalsIgnoreCase("NULL") || !OBJ_REF.equalsIgnoreCase("NA") || !OBJ_REF.equals("")) {
				stB.append(rs.getString("OBJ_REF")).append(',').append(rs.getString("TAG_TYPE")).append(',')
						.append(rs.getString("TITLE")).append(',').append(rs.getString("ID")).append(',')
						.append(rs.getString("NAME")).append(',').append(rs.getString("LINKTEXT")).append(',')
						.append(rs.getString("XPATH")).append('\n');
			}

		}
		pw.write(stB.toString());
		pw.close();
		rs.close();

		Desktop desktop = Desktop.getDesktop();
		File file = new File(filePath);
		if (file.exists() && file.canRead())
			// adam cahnges
			if (file.exists() && file.isFile())
				desktop.open(file);
			else
				throw new FileNotFoundException();

	}
}