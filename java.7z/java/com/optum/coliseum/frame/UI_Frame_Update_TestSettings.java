package com.optum.coliseum.frame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Font;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.SwingConstants;
import javax.swing.UIManager;

import java.awt.Toolkit;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import javax.swing.JComboBox;

import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.DBUtils;
import com.toedter.calendar.JDateChooser;
import javax.swing.JTable;
import javax.swing.ImageIcon;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

@SuppressWarnings("serial")
public class UI_Frame_Update_TestSettings extends JFrame {

	static Connection connection = null;

	private JTextField txt_DMRECNUM;
	@SuppressWarnings("unused")
	private JTextField txt_BrowserUnderTest;
	//private JDateChooser  txt_Defaultdate;
	private JComboBox<String> cBox_AUT;
	private JComboBox<String> cBox_sENV;
	private JComboBox<String> cbox_Browser;
	private JComboBox<String> cBox_DMAppend;
	private JComboBox<String> cBox_SMK_COLOBJS;
	private JComboBox<String> cBox_TDATA_ISBATCHPROC;
	private JComboBox<String> cBox_TDATA_TPKFETCH;
	private JComboBox<String> cBox_TDATA_TPK_REUSE;
	private JComboBox<String> cBox_TDATA_PROCDATAREF;
	private JPanel contentPane;
	private JTable table;
	private JLabel Dice;
	private JComboBox<String> cBox_ISEXITONFAIL;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					final UI_Frame_Update_TestSettings frame = new UI_Frame_Update_TestSettings();
					frame.setVisible(true);
					frame.addWindowListener(new java.awt.event.WindowAdapter() {
					    @Override
					    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
					        if (JOptionPane.showConfirmDialog(frame,"Are you sure to close this window?", "Really Closing?",JOptionPane.YES_NO_OPTION,
					            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
					        	try {
					        		connection.close();
						        	frame.dispose();
					        		UI_Frame_Dashboard homePage = new UI_Frame_Dashboard();
					        		homePage.setVisible(true);
								} catch (Exception e) {
									e.printStackTrace();
								}
					        }
					        else{
					        	frame.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
					        }
					    }
					});
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public UI_Frame_Update_TestSettings() throws Exception {
		try {
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}
		connection = DBUtils.DBConnect_Automation();

		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Dlogo.jpg")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 960, 600);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		final JLabel btnSave = new JLabel("SAVE");
		btnSave.setHorizontalAlignment(SwingConstants.CENTER);
		btnSave.setForeground(Color.WHITE);
		btnSave.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
		btnSave.setBackground(Color.BLACK);
		btnSave.setBorder(null);
		btnSave.setOpaque(true);
		btnSave.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e)
			{btnSave.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{btnSave.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{btnSave.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {btnSave.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent e) {


				if(cBox_TDATA_ISBATCHPROC.getSelectedItem().toString().isEmpty() )
					JOptionPane.showMessageDialog(null, "TDATA IS EMPTY");
				else if ( cBox_TDATA_ISBATCHPROC.getSelectedItem()==null ) {
					JOptionPane.showMessageDialog(null, "TDATA IS NULL");
				}

				int action = JOptionPane.showConfirmDialog(null, "Are you sure want to save", "Confirm",JOptionPane.YES_NO_OPTION );
				if(action ==0){
					pushSettings();
				}
			}
		});

		JLabel lblBack = new JLabel();
		lblBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				try {
					connection.close();
					dispose();
					UI_Frame_Dashboard objdshbrd = new UI_Frame_Dashboard();
					objdshbrd.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		lblBack.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "icon_back.png")));
		lblBack.setBounds(0, 0, 40, 30);
		lblBack.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblBack);

		btnSave.setBounds(825, 499, 90, 30);
		contentPane.add(btnSave);

		JLabel lblUpdateTestSettings = new JLabel("UPDATE TEST SETTINGS");
		lblUpdateTestSettings.setOpaque(true);
		lblUpdateTestSettings.setHorizontalAlignment(SwingConstants.CENTER);
		lblUpdateTestSettings.setForeground(Color.WHITE);
		lblUpdateTestSettings.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblUpdateTestSettings.setBackground(Color.BLACK);
		lblUpdateTestSettings.setBounds(0, 0, 954, 30);
		contentPane.add(lblUpdateTestSettings);

		JLabel label_9 = new JLabel("");
		label_9.setOpaque(true);
		label_9.setBackground(Color.BLACK);
		label_9.setBounds(0, 557, 954, 15);
		contentPane.add(label_9);

		txt_DMRECNUM = new JTextField();
		txt_DMRECNUM.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		txt_DMRECNUM.setColumns(10);
		txt_DMRECNUM.setBounds(557, 216, 198, 30);
		contentPane.add(txt_DMRECNUM);

		cbox_Browser = new JComboBox();
		cbox_Browser.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		cbox_Browser.addItem("IE");
		cbox_Browser.addItem("FIREFOX");
		cbox_Browser.addItem("CHROME");
		cbox_Browser.addItem("PHANTOM");
		cbox_Browser.setBounds(557, 134, 198, 30);
		contentPane.add(cbox_Browser);

		cBox_sENV = new JComboBox();
		cBox_sENV.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		cBox_sENV.setBounds(557, 93, 198, 30);
		contentPane.add(cBox_sENV);
		//Add_CBox_VALUES("Select * FROM ENV where APPLICATION = '"+cBox_AUT.getSelectedItem()+"'", "TEST_ENVIRONMENT", cBox_Environment);


		cBox_AUT = new JComboBox();
		cBox_AUT.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (cBox_sENV.getItemCount()>1) cBox_sENV.removeAllItems();
				Add_CBox_VALUES("Select * FROM ENV where APPLICATION = '"+cBox_AUT.getSelectedItem()+"'", "TEST_ENVIRONMENT", cBox_sENV);
			}
		});
		cBox_AUT.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		cBox_AUT.setBounds(557, 52, 198, 30);
		contentPane.add(cBox_AUT);
		Add_CBox_VALUES("Select DISTINCT APPLICATION FROM ENV", "APPLICATION", cBox_AUT);

		cBox_DMAppend = new JComboBox();
		cBox_DMAppend.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		cBox_DMAppend.setBounds(557, 175, 198, 30);
		contentPane.add(cBox_DMAppend);
		cBox_DMAppend.addItem("Y");
		cBox_DMAppend.addItem("N");

		table = new JTable(new DefaultTableModel(
			new Object[][] {
				{"Application under test"},
				{"Environment under test"},
				{"Browser under test"},
				{"Append data in Data Manager on refresh?"},
				{"Count of reference data fetched by DM per Test case"},
				{"Move to next test case if a step fails?"},
				{"Collect Objects during smoke test?"},
				{"Testdata processed by Batch job?"},
				{"Populate TPK in DM_MAP as part of Batch?"},
				{"Reuse TPKs?"},
				{"Autoprocess DATA_REF to populate TEST_DATA?"},
			},
			new String[] {
				"New column"
			}
		));
		table.setRowSelectionAllowed(false);
		table.setShowGrid(false);
		table.setOpaque(false);
		table.setForeground(Color.DARK_GRAY);
		((DefaultTableCellRenderer)table.getDefaultRenderer(Object.class)).setOpaque(false);
		table.setBorder(null);
		table.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		table.setRowHeight(40);
		table.setBounds(167, 52, 380, 452);
		contentPane.add(table);

		Dice = new JLabel("");
		Dice.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "dice2.png")));
		Dice.setBounds(10, 284, 162, 137);
		contentPane.add(Dice);

		cBox_SMK_COLOBJS = new JComboBox();
		cBox_SMK_COLOBJS.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		cBox_SMK_COLOBJS.setBounds(557, 295, 198, 30);
		contentPane.add(cBox_SMK_COLOBJS);
		cBox_SMK_COLOBJS.addItem("Y");
		cBox_SMK_COLOBJS.addItem("N");

		cBox_TDATA_ISBATCHPROC = new JComboBox();
		cBox_TDATA_ISBATCHPROC.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		cBox_TDATA_ISBATCHPROC.setBounds(557, 336, 198, 30);
		contentPane.add(cBox_TDATA_ISBATCHPROC);
		cBox_TDATA_ISBATCHPROC.addItem("Y");
		cBox_TDATA_ISBATCHPROC.addItem("N");

		cBox_TDATA_TPKFETCH = new JComboBox();
		cBox_TDATA_TPKFETCH.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		cBox_TDATA_TPKFETCH.setBounds(557, 375, 198, 30);
		contentPane.add(cBox_TDATA_TPKFETCH);
		cBox_TDATA_TPKFETCH.addItem("Y");
		cBox_TDATA_TPKFETCH.addItem("N");

		cBox_TDATA_TPK_REUSE = new JComboBox();
		cBox_TDATA_TPK_REUSE.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		cBox_TDATA_TPK_REUSE.setBounds(557, 416, 198, 30);
		contentPane.add(cBox_TDATA_TPK_REUSE);
		cBox_TDATA_TPK_REUSE.addItem("Y");
		cBox_TDATA_TPK_REUSE.addItem("N");

		cBox_TDATA_PROCDATAREF = new JComboBox();
		cBox_TDATA_PROCDATAREF.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		cBox_TDATA_PROCDATAREF.setBounds(557, 457, 198, 30);
		contentPane.add(cBox_TDATA_PROCDATAREF);
		cBox_TDATA_PROCDATAREF.addItem("Y");
		cBox_TDATA_PROCDATAREF.addItem("N");

		cBox_ISEXITONFAIL = new JComboBox();
		cBox_ISEXITONFAIL.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		cBox_ISEXITONFAIL.setBounds(557, 254, 198, 30);
		contentPane.add(cBox_ISEXITONFAIL);
		cBox_ISEXITONFAIL.addItem("Y");
		cBox_ISEXITONFAIL.addItem("N");

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "white1.jpg")));
		label.setBounds(0, 0, 954, 572);
		contentPane.add(label);

		populateSettings();

		/*txt_Defaultdate = new JDateChooser();
		txt_Defaultdate.setBounds(557, 257, 198, 30);
		contentPane.add(txt_Defaultdate);*/
	}

	public void populateSettings()
	{
		txt_DMRECNUM.setText(getSetting("DM_REC_NUM"));
		cbox_Browser.setSelectedItem(getSetting("BROWSER"));
		cBox_sENV.setSelectedItem(getSetting("ENVIRONMENT"));
		cBox_AUT.setSelectedItem(getSetting("AUT"));
		cBox_DMAppend.setSelectedItem(getSetting("DM_Append"));
		cBox_SMK_COLOBJS.setSelectedItem(getSetting("SMK_COLOBJS"));
		cBox_TDATA_PROCDATAREF.setSelectedItem(getSetting("TDATA_PROCDATAREF"));
		cBox_TDATA_TPK_REUSE.setSelectedItem(getSetting("TDATA_TPK_REUSE"));
		cBox_TDATA_TPKFETCH.setSelectedItem(getSetting("TDATA_TPKFETCH"));
		cBox_TDATA_ISBATCHPROC.setSelectedItem(getSetting("TDATA_ISBATCHPROC"));
		cBox_ISEXITONFAIL.setSelectedItem(getSetting("ISEXITONFAIL"));
	}

	public void pushSettings()
	{
		try {
			//Validation Messages should be there --Bharath
			setSetting("DM_REC_NUM",txt_DMRECNUM.getText());
			setSetting("BROWSER",cbox_Browser.getSelectedItem().toString());
			setSetting("ENVIRONMENT",cBox_sENV.getSelectedItem().toString());
			setSetting("AUT",cBox_AUT.getSelectedItem().toString());
			setSetting("DM_Append",cBox_DMAppend.getSelectedItem().toString());
			setSetting("SMK_COLOBJS",cBox_SMK_COLOBJS.getSelectedItem().toString());
			setSetting("TDATA_PROCDATAREF",cBox_TDATA_PROCDATAREF.getSelectedItem().toString());
			setSetting("TDATA_TPK_REUSE",cBox_TDATA_TPK_REUSE.getSelectedItem().toString());
			setSetting("TDATA_TPKFETCH",cBox_TDATA_TPKFETCH.getSelectedItem().toString());
			setSetting("TDATA_ISBATCHPROC",cBox_TDATA_ISBATCHPROC.getSelectedItem().toString());
		  setSetting("ISEXITONFAIL", cBox_ISEXITONFAIL.getSelectedItem().toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
			System.out.println("Some Of the filds are empty");

		}

		JOptionPane.showMessageDialog(null, "Settings Updated successufully");
	}

	public void Add_CBox_VALUES(String query, String dbColName, JComboBox<String> box)
	{
		try{
			PreparedStatement pst  = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				box.addItem(rs.getString(dbColName));
			}
			rs.close();
			pst.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	public void Populate_date(String sVALUE, JDateChooser box)
	{
	try {

		String query = "Select VALUE FROM SETTINGS WHERE SKEY = '"+sVALUE+"' ";
		PreparedStatement pst1  = connection.prepareStatement(query);
		ResultSet rs1 = pst1.executeQuery();
		while (rs1.next()) {

	//		box.setDateFormatString(rs1.getString("VALUE"));
		}
		rs1.close();
		pst1.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}

	public String getSetting(String keyName){
         String  str=null;
         try {
			ResultSet rs9=connection.createStatement().executeQuery("select VALUE from SETTINGS where SKEY ='"+keyName+"'");
			if (rs9.next()) str = rs9.getString("VALUE");
         } catch (SQLException e) {e.printStackTrace();}

         return str;
  }

	public void setSetting(String sKey, String sValue){
        try {
        	connection.createStatement().executeUpdate("update SETTINGS set VALUE='"+sValue+"' where SKEY='"+sKey+"'");
        } catch (SQLException e) {e.printStackTrace();}
	}

}

