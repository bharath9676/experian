package com.optum.coliseum.frame;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.WindowConstants;

import net.proteanit.sql.DbUtils;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.SystemColor;
import java.awt.Toolkit;
import javax.swing.border.LineBorder;

import com.optum.coliseum.driver.DataHandler;
import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.DBUtils;
import com.optum.coliseum.generic.GenericUtils;
import com.optum.coliseum.generic.Settings;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

@SuppressWarnings("serial")
public class UI_Frame_DataConfiguration extends JFrame
{
	public Connection con_APP;					static Connection connection =null;
	public String selectedTestCaseid;			public String Tid;
	public String DMid;							public String Mid;
	public String moduleID;		    			public String sTPK;
	public String Stepid;						public String tData;
	public String DMID;							public String All_dmid;
	public String No_dmid;						public String sDATAVALUE;
	public String yes_dmid;						public String testEnv;
	public int DM_REC_NUM;						public String sAUT;
	private JLabel lbl;							public String sRepFolder;
	private JTextField textField_Reason;
	public 	JTextField textField_Rqstr_nm;
	private JTextField textField_TPKSQL;
	public  JProgressBar ProgressBar1;
	private JComboBox<String> Append_comboBox ;
	private JPanel contentPane;
	public ResultSet rs;
	private JTable table_Sql;
	private JScrollPane scrollPane_sql;

	public void updateDB()
	{
		if(connection==null){System.out.println("Connection wasn't established");}
	 	try {
	 		Statement st12 = connection.createStatement();
	 		String sTimestamp 	= new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
	 		st12.executeUpdate("Insert Into DM_REF_HIST VALUES('"+sTimestamp+"', '"+textField_Rqstr_nm.getText()+"', '"+textField_Reason.getText()+"')");
			st12.executeUpdate("Update SETTINGS set VALUE = '"+textField_TPKSQL.getText()+"' where Skey='DM_REC_NUM' ");
			st12.executeUpdate("Update SETTINGS set VALUE = '"+(String)Append_comboBox.getSelectedItem()+"' where Skey='DM_APPEND' ");
			st12.close();
		}
	 	catch (Exception e2) {
			e2.printStackTrace();
		}
	}
	       // Launch the application.
	public static void main(String[] args) {
	       EventQueue.invokeLater(new Runnable() {
	       public void run() {
	    	   try {
			       final UI_Frame_DataConfiguration frame = new UI_Frame_DataConfiguration();
				   frame.setVisible(true);
				   frame.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
				   frame.addWindowListener(new java.awt.event.WindowAdapter() {
					    @Override
					    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
					        if (JOptionPane.showConfirmDialog(frame,"Are you sure to close this window?", "Really Closing?",JOptionPane.YES_NO_OPTION,
					            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
					        	try {
					        		connection.close();
					        		frame.dispose();
					        		UI_Frame_Dashboard homePage = new UI_Frame_Dashboard();
					        		homePage.setVisible(true);
								} catch (Exception e) {
									e.printStackTrace();
								}}
					        else{
					        	frame.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
					        }  }});} catch (Exception e) {
					e.printStackTrace();
				}}});}

	/*###############################
	    * Create the frame.
	   #################################*/

	/**
	 * @throws Exception
	 */
	@SuppressWarnings("deprecation")
	public UI_Frame_DataConfiguration() throws Exception {

		try {
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}

		connection = DBUtils.DBConnect_Automation();
		sAUT = Settings.getSetting("AUT", connection);
		setIconImage(Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Dlogo.jpg")));
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(0, 0, 960, 600);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblBack = new JLabel();
		lblBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				try {
					connection.close();
					dispose();
					UI_Frame_Dashboard objdshbrd = new UI_Frame_Dashboard();
					objdshbrd.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		lblBack.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "icon_back.png")));
		lblBack.setBounds(0, 0, 40, 30);
		lblBack.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblBack);

		   JLabel lblAnalyzeDatabank = new JLabel("ANALYZE DATABANK");
		   lblAnalyzeDatabank.setOpaque(true);
		   lblAnalyzeDatabank.setHorizontalAlignment(SwingConstants.CENTER);
		   lblAnalyzeDatabank.setForeground(Color.WHITE);
		   lblAnalyzeDatabank.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
		   lblAnalyzeDatabank.setBorder(null);
		   lblAnalyzeDatabank.setBackground(Color.GRAY);
		   lblAnalyzeDatabank.setBounds(500, 64, 361, 30);
		   contentPane.add(lblAnalyzeDatabank);

		   JLabel lblNewLabel_1 = new JLabel("CONFIGURATION SETTINGS");
	        lblNewLabel_1.setBorder(null);
	        lblNewLabel_1.setOpaque(true);
	        lblNewLabel_1.setBackground(new Color(128, 128, 128));
	        lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
	        lblNewLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
	        lblNewLabel_1.setForeground(Color.WHITE);
	        lblNewLabel_1.setBounds(101, 64, 361, 30);
	        contentPane.add(lblNewLabel_1);

	        JLabel lblNewLabel_2 = new JLabel("Requester Name");
	        lblNewLabel_2.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
	        lblNewLabel_2.setForeground(new Color(105, 105, 105));
	        lblNewLabel_2.setBounds(121, 415, 113, 30);
	        contentPane.add(lblNewLabel_2);

	        JLabel lblBankTpkCount = new JLabel("Bank TPK count per SQL");
	        lblBankTpkCount.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
	        lblBankTpkCount.setForeground(new Color(105, 105, 105));
	        lblBankTpkCount.setBounds(111, 111, 171, 30);
	        contentPane.add(lblBankTpkCount);

	        JLabel lblDeleteOldRecords = new JLabel("Preserve existing DM data");
	        lblDeleteOldRecords.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
	        lblDeleteOldRecords.setForeground(new Color(105, 105, 105));
	        lblDeleteOldRecords.setBounds(111, 152, 200, 30);
	        contentPane.add(lblDeleteOldRecords);

	        textField_Rqstr_nm = new JTextField();
	        textField_Rqstr_nm.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
	        textField_Rqstr_nm.setBounds(260, 416, 313, 30);
	        textField_Rqstr_nm.setEditable(false);
	        contentPane.add(textField_Rqstr_nm);
	        textField_Rqstr_nm.setColumns(10);

	        DisplayUserDetails();
	        textField_TPKSQL = new JTextField();
	        textField_TPKSQL.setBounds(359, 112, 77, 30);
	        contentPane.add(textField_TPKSQL);
	        textField_TPKSQL.setColumns(10);
	        textField_TPKSQL.setText(Settings.getSetting("DM_REC_NUM", connection));


	        Append_comboBox = new JComboBox<String>();
	        Append_comboBox.setBounds(359, 153, 77, 30);
	        Append_comboBox.addItem("Y");
	        Append_comboBox.addItem("N");
	        Append_comboBox.setSelectedItem(Settings.getSetting("DM_APPEND", connection));
	        contentPane.add(Append_comboBox);

	        JLabel lblNewLabel_3 = new JLabel("Process scheduled only");
	        lblNewLabel_3.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
	        lblNewLabel_3.setForeground(new Color(128, 128, 128));
	        lblNewLabel_3.setBounds(111, 193, 154, 30);
	        contentPane.add(lblNewLabel_3);

	        lbl = new JLabel("");
	        lbl.setForeground(new Color(105, 105, 105));
	        lbl.setBounds(615, 41, 86, 14);
	        contentPane.add(lbl);

	        ProgressBar1 = new JProgressBar();
            ProgressBar1.setStringPainted(true);
            ProgressBar1.setBounds(135, 351, 683, 23);
            contentPane.add(ProgressBar1);

	        final JLabel btn_TriggerConfs = new JLabel("TRIGGER");
	        btn_TriggerConfs.setHorizontalAlignment(SwingConstants.CENTER);
	        btn_TriggerConfs.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	        btn_TriggerConfs.setForeground(Color.WHITE);
	        btn_TriggerConfs.setBackground(Color.BLACK);
	        btn_TriggerConfs.setBorder(null);
	        btn_TriggerConfs.setOpaque(true);
	        btn_TriggerConfs.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e)
				{btn_TriggerConfs.setBackground(new Color(255, 165, 0));}
				public void mouseExited(MouseEvent e)
				{btn_TriggerConfs.setBackground(Color.BLACK);}
				public void mousePressed(MouseEvent arg0)
				{btn_TriggerConfs.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
		        public void mouseReleased(MouseEvent arg0)
		        {btn_TriggerConfs.setBorder(new LineBorder(new Color(192, 192, 192)));}
				public void mouseClicked(MouseEvent e) {
			   try {
				   int action = 1;
				 	if (textField_Reason.getText().equals("")) Msgbox.msgbox( "Please enter Request Reason");
				 	else if (textField_Rqstr_nm.getText().equals("")) Msgbox.msgbox( "Please enter Requester Name");
				 	else if (!getAuthStatus()) Msgbox.msgbox("You do not have sufficient privilleges to refresh DM!");
			 		else{
			 			action = JOptionPane.showConfirmDialog(null, "Are you sure you want to proceed with Execution", "CONFIRMATION",JOptionPane.YES_NO_OPTION );
			 		 	if(action ==0){
			    			updateDB();
			    			con_APP = DBUtils.DBConnect_Application();
			    			dataManager  DMRefresh = new dataManager();
			    			DMRefresh.execute();
			    		}
				    }
			  }
					catch (Exception e1) {
					e1.printStackTrace();
			  }
			  }
	          });
	        btn_TriggerConfs.setBounds(686, 433, 112, 30);
	        contentPane.add(btn_TriggerConfs);

	        JLabel lblInitiateConfiguration = new JLabel("DATA MANAGER REFRESH");
	        lblInitiateConfiguration.setOpaque(true);
	        lblInitiateConfiguration.setHorizontalAlignment(SwingConstants.CENTER);
	        lblInitiateConfiguration.setForeground(Color.WHITE);
	        lblInitiateConfiguration.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
	        lblInitiateConfiguration.setBorder(null);
	        lblInitiateConfiguration.setBackground(Color.GRAY);
	        lblInitiateConfiguration.setBounds(101, 272, 760, 30);
	        contentPane.add(lblInitiateConfiguration);

	        JLabel lblTestManagement = new JLabel("MANAGE TEST DATA");
	        lblTestManagement.setOpaque(true);
	        lblTestManagement.setHorizontalAlignment(SwingConstants.CENTER);
	        lblTestManagement.setForeground(Color.WHITE);
	        lblTestManagement.setFont(new Font("Calibri", Font.PLAIN, 18));
	        lblTestManagement.setBackground(Color.BLACK);
	        lblTestManagement.setBounds(0, 0, 954, 30);
	        contentPane.add(lblTestManagement);

	        JLabel label_1 = new JLabel("");
	        label_1.setOpaque(true);
	        label_1.setBackground(Color.BLACK);
	        label_1.setBounds(0, 557, 954, 15);
	        contentPane.add(label_1);

	        JLabel lblRequestReason = new JLabel("Request reason");
	        lblRequestReason.setForeground(SystemColor.controlDkShadow);
	        lblRequestReason.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
	        lblRequestReason.setBounds(121, 452, 113, 30);
	        contentPane.add(lblRequestReason);

	        textField_Reason = new JTextField();
	        textField_Reason.setFont(new Font("Tahoma", Font.PLAIN, 11));
	        textField_Reason.setColumns(10);
	        textField_Reason.setBounds(260, 453, 313, 30);
	        contentPane.add(textField_Reason);

			JLabel lblApplication = new JLabel("APPLICATION: "+sAUT);
			lblApplication.setFont(new Font("Tahoma", Font.BOLD, 13));
			lblApplication.setForeground(Color.GRAY);
			lblApplication.setBounds(689, 31, 129, 32);
			contentPane.add(lblApplication);

			final JLabel lblChange = new JLabel("Change");
			lblChange.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e){
					try {
						try {connection.close();} catch (SQLException e1) {e1.printStackTrace();}
						connection.close();
		        		dispose();
						UI_Frame_Update_TestSettings objUI =new  UI_Frame_Update_TestSettings();
						objUI.setVisible(true);
						objUI.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
					} catch (Exception e1) {
						e1.printStackTrace();
				}
				}			@Override
				public void mouseEntered(MouseEvent e)
				{lblChange.setForeground(Color.RED);}
				public void mouseExited(MouseEvent e)
				{lblChange.setForeground(Color.BLUE);}
				public void mousePressed(MouseEvent arg0)
				{lblChange.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
				public void mouseReleased(MouseEvent arg0)
				{lblChange.setBorder(null);}
	});
			lblChange.setForeground(Color.BLUE);
			lblChange.setBounds(815, 41, 46, 14);
			contentPane.add(lblChange);

	        JPanel panel_1 = new JPanel();
	        panel_1.setBorder(new LineBorder(new Color(105, 105, 105)));
	        panel_1.setBounds(100, 272, 761, 251);
	        contentPane.add(panel_1);

	        JComboBox<String> comboBox = new JComboBox<String>();
	        comboBox.setBounds(359, 194, 77, 30);
	        comboBox.addItem("--Select--");
	        comboBox.addItem("Y");
	        comboBox.addItem("N");
	        contentPane.add(comboBox);
	        comboBox.enable(false);

	        JPanel panel_2 = new JPanel();
	        panel_2.setOpaque(false);
	        panel_2.setBorder(new LineBorder(Color.GRAY));
	        panel_2.setBounds(101, 64, 361, 181);
	        contentPane.add(panel_2);

	        scrollPane_sql = new JScrollPane();
			scrollPane_sql.setBackground(Color.WHITE);
			scrollPane_sql.setBounds(500, 96, 361, 146);
			getContentPane().add(scrollPane_sql);

			table_Sql = new JTable();
			table_Sql.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
			table_Sql.setShowHorizontalLines(false);
			table_Sql.setShowVerticalLines(false);
			table_Sql.setBackground(Color.WHITE);
			UpdateAnalysisTable();

			JLabel labelBG = new JLabel("");
			labelBG.setIcon(new ImageIcon("src\\main\\resources\\Media\\white1.jpg"));
			labelBG.setBounds(0, 0, 954, 561);
			contentPane.add(labelBG);

	    }
	public void UpdateAnalysisTable(){
		ResultSet rs8 = null;
		try{
			String query8 = "Select distinct T1.MODULEID, T1.TCID, AVAILABLE, (Total - Available) AS CONSUMED, TOTAL from TC_SCHEDULER TS, MOD_SCHEDULER MS, "
							+ "(Select DP.MODULEID, DP.TCID, count(DM.DMID) AS TOTAL from DM, DM_MAP DP where DM.DMID = DP.DMID group by DP.MODULEID, DP.TCID) AS T1,"
							+ "(Select DP.MODULEID, DP.TCID, count(DM.DMID) AS AVAILABLE from DM, DM_MAP DP where DM.DMID = DP.DMID and USED_IND = 'N' group by DP.MODULEID, DP.TCID) AS T3 "
							+ "where TS.MODULEID = MS.MODULEID and TS.MODULEID = T1.MODULEID and TS.APPLICATION = '"+sAUT+"' "
							+ "and T1.MODULEID = T3.MODULEID and T1.TCID = T3.TCID order by T1.MODULEID, T1.TCID" ;
			rs8 = connection.createStatement().executeQuery(query8);
			if (rs8!=null) table_Sql.setModel(DbUtils.resultSetToTableModel(rs8));
		}	catch(Exception etc){etc.printStackTrace();}
		scrollPane_sql.setViewportView(table_Sql);
		GenericUtils.setCellsAlignment(table_Sql, SwingConstants.CENTER);
	}

	public void DisplayUserDetails() throws Exception, Exception{
		 ResultSet rs9 = connection.createStatement().executeQuery("SELECT FNAME, LNAME FROM USERS  WHERE  USER_NAME = '"+Settings.getSetting("ACT_USER", connection)+"' ");
		 if(rs9.next()){
			 textField_Rqstr_nm.setText(rs9.getString("FNAME")+" "+rs9.getString("LNAME"));
		 }
	}

	public void DataManager() {
	    ProgressBar1.setMinimum(0);
	    DataHandler.ProcessDMAppend(connection, sAUT, sRepFolder);

	    try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}

	    DM_REC_NUM = Integer.parseInt(Settings.getSetting("DM_REC_NUM", connection));

	    int iDMCount = 0;
	    try {
			ResultSet rs06=connection.createStatement().executeQuery("Select Count(*) AS COUNT from [SQLS] where sqlid like '%DM%' and application = '"+sAUT+"'" );
			if (rs06.next()) iDMCount = Integer.parseInt(rs06.getString("COUNT"));
		} catch (NumberFormatException e) {e.printStackTrace();} catch (SQLException e) {e.printStackTrace();}

	    if (iDMCount==0) Msgbox.msgbox("Nothing to process. No DM queries found for the selected application!");
	    else{
		    ProgressBar1.setMaximum(iDMCount * DM_REC_NUM);

		    int iCnt = 0;
		    try {
				ResultSet rs9=connection.createStatement().executeQuery("Select SQLID, esql from [SQLS] where sqlid like '%DM%' and application = '"+sAUT+"'" );
				while (rs9.next()){
					com.optum.coliseum.driver.DataHandler.RefreshDMRecord(connection, con_APP, rs9.getString("SQLID"), rs9.getString("eSQL"), DM_REC_NUM, sRepFolder);
					iCnt = iCnt + 1;
					ProgressBar1.setValue(iCnt);
				}
			} catch (SQLException e) {e.printStackTrace();}

			System.out.println("############### Data Manager execution completed! ###############");
			UpdateAnalysisTable();
	    }
	}

	class dataManager extends SwingWorker<Object, Object>
    {
        @Override
        public Void doInBackground()throws Exception {
            DataManager();
            ProgressBar1.setValue(100);
            Msgbox.msgbox("Processing completed successfully!");
            ProgressBar1.setValue(0);
            return null;
        }
    }

    public boolean getAuthStatus(){
		boolean sPRIV = false;
					try {
						ResultSet resultSet = connection.createStatement().executeQuery("Select PRIVILEGE from USERS where USER_NAME = (SELECT VALUE FROM SETTINGS WHERE SKEY = 'ACT_USER')");
						if (resultSet.next()) if (resultSet.getString("PRIVILEGE").equalsIgnoreCase("A")) sPRIV = true;
						resultSet.close();
					} catch (SQLException e) {e.printStackTrace();}
				return sPRIV;
		}
}

