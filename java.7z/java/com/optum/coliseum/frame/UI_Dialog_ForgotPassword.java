package com.optum.coliseum.frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;

import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.DBUtils;

public class UI_Dialog_ForgotPassword extends JDialog {

	private static final long serialVersionUID = 1L;
	private JTextField txt_MSID;
	private JTextField txt_LastName;
	private JTextField txt_SecurityAnswer;
	private JTextField lbl_DisplaySecurityQuestion;
	public JLabel lbl_RETPASSWORD;
	public String SecurityQ;
	public String sPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UI_Dialog_ForgotPassword dialog = new UI_Dialog_ForgotPassword();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public UI_Dialog_ForgotPassword() {
		try {
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}
		setTitle("Coliseum - Forgot Password");
		setResizable(false);
		getContentPane().setBackground(Color.WHITE);
		setBounds(100, 100, 450, 529);
		setLocationRelativeTo(null);
		getContentPane().setLayout(null);

		JLabel lblRequestersLastName = new JLabel("Your Last Name");
		lblRequestersLastName.setForeground(Color.DARK_GRAY);
		lblRequestersLastName.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		lblRequestersLastName.setBounds(25, 123, 130, 30);
		getContentPane().add(lblRequestersLastName);

		JLabel lblRequestersMsid = new JLabel("Your MSID");
		lblRequestersMsid.setForeground(Color.DARK_GRAY);
		lblRequestersMsid.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		lblRequestersMsid.setBounds(25, 82, 130, 30);
		getContentPane().add(lblRequestersMsid);

		txt_MSID = new JTextField();
		txt_MSID.setBorder(new LineBorder(Color.LIGHT_GRAY));
		txt_MSID.setColumns(10);
		txt_MSID.setBounds(165, 83, 235, 30);
		getContentPane().add(txt_MSID);

		txt_LastName = new JTextField();
		txt_LastName.setBorder(new LineBorder(Color.LIGHT_GRAY));
		txt_LastName.setColumns(10);
		txt_LastName.setBounds(165, 124, 235, 30);
		getContentPane().add(txt_LastName);

		JLabel lblPasswordRetrievalForm = new JLabel("PASSWORD RECOVERY FORM");
		lblPasswordRetrievalForm.setHorizontalAlignment(SwingConstants.CENTER);
		lblPasswordRetrievalForm.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 13));
		lblPasswordRetrievalForm.setForeground(Color.WHITE);
		lblPasswordRetrievalForm.setBackground(Color.BLACK);
		lblPasswordRetrievalForm.setOpaque(true);
		lblPasswordRetrievalForm.setBounds(0, 0, 444, 30);
		getContentPane().add(lblPasswordRetrievalForm);

		JLabel label_1 = new JLabel("");
		label_1.setOpaque(true);
		label_1.setBackground(Color.BLACK);
		label_1.setBounds(0, 491, 444, 10);
		getContentPane().add(label_1);

		JLabel lbl_SecurityQuestion = new JLabel("Security Question");
		lbl_SecurityQuestion.setForeground(Color.DARK_GRAY);
		lbl_SecurityQuestion.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		lbl_SecurityQuestion.setBounds(27, 234, 130, 30);
		getContentPane().add(lbl_SecurityQuestion);

		JLabel lbl_SecurityAnswer = new JLabel("Security Answer");
		lbl_SecurityAnswer.setForeground(Color.DARK_GRAY);
		lbl_SecurityAnswer.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		lbl_SecurityAnswer.setBounds(27, 283, 130, 30);
		getContentPane().add(lbl_SecurityAnswer);

		txt_SecurityAnswer = new JTextField();
		txt_SecurityAnswer.setBorder(new LineBorder(Color.LIGHT_GRAY));
		txt_SecurityAnswer.setColumns(10);
		txt_SecurityAnswer.setBounds(165, 283, 235, 30);
		getContentPane().add(txt_SecurityAnswer);

		JLabel label_5 = new JLabel("");
		label_5.setVerifyInputWhenFocusTarget(false);
		label_5.setOpaque(true);
		label_5.setBorder(null);
		label_5.setBackground(Color.LIGHT_GRAY);
		label_5.setBounds(0, 369, 444, 5);
		getContentPane().add(label_5);

		JLabel label_4 = new JLabel("");
		label_4.setBorder(null);
		label_4.setOpaque(true);
		label_4.setVerifyInputWhenFocusTarget(false);
		label_4.setBackground(Color.LIGHT_GRAY);
		label_4.setBounds(0, 209, 444, 5);
		getContentPane().add(label_4);

		final JLabel lblGetSecurityQuestion = new JLabel("GET SECURITY QUESTION");
		lblGetSecurityQuestion.setOpaque(true);
		lblGetSecurityQuestion.setHorizontalAlignment(SwingConstants.CENTER);
		lblGetSecurityQuestion.setForeground(Color.WHITE);
		lblGetSecurityQuestion.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		lblGetSecurityQuestion.setBackground(Color.BLACK);
		lblGetSecurityQuestion.setBounds(165, 165, 235, 22);
		lblGetSecurityQuestion.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e)
			{lblGetSecurityQuestion.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{lblGetSecurityQuestion.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{lblGetSecurityQuestion.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {lblGetSecurityQuestion.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent e) {
				int iFlag = 1;
				try {
					if (txt_MSID.getText().equals("")){
						lbl_RETPASSWORD.setText("Please enter requester's MSID");
						 iFlag = 0;
					}
					else if (txt_LastName.getText().equals("")){
						lbl_RETPASSWORD.setText("Please enter requester's Last Name");
						 iFlag = 0;
					}
					if (iFlag == 1) {
						SecurityQ = GetSecurityQuestion();
						if (!(SecurityQ == null)){
								lbl_DisplaySecurityQuestion.setText(SecurityQ);
								lbl_RETPASSWORD.setText("");
							}
							else {
								lbl_DisplaySecurityQuestion.setText("---");
								lbl_RETPASSWORD.setText("No record exists with this MSID and Last Name");
							}
					}
				}
				catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
				}
			}});
		getContentPane().add(lblGetSecurityQuestion);

		final JLabel lblRetPassword = new JLabel("RETRIEVE PASSWORD");
		lblRetPassword.setBackground(Color.BLACK);
		lblRetPassword.setForeground(Color.WHITE);
		lblRetPassword.setOpaque(true);
		lblRetPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblRetPassword.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		lblRetPassword.setBounds(167, 324, 235, 22);
		lblRetPassword.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e)
			{lblRetPassword.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{lblRetPassword.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{lblRetPassword.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {lblRetPassword.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent e) {
				try {
						if (lbl_DisplaySecurityQuestion.getText().equals("---")){
							lbl_RETPASSWORD.setText("Please retrieve Security Question first!");
						}
						else{
							if (txt_SecurityAnswer.getText().equals("")){
								lbl_RETPASSWORD.setText("Please enter Security Answer");
							}
							else {sPassword = fetchPassword();
								if (sPassword == null){
									lbl_RETPASSWORD.setText("Incorrect Answer!");
								}
								else {
									lbl_RETPASSWORD.setText("Your password is : "+sPassword);
								}
							}
						}
				} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
				}
			}
		});
		getContentPane().add(lblRetPassword);


		lbl_DisplaySecurityQuestion = new JTextField();
		lbl_DisplaySecurityQuestion.setBorder(null);
		lbl_DisplaySecurityQuestion.setText("---");
		lbl_DisplaySecurityQuestion.setOpaque(false);
		lbl_DisplaySecurityQuestion.setColumns(10);
		lbl_DisplaySecurityQuestion.setBounds(165, 235, 235, 30);
		getContentPane().add(lbl_DisplaySecurityQuestion);

		lbl_RETPASSWORD = new JLabel("");
		lbl_RETPASSWORD.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_RETPASSWORD.setForeground(Color.RED);
		lbl_RETPASSWORD.setFont(new Font("Tahoma", Font.BOLD, 12));
		lbl_RETPASSWORD.setBounds(10, 407, 424, 30);
		getContentPane().add(lbl_RETPASSWORD);

		JLabel lblNewLabel = new JLabel("Responses are case sensitive");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel.setBounds(10, 466, 247, 14);
		getContentPane().add(lblNewLabel);

		JLabel label_6 = new JLabel("");
		label_6.setVerifyInputWhenFocusTarget(false);
		label_6.setOpaque(true);
		label_6.setBorder(null);
		label_6.setBackground(Color.LIGHT_GRAY);
		label_6.setBounds(0, 48, 444, 5);
		getContentPane().add(label_6);

		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "white1.jpg")));

		label_3.setBounds(0, 370, 444, 120);
		getContentPane().add(label_3);

		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "white1.jpg")));
		label_2.setBounds(0, 0, 444, 53);
		getContentPane().add(label_2);

	}

	public String GetSecurityQuestion() throws Exception{
		Connection Tcon = null;
		String SecQ = null;
		Tcon = DBUtils.DBConnect_Automation();
		String sQuery = "SELECT SECURITY_Q FROM USERS WHERE USER_NAME = '"+ txt_MSID.getText() + "' and LNAME = '"+ txt_LastName.getText()+ "'";
		try {
			PreparedStatement statement = Tcon.prepareStatement(sQuery);
			statement.executeQuery();
			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				SecQ = rs.getString("SECURITY_Q");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Tcon.close();
		return SecQ;
	}

	public String fetchPassword() throws Exception {
		Connection Tcon = null;
		String sPWD = null;
		Tcon = DBUtils.DBConnect_Automation();
		String sQuery = "SELECT PASSWORD FROM USERS WHERE USER_NAME = '"+ txt_MSID.getText() + "' and LNAME = '"+ txt_LastName.getText()+ "'and SECURITY_A = '"+ txt_SecurityAnswer.getText()+ "'";
		try {
			PreparedStatement statement = Tcon.prepareStatement(sQuery);
			statement.executeQuery();
			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				sPWD = rs.getString("PASSWORD");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Tcon.close();
		return sPWD;

	}
}
