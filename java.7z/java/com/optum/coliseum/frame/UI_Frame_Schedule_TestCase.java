package com.optum.coliseum.frame;

import java.awt.BorderLayout;
import java.awt.BorderLayout;
import java.awt.BorderLayout;
import java.awt.BorderLayout;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.DBUtils;
import com.optum.coliseum.generic.Settings;

@SuppressWarnings({ "serial", "unused" })
public class UI_Frame_Schedule_TestCase extends JFrame {

	private JPanel contentPane;
	private JFrame frame;
	private JTable table;
	private JTable table3;
	private JTable table4;
	private JLabel lbl;
	private static Connection connection;
	Vector<Vector<Object>> data;
	JScrollPane ST_scrollPane_2;
	DefaultTableModel tb2model;
	Box horizontalBox;
	@SuppressWarnings("rawtypes")
	JComboBox MN_comboBox;
	Vector<Vector<Object>> data1;
	JScrollPane scrollPane_3;
	DefaultTableModel tb2model1;
	Box horizontalBox1;
	JScrollPane scrollPane5;
	Box horizontalBox_2;
	private Box horizontalBox_2_1;
	Box horizontalBox_1;
	Box horizontalBox_3;
	DefaultTableModel tb2model5;
	public static String sAUT;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					final UI_Frame_Schedule_TestCase frame = new UI_Frame_Schedule_TestCase();
					frame.setVisible(true);
					frame.addWindowListener(new java.awt.event.WindowAdapter() {
				    @Override
				    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				        if (JOptionPane.showConfirmDialog(frame,"Are you sure to close this window?", "Really Closing?",JOptionPane.YES_NO_OPTION,
				            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
				        	try {
				        		connection.close();
				        		frame.dispose();
				        		UI_Frame_Dashboard homePage = new UI_Frame_Dashboard();
				        		homePage.setVisible(true);
							} catch (Exception e) {
								e.printStackTrace();
							}}
				        else{
				        	frame.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
				        }  }});}
				catch (Exception e) {e.printStackTrace();}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public UI_Frame_Schedule_TestCase() {

		try {
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}

		setIconImage(Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Dlogo.jpg")));
		setResizable(false);
		connection = DBUtils.DBConnect_Automation();
		sAUT = Settings.getSetting("AUT", connection);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 960, 600);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblScheduleModules = new JLabel("SCHEDULE MODULES");
		lblScheduleModules.setHorizontalAlignment(SwingConstants.CENTER);
		lblScheduleModules.setBackground(new Color(105, 105, 105));
		lblScheduleModules.setOpaque(true);
		lblScheduleModules.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
		lblScheduleModules.setForeground(Color.WHITE);
		lblScheduleModules.setBounds(81, 70, 373, 30);
		contentPane.add(lblScheduleModules);

		JLabel lblScheduleTestCases = new JLabel("                        SCHEDULE TEST CASES");
		lblScheduleTestCases.setBackground(new Color(105, 105, 105));
		lblScheduleTestCases.setOpaque(true);
		lblScheduleTestCases.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
		lblScheduleTestCases.setForeground(Color.WHITE);
		lblScheduleTestCases.setBounds(479, 71, 417, 30);
		contentPane.add(lblScheduleTestCases);

		JLabel lblModuleName = new JLabel("Select Module Name");
		lblModuleName.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
		lblModuleName.setForeground(Color.BLACK);
		lblModuleName.setBounds(489, 107, 192, 30);
		contentPane.add(lblModuleName);
		Vector<Object> cols = new Vector<Object>();
		cols.addElement("Module Name");
		cols.addElement("Execute?");
		Vector<Vector<Object>> rows = null;
		try {
			PreparedStatement statement = connection
					.prepareStatement("select MODULE_NAME,EXEC_FLAG from MOD_SCHEDULER where APPLICATION = '"+sAUT+"' ORDER BY MODULEID");
			ResultSet rs = statement.executeQuery();
			rows = new Vector<Vector<Object>>();
			while (rs.next()) {
				Vector<Object> newRow = new Vector<Object>();
				newRow.addElement(rs.getString(1));
				String flag = rs.getString(2);
				if ("YES".equals(flag)) {
					newRow.addElement(Boolean.TRUE);
				} else {
					newRow.addElement(Boolean.FALSE);
				}
				rows.add(newRow);
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
		DefaultTableModel model = new DefaultTableModel(rows, cols);
		table = new JTable(model) {
			private static final long serialVersionUID = 1L;
			@Override
			public Class getColumnClass(int column) {
				switch (column) {
				case 0:
					return String.class;
				default:
					return Boolean.class;
				}
			}
		};
		table.setPreferredScrollableViewportSize(table.getPreferredSize());

		JScrollPane SM_scrollPane = new JScrollPane(table);
		SM_scrollPane.setBounds(91, 111, 373, 132);
		contentPane.add(SM_scrollPane);

		Box horizontalBox_1 = Box.createHorizontalBox();
		SM_scrollPane.setColumnHeaderView(horizontalBox_1);

		final JLabel SM_btnSave = new JLabel("SAVE");
		SM_btnSave.setHorizontalAlignment(SwingConstants.CENTER);
		SM_btnSave.setOpaque(true);
		SM_btnSave.setBackground(new Color(0, 0, 0));
		SM_btnSave.setForeground(new Color(255, 255, 255));
		SM_btnSave.setFont(new Font("Trebuchet MS", Font.PLAIN, 11));
		SM_btnSave.setBounds(410, 255, 45, 23);
		SM_btnSave.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e)
			{SM_btnSave.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{SM_btnSave.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{SM_btnSave.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {SM_btnSave.setBorder(new LineBorder(new Color(192, 192, 192)));}
			public void mouseClicked(MouseEvent arg0) {
				TableModel model = table.getModel();
				for (int i = 0; i < model.getRowCount(); i++) {
					String mode = (String) model.getValueAt(i, 0);
					String flag = "NO";
					if ((boolean) model.getValueAt(i, 1)) {
						flag = "YES";
					}
					try {
						PreparedStatement st = connection.prepareStatement(
								"update MOD_SCHEDULER set EXEC_FLAG='" + flag + "' where MODULE_NAME='" + mode + "' and APPLICATION = '"+sAUT+"'");
						st.execute();
						st.close();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					if (MN_comboBox != null) {
						MN_comboBox.removeAllItems();
						for (String ite : getComboData()) {
							MN_comboBox.addItem(ite);
						}
					}

					try {
						String query2 = "select COUNT(*) As c from MOD_SCHEDULER where EXEC_FLAG = 'YES' and APPLICATION = '"+sAUT+"'";
						PreparedStatement statement1 = connection.prepareStatement(query2);
						ResultSet resultSet1 = statement1.executeQuery();
						while(resultSet1.next()){
						int  str= resultSet1.getInt("c");
						lbl.setText("" + str);
						}
					} catch (SQLException e1) {
						e1.printStackTrace();

					}

				}
				JOptionPane.showMessageDialog(null, "Schedule updated successfully");
			}
		});
		contentPane.add(SM_btnSave);

		MN_comboBox = new JComboBox();
		MN_comboBox.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
		MN_comboBox.setBounds(677, 111, 219, 30);
		MN_comboBox.removeAllItems();
		for (String ite : getComboData()) {
			MN_comboBox.addItem(ite);
		}
		contentPane.add(MN_comboBox);

		JLabel lblCountOfScheduled = new JLabel("Count of scheduled Modules :");
		lblCountOfScheduled.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
		lblCountOfScheduled.setForeground(new Color(255, 140, 0));
		lblCountOfScheduled.setBounds(81, 330, 211, 30);
		contentPane.add(lblCountOfScheduled);

		lbl = new JLabel("");
		lbl.setFont(new Font("Microsoft Sans Serif", Font.BOLD, 14));
		lbl.setForeground(Color.BLACK);
		lbl.setBounds(308, 330, 37, 30);
		contentPane.add(lbl);
		getTable(null);

		try {
			String query2 = "select COUNT(*) As c from MOD_SCHEDULER where EXEC_FLAG = 'YES' and APPLICATION = '"+sAUT+"'";
			PreparedStatement statement1 = connection.prepareStatement(query2);
			ResultSet resultSet1 = statement1.executeQuery();
			while(resultSet1.next()){
			int  str= resultSet1.getInt("c");
			lbl.setText("" + str);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		MN_comboBox.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				String item = (String) e.getItem();
				getTable(item);
				SwingUtilities.updateComponentTreeUI(contentPane);
			}
		});
		getScheduleSummary(null);
		}

	private void getTable(String item) {
	if (horizontalBox != null) {
		contentPane.remove(horizontalBox);
		}
	horizontalBox = Box.createHorizontalBox();
	horizontalBox.setBounds(479, 163, 417, 352);
	contentPane.add(horizontalBox);
	Vector<Object> tb2col = new Vector<Object>();
	tb2col.addElement("TCID");
	tb2col.addElement("Test Case Name");
	tb2col.addElement("Execute?");
	try {
		PreparedStatement statement1 = null;
		if (item == null) {
			statement1 = connection.prepareStatement(
					"select t.TCID,t.TC_DESC,t.EXEC_FLAG from TC_SCHEDULER t,MOD_SCHEDULER m where m.MODULEID=t.MODULEID and m.MODULE_NAME='"
							+ item + "' and T.APPLICATION = '"+sAUT+"' ORDER BY t.TCID");
		} else {
			statement1 = connection.prepareStatement(
					"select t.TCID,t.TC_DESC,t.EXEC_FLAG from TC_SCHEDULER t,MOD_SCHEDULER m where m.MODULEID=t.MODULEID and m.MODULE_NAME='"
							+ item + "' and T.APPLICATION = '"+sAUT+"' ORDER BY t.TCID");
		}
		ResultSet rs1 = statement1.executeQuery();
		data = new Vector<Vector<Object>>();
		while (rs1.next()) {
			Vector<Object> newRow = new Vector<Object>();
			newRow.addElement(rs1.getString(1));
			newRow.addElement(rs1.getString(2));
			String flag = rs1.getString(3);
			if ("YES".equals(flag)) {
				newRow.addElement(Boolean.TRUE);
			} else {
				newRow.addElement(Boolean.FALSE);
			}
			data.add(newRow);
		}
		rs1.close();
		statement1.close();
	} catch (SQLException e1) {
		e1.printStackTrace();
	}
	tb2model = new DefaultTableModel(data, tb2col);
	tb2model.fireTableDataChanged();
	table3 = new JTable(tb2model) {
	private static final long serialVersionUID = 1L;
		//@SuppressWarnings({ "unchecked", "rawtypes" })
		@Override
		public Class<?> getColumnClass(int column) {
			switch (column) {
			case 0:
				return String.class;
			case 1:
				return String.class;
			default:
				return Boolean.class;
			}
		}
	};
	table3.setPreferredScrollableViewportSize(table3.getPreferredSize());
	ST_scrollPane_2 = new JScrollPane(table3);
	horizontalBox.add(ST_scrollPane_2);

	final JLabel ST_button = new JLabel("SAVE");
	ST_button.setOpaque(true);
	ST_button.setHorizontalAlignment(SwingConstants.CENTER);
	ST_button.setBackground(new Color(0, 0, 0));
	ST_button.setForeground(new Color(255, 255, 255));
	ST_button.setFont(new Font("Trebuchet MS", Font.PLAIN, 11));
	ST_button.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseEntered(MouseEvent e)
		{ST_button.setBackground(new Color(255, 165, 0));}
		public void mouseExited(MouseEvent e)
		{ST_button.setBackground(Color.BLACK);}
		public void mousePressed(MouseEvent arg0)
		{ST_button.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
        public void mouseReleased(MouseEvent arg0)
        {ST_button.setBorder(new LineBorder(new Color(192, 192, 192)));}
		public void mouseClicked(MouseEvent arg0) {
			String item = (String) MN_comboBox.getSelectedItem();
			TableModel model = table3.getModel();
			for (int i = 0; i < model.getRowCount(); i++) {
				String mode = (String) model.getValueAt(i, 0);
				String flag = "NO";
				if ((boolean) model.getValueAt(i, 2)) {
					flag = "YES";
				}
				try {
					PreparedStatement st = connection.prepareStatement(
							"update TC_SCHEDULER set EXEC_FLAG='" + flag + "' where TCID='" + mode
									+ "' and MODULEID=(select MODULEID from MOD_SCHEDULER where MODULE_NAME='"
									+ item + "' and APPLICATION = '"+sAUT+"')");
					st.execute();
					st.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			getScheduleSummary(null);
			JOptionPane.showMessageDialog(null, "Schedule updated successfully");
		}
	});
	ST_button.setBounds(841, 523, 45, 23);
	contentPane.add(ST_button);
}
		private List<String> getComboData() {
		String query = "select MODULE_NAME from MOD_SCHEDULER where EXEC_FLAG = 'YES' and APPLICATION = '"+sAUT+"' ORDER BY MODULEID";
		List<String> list = new ArrayList<>();
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next()) {
				list.add(resultSet.getString("MODULE_NAME"));
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
			return list;
		}
		return list;
	}
	private void getScheduleSummary(String item) {
		Vector<Object> tb2col = new Vector<Object>();
		tb2col.addElement("Module Name");
		tb2col.addElement("Scheduled TCs");
		try {
			PreparedStatement statement1 = null;
			statement1 = connection.prepareStatement(
					"select m.MODULE_NAME,count(t.TCID) from TC_SCHEDULER t,MOD_SCHEDULER m where t.EXEC_FLAG='YES' and m.EXEC_FLAG='YES' and t.MODULEID=m.MODULEID and M.APPLICATION = '"+sAUT+"' group by m.MODULE_NAME");
			ResultSet rs1 = statement1.executeQuery();
			data1 = new Vector<Vector<Object>>();
			while (rs1.next()) {
				Vector<Object> newRow = new Vector<Object>();
				newRow.addElement(rs1.getString(1));
				newRow.addElement(rs1.getInt(2));
				data1.add(newRow);
			}
			rs1.close();
			statement1.close();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		tb2model5 = new DefaultTableModel(data1, tb2col);
		tb2model5.fireTableDataChanged();
		table4 = new JTable(tb2model5) {
		private static final long serialVersionUID = 1L;
		@SuppressWarnings({ "unchecked", "rawtypes" })
			@Override
			public Class getColumnClass(int column) {
				switch (column) {
				case 0:
					return String.class;
				default:
					return Integer.class;
				}
			}
		};

		table4.setPreferredScrollableViewportSize(table4.getPreferredSize());

		if (horizontalBox_2 != null) {
			contentPane.remove(horizontalBox_2);
		}
		horizontalBox_2 = Box.createHorizontalBox();
		horizontalBox_2.setBounds(81, 394, 373, 121);
		contentPane.add(horizontalBox_2);

		JScrollPane scrollPane_1 = new JScrollPane(table4);
		horizontalBox_2.add(scrollPane_1);

		JLabel lblCountOfTest = new JLabel("Count of Test cases per Module :");
		lblCountOfTest.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
		lblCountOfTest.setForeground(new Color(255, 140, 0));
		lblCountOfTest.setBounds(81, 357, 256, 30);
		contentPane.add(lblCountOfTest);

		JLabel lblScheduleSummary = new JLabel("SCHEDULE SUMMARY");
		lblScheduleSummary.setHorizontalAlignment(SwingConstants.CENTER);
		lblScheduleSummary.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 15));
		lblScheduleSummary.setBackground(new Color(105, 105, 105));
		lblScheduleSummary.setOpaque(true);
		lblScheduleSummary.setForeground(Color.WHITE);
		lblScheduleSummary.setBounds(81, 289, 373, 30);
		contentPane.add(lblScheduleSummary);

		final JLabel lblSelectAll = new JLabel("Select all");
		lblSelectAll.setForeground(Color.BLUE);
		lblSelectAll.setBounds(850, 150, 46, 14);
		lblSelectAll.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent arg0) {
			String item = (String) MN_comboBox.getSelectedItem();
			TableModel model = table3.getModel();
			String flag = "YES";
			try {
				if ((boolean) model.getValueAt(1, 2)) flag = "NO";
				for (int i = 0; i < model.getRowCount(); i++) {
						if (flag.equals("YES")) model.setValueAt(true, i, 2);
						else 					model.setValueAt(false, i, 2);
				}
			} catch (Exception e) {}
			getScheduleSummary(null);
			}
		public void mouseEntered(MouseEvent e)
		{lblSelectAll.setForeground(Color.RED);}
		public void mouseExited(MouseEvent e)
		{lblSelectAll.setForeground(Color.BLUE);}
		public void mousePressed(MouseEvent arg0)
		{lblSelectAll.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
		public void mouseReleased(MouseEvent arg0)
		{lblSelectAll.setBorder(null);}
		});
		contentPane.add(lblSelectAll
				);

		JLabel lblBack = new JLabel();
		lblBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				try {
					connection.close();
					dispose();
					UI_Frame_Dashboard objdshbrd = new UI_Frame_Dashboard();
					objdshbrd.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		lblBack.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "icon_back.png")));
		lblBack.setBounds(0, 0, 40, 30);
		lblBack.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblBack);

		JLabel lblSqlBank = new JLabel("SCHEDULE TEST CASES");
		lblSqlBank.setOpaque(true);
		lblSqlBank.setHorizontalAlignment(SwingConstants.CENTER);
		lblSqlBank.setForeground(Color.WHITE);
		lblSqlBank.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblSqlBank.setBackground(Color.BLACK);
		lblSqlBank.setBounds(0, 0, 954, 30);
		contentPane.add(lblSqlBank);

		JLabel label_1 = new JLabel("");
		label_1.setOpaque(true);
		label_1.setBackground(Color.BLACK);
		label_1.setBounds(0, 557, 954, 15);
		contentPane.add(label_1);

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "white1.jpg")));
		label.setBounds(0, 515, 954, 46);
		contentPane.add(label);

		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "dice2.png")));
		label_2.setBounds(885, 357, 69, 107);
		contentPane.add(label_2);

		final JLabel lblChange = new JLabel("Change");
		lblChange.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e){
				try {
					try {connection.close();} catch (SQLException e1) {e1.printStackTrace();}
					connection.close();
	        		dispose();
					UI_Frame_Update_TestSettings objUI =new  UI_Frame_Update_TestSettings();
					objUI.setVisible(true);
					objUI.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
				} catch (Exception e1) {
					e1.printStackTrace();
			}
			}			@Override
			public void mouseEntered(MouseEvent e)
			{lblChange.setForeground(Color.RED);}
			public void mouseExited(MouseEvent e)
			{lblChange.setForeground(Color.BLUE);}
			public void mousePressed(MouseEvent arg0)
			{lblChange.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
			public void mouseReleased(MouseEvent arg0)
			{lblChange.setBorder(null);}
});
		lblChange.setForeground(Color.BLUE);
		lblChange.setBounds(850, 41, 46, 14);
		contentPane.add(lblChange);

		JLabel lblApplication = new JLabel("APPLICATION: "+sAUT);
		lblApplication.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblApplication.setForeground(Color.GRAY);
		lblApplication.setBounds(717, 31, 129, 32);
		contentPane.add(lblApplication);

		JLabel label_BG = new JLabel("");
		label_BG.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "white1.jpg")));
		label_BG.setBounds(0, 28, 954, 72);
		contentPane.add(label_BG);


	}
}
