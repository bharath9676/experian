package com.optum.coliseum.frame;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JPasswordField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;

import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.DBUtils;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URL;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import java.awt.SystemColor;
import java.awt.Insets;
import javax.swing.border.CompoundBorder;

public class UI_Frame_Login extends JFrame {

	private static final long serialVersionUID = 1L;
	public JTextField txt_userNameB;
	private JPasswordField txt_passwordB;
	public String pWD;
	public JLabel lblUserNameAbsent;
	public JLabel lblPasswordAbsent;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				       final UI_Frame_Login frame = new UI_Frame_Login();
					   frame.setVisible(true);
					   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection connection = null;
	private JTextField txt_userName;
	private JTextField txt_password;
	public UI_Frame_Login() {
		initialize();
	}

	private void initialize() {

		try {
		    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
		    e.printStackTrace();
		}

		setTitle("COLISEUM");
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Dlogo.jpg")));

		getContentPane().setForeground(new Color(0, 153, 204));
		getContentPane().setBackground(Color.WHITE);
		setBounds(100, 100, 960, 600);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);

		txt_userNameB = new JTextField();
		txt_userNameB.setToolTipText("Enter Username here");
		txt_userNameB.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txt_userNameB.setText("");
			}
		});
		txt_userNameB.setOpaque(false);
		txt_userNameB.setForeground(Color.GRAY);
		txt_userNameB.setBorder(null);
		txt_userNameB.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		txt_userNameB.setBounds(371, 173, 191, 38);
		getContentPane().add(txt_userNameB);
		txt_userNameB.setColumns(10);


		txt_passwordB = new JPasswordField();
		txt_passwordB.setToolTipText("Enter Password here");
		txt_passwordB.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txt_password.setText("");
			}
		});
		txt_passwordB.setOpaque(false);
		txt_passwordB.setHorizontalAlignment(SwingConstants.LEFT);
		txt_passwordB.setMargin(new Insets(2, 7, 2, 2));
		txt_passwordB.setBorder(null);
		txt_passwordB.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ENTER){

					try {
						Submit();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
			    }

			}
		});
		txt_passwordB.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		txt_passwordB.setBounds(371, 241, 191, 38);
		getContentPane().add(txt_passwordB);

		final JLabel btn_Submit = new JLabel("SUBMIT");
		btn_Submit.setHorizontalAlignment(SwingConstants.CENTER);
		btn_Submit.setOpaque(true);
		btn_Submit.setBorder(null);
		btn_Submit.setBackground(Color.BLACK);
		btn_Submit.setForeground(new Color(255, 255, 255));
		btn_Submit.setFont(new Font("Calibri", Font.BOLD, 14));
		btn_Submit.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e)
			{btn_Submit.setBackground(new Color(255, 165, 0));}
			public void mouseExited(MouseEvent e)
			{btn_Submit.setBackground(Color.BLACK);}
			public void mousePressed(MouseEvent arg0)
			{btn_Submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));}
	        public void mouseReleased(MouseEvent arg0)
	        {btn_Submit.setBorder(new LineBorder(new Color(192, 192, 192)));}
			@SuppressWarnings("deprecation")
			public void mouseClicked(MouseEvent e) {
				if (txt_userNameB.getText().equals("")){
					lblUserNameAbsent.setText("Please enter username");
				}
				else if (txt_passwordB.getText().equals("")){
					lblUserNameAbsent.setText("");
					lblPasswordAbsent.setText("Please enter password");
				}
				else {
					try {
						Submit();
					} catch (Exception e1) {
						e1.printStackTrace();
					}

				}
			}
		});
		btn_Submit.setBounds(360, 305, 244, 36);
		getContentPane().add(btn_Submit);

		JLabel lbl_Coliseum = new JLabel("COLISEUM");
		lbl_Coliseum.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
		lbl_Coliseum.setForeground(Color.WHITE);
		lbl_Coliseum.setBackground(new Color(255, 255, 255));
		lbl_Coliseum.setBounds(1082, 558, 103, 14);
		getContentPane().add(lbl_Coliseum);

		final JLabel lbl_ForgotPassword = new JLabel("Forgot Password?");
		lbl_ForgotPassword.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		lbl_ForgotPassword.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e)
			{lbl_ForgotPassword.setForeground(Color.BLUE);}
			public void mouseExited(MouseEvent e)
			{lbl_ForgotPassword.setForeground(new Color(255, 140, 0));}
			public void mouseClicked(MouseEvent e) {

				try {
					UI_Dialog_ForgotPassword fPassword = new UI_Dialog_ForgotPassword();
					fPassword.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		lbl_ForgotPassword.setForeground(new Color(255, 140, 0));
		lbl_ForgotPassword.setBounds(360, 404, 120, 26);
		getContentPane().add(lbl_ForgotPassword);

		final JLabel lbl_NewUser = new JLabel("New User?");
		lbl_NewUser.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		lbl_NewUser.setForeground(new Color(255, 140, 0));
		lbl_NewUser.setBounds(360, 370, 75, 25);
		lbl_NewUser.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e)
			{lbl_NewUser.setForeground(Color.BLUE);}
			public void mouseExited(MouseEvent e)
			{lbl_NewUser.setForeground(new Color(255, 140, 0));}
			public void mouseClicked(MouseEvent e) {
				//int action = JOptionPane.showConfirmDialog(null, "By clicking on YES, you will be sending a request to the administrators for adding you as a user. Are you sure you want to proceed?", "CONFIRMATION",JOptionPane.YES_NO_OPTION );
				//if(action ==0){
				UI_Dialog_NewUser newUser = new UI_Dialog_NewUser();
				newUser.setVisible(true);
			}});
		getContentPane().add(lbl_NewUser);

		lblPasswordAbsent = new JLabel("");
		lblPasswordAbsent.setForeground(new Color(255, 69, 0));
		lblPasswordAbsent.setFont(new Font("Tahoma", Font.ITALIC, 11));
		lblPasswordAbsent.setBounds(360, 281, 233, 26);
		getContentPane().add(lblPasswordAbsent);

		lblUserNameAbsent = new JLabel("");
		lblUserNameAbsent.setFont(new Font("Tahoma", Font.ITALIC, 11));
		lblUserNameAbsent.setForeground(new Color(255, 69, 0));
		lblUserNameAbsent.setBounds(360, 214, 234, 25);
		getContentPane().add(lblUserNameAbsent);

		JLabel lblWelcomeToColiseum = new JLabel("Welcome to Coliseum");
		lblWelcomeToColiseum.setForeground(Color.DARK_GRAY);
		lblWelcomeToColiseum.setHorizontalAlignment(SwingConstants.CENTER);
		lblWelcomeToColiseum.setFont(new Font("Segoe UI", Font.PLAIN, 33));
		lblWelcomeToColiseum.setBounds(313, 25, 331, 42);
		getContentPane().add(lblWelcomeToColiseum);

		JLabel lblPleaseLoginTo = new JLabel("Please login to continue");
		lblPleaseLoginTo.setForeground(Color.GRAY);
		lblPleaseLoginTo.setHorizontalAlignment(SwingConstants.CENTER);
		lblPleaseLoginTo.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblPleaseLoginTo.setBounds(313, 95, 331, 26);
		getContentPane().add(lblPleaseLoginTo);

		JLabel label_2 = new JLabel("");
		label_2.setOpaque(true);
		label_2.setBackground(Color.BLACK);
		label_2.setBounds(0, 559, 954, 11);
		getContentPane().add(label_2);

		txt_password = new JTextField();
		txt_password.setEditable(false);
		txt_password.setMargin(new Insets(2, 8, 2, 2));
		txt_password.setForeground(Color.GRAY);
		txt_password.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		txt_password.setBorder(new CompoundBorder(new CompoundBorder(new LineBorder(new Color(192, 192, 192)), null), null));
		txt_password.setBackground(Color.WHITE);
		txt_password.setBounds(360, 239, 202, 42);
		getContentPane().add(txt_password);

		txt_userName = new JTextField();
		txt_userName.setEnabled(false);
		txt_userName.setBackground(Color.WHITE);
		txt_userName.setForeground(Color.GRAY);
		txt_userName.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		txt_userName.setBorder(new CompoundBorder(new CompoundBorder(new LineBorder(new Color(192, 192, 192)), null), null));
		txt_userName.setBounds(360, 171, 202, 42);
		getContentPane().add(txt_userName);

		JLabel label_3 = new JLabel("");
		label_3.setBorder(new LineBorder(Color.LIGHT_GRAY));
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setOpaque(true);
		label_3.setBackground(Color.WHITE);
		label_3.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_Password.png")));
		/*try
		label_3.setIcon(new ImageIcon(ImageIO.read(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_Password.png"))));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		label_3.setBounds(567, 239, 37, 42);
		getContentPane().add(label_3);

		JLabel label_4 = new JLabel("");
		label_4.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "Icon_user.png")));
		label_4.setOpaque(true);
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setBorder(new LineBorder(Color.LIGHT_GRAY));
		label_4.setBackground(Color.WHITE);
		label_4.setBounds(567, 171, 37, 42);
		getContentPane().add(label_4);

		JLabel label = new JLabel("");
		label.setBorder(null);
		label.setOpaque(true);
		label.setBackground(SystemColor.menu);
		//label.setBorder(new LineBorder(Color.GRAY));
		label.setIcon(null);
		label.setBounds(334, 132, 295, 333);
		getContentPane().add(label);

		JLabel label_6 = new JLabel("");
		label_6.setIcon(new ImageIcon(ClassLoader.getSystemResource(Constants.CLASSPATH_MEDIA_FOLDER + "coliseum2.png")));
		label_6.setBounds(740, 370, 214, 152);
		getContentPane().add(label_6);

		JLabel lblNewLabel = new JLabel("Functional Testing and Test data preperation Automation Tool");
		lblNewLabel.setBounds(334, 540, 311, 14);
		getContentPane().add(lblNewLabel);

		JLabel lblSvngitVersion = new JLabel("SVN/GIT Version");
		lblSvngitVersion.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblSvngitVersion.setBounds(94, 540, 110, 14);
		getContentPane().add(lblSvngitVersion);

		JLabel lblVersion = new JLabel("Edition 1.0.1");
		lblVersion.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblVersion.setBounds(22, 540, 96, 14);
		getContentPane().add(lblVersion);

		JLabel lblPoweredByJava = new JLabel("Powered by JAVA");
		lblPoweredByJava.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPoweredByJava.setBounds(834, 540, 120, 14);
		getContentPane().add(lblPoweredByJava);


	}

	@SuppressWarnings("deprecation")
	public void Submit()throws Exception
	{
		lblUserNameAbsent.setText("");
		lblPasswordAbsent.setText("");
		connection = DBUtils.DBConnect_Automation();
		String sName = null;
		try{
			ResultSet rs = connection.createStatement().executeQuery("Select * from USERS where USER_NAME ='"+ txt_userNameB.getText()+"'");
			if(rs.next()){
				sName = rs.getString(1);
			}
			if (sName == null) {
				lblUserNameAbsent.setText("Incorrect user name");
				txt_passwordB.setText("");
			}
			else {
				ResultSet rs1 = connection.createStatement().executeQuery("Select * from USERS where USER_NAME ='"+ txt_userNameB.getText()+"' and AUTHORIZED = 'Y'");
				int count =0;
				while(rs1.next()){
					count = count +1;
				}
				if(count > 0){
					ResultSet rs2 = connection.createStatement().executeQuery("Select * from USERS where USER_NAME ='"+ txt_userNameB.getText()+"' and PASSWORD ='"+txt_passwordB.getText()+"'");
					count =0;
					while(rs2.next()){
						count = count +1;
					}
					if(count > 0){
						updateactuser();
						dispose();
						UI_Frame_Dashboard homePage = new UI_Frame_Dashboard();
						homePage.setVisible(true);
						System.out.println("Dashboard initiated for :" + txt_userNameB.getText());
					}
					else {
						lblPasswordAbsent.setText("Password is incorrect!");
					}
				}
				else {
					lblUserNameAbsent.setText("User is not authorized!");
				}
			}
		}
		catch(Exception ep){
			System.out.println(ep);
			Msgbox.msgbox("Environmental error occured while accessing Login details!");
		}
		connection.close();
	}//Method


	public void updateactuser()
	{
		try {
			connection = DBUtils.DBConnect_Automation();
			String str = txt_userNameB.getText();
			String query0 = "update SETTINGS set VALUE = ? where SKEY = 'ACT_USER'";
			PreparedStatement statement = connection.prepareStatement(query0);
			statement.setString(1, str);
			statement.execute();
			connection.close();

		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}
}
