package com.optum.coliseum.driver;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;

import com.optum.coliseum.generic.DBUtils;
import com.optum.coliseum.generic.Settings;

public class DataHandler {
	
	public static String sAUT;
	public static String value;
	public static PrintWriter out;		
	public static String sLogFolder;
	public static String sTimeStamp = "";
	public static boolean isFailure;
	public static String sReportFolder = null;
	
       public static void main(String[] args)throws Exception {
              Connection Tcon      = DBUtils.DBConnect_Automation();
              Connection con_App   = DBUtils.DBConnect_Application();
              DataManager_Batch (Tcon,  con_App); 
              Tcon.close();
              con_App.close();
       }
         
       public static void DataManager_Batch(Connection Tcon, Connection con_App)
       {
		   sTimeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date()).replaceAll(".", "");
		   getDataConfRepFolder(Tcon);
		   
		   sAUT =  Settings.getSetting("AUT1", Tcon);
		   
		   if(Settings.getSetting("DM_APPEND", Tcon).equalsIgnoreCase("N")) ProcessDMAppend(Tcon, sAUT, sLogFolder);
    	   
		   int iDMRecNum = Integer.parseInt(Settings.getSetting("DM_REC_NUM", Tcon)); 
		   try {
			   ResultSet rs9=Tcon.createStatement().executeQuery("Select SQLID, eSQL from [SQLS] where sqlid like 'DM%' and Application = '"+sAUT+"'");
			   while (rs9.next()){
			         com.optum.coliseum.driver.DataHandler.RefreshDMRecord(Tcon, con_App, rs9.getString("SQLID"), rs9.getString("eSQL"), iDMRecNum, sLogFolder);
			   }
		   } catch (SQLException e) {Log("################## Error! while accessing DM table"); e.printStackTrace();}
              
           String sTS = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
           try {Tcon.createStatement().executeUpdate("Update Settings set Value = '"+sTS+"' where SKEY = 'DM_REFRESH_TS'");} 
           catch (SQLException e) {Log("&&&&&&&& Warning! Cant update DM_REFRESH_TS"); e.printStackTrace();}
           
           Log("************************************");
           Log("Data Manager refreshed!");
       }
       
       public static void RefreshDMRecord(Connection Tcon, Connection con_App, String sDMID, String sESQL, int DM_REC_NUM, String sReportFolder){
    	   sLogFolder = sReportFolder; 
    	   Log("*********************************************************");
	   	  	Log("DMID: " + sDMID);
	   	  	Log("*********************************************************");   
	   	  	int dmRecCount = 0;
	   	             try {
                           ResultSet rs_APP=con_App.createStatement().executeQuery(sESQL);
                           while(rs_APP.next()){
                        	        if(dmRecCount<DM_REC_NUM)
                                    {
                                     Log(rs_APP.getString(1));
                                     String sQuery = "INSERT INTO [DM] (DMID, TPK, USED_IND) VALUES ('"+ sDMID +"', '"+rs_APP.getString(1)+"', 'N')";
                                     Tcon.createStatement().executeUpdate(sQuery);
                                     dmRecCount=dmRecCount+1;
                                    }
                                    else break;
                           }
                     } catch (SQLException e) {e.printStackTrace();}
       }
       
       public static boolean FetchTPKfromDM(Connection TCon, String Mid, String Tid, String sReportFolder)  
       {
    	   isFailure = true;
    	   sLogFolder = sReportFolder;    
    	   String sQuery = "select * from DM_MAP where Moduleid = '"+ Mid + "' and TCID = '"+ Tid +"'";
              
           try {
        	   ResultSet rs_MAP=TCon.createStatement().executeQuery(sQuery); 
               while(rs_MAP.next())
                     {
                           if (!(rs_MAP.getString("DMID").equals("NA"))){
                                  Statement st1=TCon.createStatement();
                                  ResultSet rs1=st1.executeQuery("select TPK from DM where DMID = '"+rs_MAP.getString("DMID")+"' and USED_IND = 'N'");
                                  while (rs1.next()) {
                                         String sTPK = rs1.getString("TPK"); 
                                         st1.executeUpdate("Update DM_MAP Set ACTIVE_TPK= '" +sTPK + "'where DM_MAP_ID = '"+rs_MAP.getString("DM_MAP_ID")+"'");
                                         st1.executeUpdate("Update DM Set USED_IND= 'Y' where TPK='" + sTPK + "'");
                                         Log(rs_MAP.getString("Moduleid") + rs_MAP.getString("TCID") + " | TPK : "+sTPK+" found and populated");
                                         if (sTPK!=null) isFailure = false;
                                         else Log("@@@@@@@@ WARNING! No TPK found in Store!");
                                  }
                           }
                           else {
                        	   isFailure = false;
                        	   Log("@@@@@@@@ WARNING! TPK is defined as NA for this Test case. Hence proceeding regardless...");
                           }
                     }
              } catch (SQLException e) {Log(e.getMessage());}
              
           return isFailure; 
       }
    
       public static String ProcessDataRef(Connection Tcon, Connection con_APP, String sDataRef, String sAut, String Mid, String Tid, int Sid, String TmplID, List <String> TmplParamsList, String sReportFolder) {
    	   
    	   	sLogFolder = sReportFolder; String sRet = null; String sRetFinal = null;
    	   	
    	   	
			String a[] 	= sDataRef.split("\\|\\|");   //#REPLACE(Q,#RN(3),SQL)||#SQL(SQM001)
			
			for (String A : a){
				System.out.println("Split with pipe : "+ A);
				
				A = processParameters(Tcon, A, sAut, Mid, Tid, TmplID, TmplParamsList, false);
	        	if (A.startsWith("#")){
				      	  	String B[] = A.split("\\("); 
				      	  	String sKeyword = B[0]; 
				      	  	String sParam[] = A.substring(sKeyword.length()+1, A.length()-1).split("\\,"); sKeyword = sKeyword.trim();
				      	  	
				      	  	for (int i = 0; i<sParam.length; i++){
				      	  		
				      	  		sParam[i]=sParam[i].trim();
				      	  		
				      	  		if (sParam[i].startsWith("#")) sParam[i]= ProcessDataRef(Tcon, con_APP, sParam[i], sAut, Mid, Tid, Sid, TmplID, TmplParamsList, sLogFolder); 
				      	  		System.out.println("Parameter " + i + " : " + sParam[i]);
				      	  		
				      	  		sRet = null;
				      	  		switch (sKeyword){
									case "#RM": sRet = RandomStringUtils.randomAlphanumeric	(Integer.parseInt(sParam[0])).toUpperCase();       		break;
									case "#RS": sRet = RandomStringUtils.randomAlphabetic	(Integer.parseInt(sParam[0])).toUpperCase();        	break;
									case "#RN": sRet = RandomStringUtils.randomNumeric		(Integer.parseInt(sParam[0])).toUpperCase();     		break;
									case "#RP": sRet = RandomStringUtils.randomNumeric		(Integer.parseInt(sParam[0])).toUpperCase()+".0000";	break;
									case "#RE": sRet = RandomStringUtils.randomAlphabetic	(7).toUpperCase()+"@Coliseum.com";						break;
									case "#REPLACE"	: sRet= sParam[2].replace(sParam[0], sParam[1]);												break;
									case "#CONCAT"	: for (int c = 0; c<sParam.length; c++) 
									{
										sRet = sParam[c];
									} 								break;
									
									case "#SPLIT"	: String T[] = sParam[0].split(sParam[1]); sRet = T[Integer.parseInt(sParam[2])] ;				break;
									
									case "#SUBSTR"	: sRet = sParam[0].substring(Integer.parseInt(sParam[1]), Integer.parseInt(sParam[2]));			break;
									case "#SQL":
									    String sQuery = "0";
									    try { ResultSet rs15=Tcon.createStatement().executeQuery("select ESQL from SQLS where SQLID='"+sParam[0]+"'");
									          if(rs15.next()) { 
									        	  sQuery = rs15.getString("ESQL");
									        	  System.out.println(sQuery);
									        	  sQuery = processParameters(Tcon, sQuery, sAut, Mid, Tid, TmplID, TmplParamsList, true);
									          }

									          if (!(sQuery.equals("0"))){
									        	  System.out.println(sQuery);	
									        	  ResultSet rs_APP=con_APP.createStatement().executeQuery(sQuery);//APP Database
									           		if (rs_APP.next()) 	sRet = rs_APP.getString(1);
									           		else {  			sRet = "NO DATA"; //Log("Warning!! ################## Test data not found!");
									           		}
									          } 
									          else Log("FAILURE!! ################## SQLID : '"+sParam[0]+"' does not look correct.");
									    } 
									    catch (SQLException e) {}
									break;
									case "#GETLOGINURL":
											sQuery = "select LOGIN_URL from ENV where APPLICATION='"+sParam[0]+"' and TEST_ENVIRONMENT='"+Settings.getSetting("ENVIRONMENT", Tcon)+"'";
									       System.out.println(sQuery);
											try {ResultSet rs15=Tcon.createStatement().executeQuery(sQuery);
										       	if(rs15.next()) sRet = rs15.getString(1);
										       	else { sRet = "^__^"; Log("Warning!! ################## Cant fetch the URL!");
										       	}
									       } catch (SQLException e) {}
									break;
									case "#PARSEXML":
										String x[] = sRetFinal.split("<"+sParam[0]+">");
										String y[] = x[1].split("</"+sParam[0]+">");
										sRet = y[0];value = y[0];
									break;
									
								}
				      	  	}
	        	}
	        	else sRet = A;
	        		        	
	        	if (sRetFinal==null) 	sRetFinal = sRet;
				else					sRetFinal = sRetFinal + "||"+sRet;
			
	        //	if(!(sRetFinal.equalsIgnoreCase("NULL"))){if (sRetFinal.contains("'")) sRetFinal = sRetFinal.replaceAll("'", "''");}
	        	if (sRetFinal!=null) if (sRetFinal.contains("'"))sRetFinal=sRetFinal.replaceAll("\'","");
			}
			
		//	if (sRetFinal==null) sRetFinal = "^__^";
	        if (sDataRef.startsWith("#CONCAT")){sRetFinal=sRetFinal.replace("||", "");}
			System.out.println("sRetFinal : "+sRetFinal);
			try {
				if(TmplID != null){
				   Tcon.createStatement().executeUpdate("Update TEMPLATES Set TEST_DATA ='"+sRetFinal+"' where TMPLID = '" +TmplID + "' and Stepid = '"+Sid+"'");
				    Log("Testdata Value: '" + sRetFinal+"' updated for Template: "+TmplID + " | " + Sid);
				}
				else {
				   Tcon.createStatement().executeUpdate("Update DRIVER Set TEST_DATA ='"+sRetFinal+"' where TCID = '" +Tid + "' and Moduleid = '" +Mid + "' and Stepid = '"+Sid+"'");
				    Log("Testdata Value: '" + sRetFinal+ "' updated for Driver: "+Mid+ " | "+ Tid + " | " + Sid);
				}
    	   } catch (SQLException e) {Log(e.toString()); e.printStackTrace();}
            
           return sRetFinal;
       }
       
	   public static void ProcessDMAppend(Connection Tcon, String AUT, String sReportFolder){
    	   sLogFolder = sReportFolder;    
    	   try {
            	    ResultSet rs1=Tcon.createStatement().executeQuery("select count(1) from DM where DMID in (Select SQLID from SQLS where APPLICATION = '"+AUT+"')");
                    if (rs1.next()) if(Integer.parseInt(rs1.getString(1))>0 ) {
                    		Tcon.createStatement().executeUpdate("Delete from DM where DMID IN (Select SQLID from SQLS where APPLICATION = '"+AUT+"')");
                    		Log("DM truncated successfully!");
                    }
              } catch (Exception e) {Log("@@@@@@@@@@@@@@@@@@@@ WARNING! DM Append could not be processed"); e.printStackTrace();}
       }

       public static void Log(String text){
   	    try { 
   	    	out = new PrintWriter(new BufferedWriter(new FileWriter(sLogFolder+"\\log"+sTimeStamp+".txt", true)));
   	    	out.println(text);
   	    	out.close();
   	    } 
   	    catch (IOException e) {e.printStackTrace();}
       }
       //BHarath -->Changed Reports_Root to Log_Root as we are writing into only logs. Chnaged sRepFolder to sLogFolder
       public static void getDataConfRepFolder(Connection Tcon){
    	   sLogFolder = Settings.getSetting("LOG_ROOT", Tcon) + "\\DataConf";
    	   File Folder = new File(sLogFolder);
    	   if (!Folder.exists()) Folder.mkdir();
       }

       public static String getTPK(Connection Tcon, String Mid, String Tid){
    	   String sRet = null;
	    	try {
				ResultSet rs17=Tcon.createStatement().executeQuery("SELECT ACTIVE_TPK FROM DM_MAP WHERE TCID = '" +Tid + "' and Moduleid = '" +Mid+"'");
				if (rs17.next()) sRet = rs17.getString("ACTIVE_TPK");
			} catch (SQLException e) {e.printStackTrace();}
	   		return sRet;
       }
       
       public static String getRTVal(Connection Tcon, String sAut, String Mid, String Tid, String TmplId, String RTValNum){
    	   String sRet = null;
	    	try {
	    		String sQuery = "SELECT TEST_DATA FROM DRIVER WHERE APPLICATION = '" +sAut + "' and TCID = '" +Tid + "' and Moduleid = '" +Mid+"' and RTVAL_REF = '"+RTValNum+"'";
				if (TmplId!=null) sQuery = "SELECT TEST_DATA FROM TEMPLATES WHERE tmplid = '" +TmplId+"' and RTVAL_REF = '"+RTValNum+"'";
	    		System.out.println("RTVAL Fetch Query: "+sQuery);
	    		ResultSet rs17=Tcon.createStatement().executeQuery(sQuery);
				if (rs17.next()) sRet = rs17.getString("TEST_DATA");
			} catch (SQLException e) {e.printStackTrace();}
	   		return sRet;
       }
       
       public static String processParameters(Connection Tcon, String A, String sAut, String Mid, String Tid, String TmplId, List <String> TmplParamsList, boolean isQuery){
   		
     		if (A.contains("TPK")) {
     			if (isQuery) A = A.replace("TPK", "'"+getTPK(Tcon, Mid, Tid).trim()+"'").trim();
     			else 		 A = A.replace("TPK", 	  getTPK(Tcon, Mid, Tid)).trim();
     		}
      		
     		if (TmplParamsList!=null){
              for (int i1=0; i1<TmplParamsList.size(); i1++){
                  	if (A.contains("TPAR"+(i1+1))) {
                  		if (isQuery) A=A.replace("TPAR"+(i1+1), "'"+TmplParamsList.get(i1)).trim()+"'";
                  		else 		 A=A.replace("TPAR"+(i1+1), 	TmplParamsList.get(i1)).trim();
                  	}
              }
      		}
     		
      		for (int i2=1; i2<11; i2++){
              	if (A.contains("RTVAL"+i2)) {
              		if (isQuery) A=A.replace("RTVAL"+i2, "'"+getRTVal(Tcon, sAut, Mid, Tid, TmplId, "RTVAL"+i2).trim()+"'");
              		else 		 A=A.replace("RTVAL"+i2, 	 getRTVal(Tcon, sAut, Mid, Tid, TmplId, "RTVAL"+i2).trim());
              	}
      		}

      		return A;
      }
}

