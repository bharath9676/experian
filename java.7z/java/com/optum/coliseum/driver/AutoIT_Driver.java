package com.optum.coliseum.driver;

import java.io.IOException;
import java.io.InputStream;

import org.openqa.selenium.WebDriver;

import com.optum.coliseum.generic.Constants;

import pack1.WebDriverWait;
import pack1.Webdriver;

public class AutoIT_Driver {
	public static void main(String []args) throws Exception{
		try {
			
			Process proc=Runtime.getRuntime().exec(Constants.PATH_AUTOIT_WINDOWSFRAMEWORK);
   			InputStream is = proc.getInputStream();
   			int retCode = 0;
   			while (retCode != -1){
   				retCode = is.read();
   			}
   		} catch (IOException e) {
   			e.printStackTrace();
   		}
	}}

