package com.optum.coliseum.driver;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.optum.coliseum.generic.DBUtils;
public class OWOR
{
	public Connection Tcon;
	public String OBJID;
	public String OWID;
	public int flag1=0;
    public int flag2=0;
    public int flag3=0;
    public int flag4=0;	
    public int Tflag = 0;
    public int TempFlag = 0;
    
    public static void main(String []args) throws Exception{
    	OWOR base = new OWOR();
		base.actionPerform();
	}
    
	public void actionPerform()throws SQLException
	{
	    Tcon = DBUtils.DBConnect_Automation();
	    Statement st_OR=Tcon.createStatement();
	    ResultSet rs_OR = st_OR.executeQuery("Select * from OBJ_REP");
		while (rs_OR.next())
		{
			System.out.println("Processing for OBJ_REF : "+rs_OR.getString("OBJ_REF") + "###############################"); 
			Tflag = 0;
			Statement st_OW=Tcon.createStatement();
			ResultSet rs_OW = st_OW.executeQuery("Select * from OBJ_WH");
			while (rs_OW.next())
			{	
				System.out.println("Processing for OWHID : "+rs_OW.getString("OWHID"));
				TempFlag = 0;flag1=0;flag2=0;flag3=0;flag4=0;

/*			    #####################################################################
				        Analyze T-FLAG for each OW record
			    #####################################################################
*/				
				if (compare(rs_OW.getString("NAME"), rs_OR.getString("NAME"))) 			{flag1 = 13;}
				if (compare(rs_OW.getString("ID"), rs_OR.getString("ID"))) 				{flag2 = 11;}
				if (compare(rs_OW.getString("LINKTEXT"), rs_OR.getString("LINKTEXT"))) 	{flag3 = 7;}
				if (compare(rs_OW.getString("TITLE"), rs_OR.getString("TITLE"))) 		{flag4 = 1;}
				
				TempFlag = flag1+flag2+flag3+flag4;
				System.out.println("Tempflag : " + TempFlag);
				if (Tflag<TempFlag){Tflag = TempFlag; OWID = rs_OW.getString("OWHID");};
				//System.out.println("processed for:"+OWID);
				
			}   
			
/*			#####################################################################	
				   Update the OR accordingly
			#####################################################################
*/
			if (!(Tflag==0)){ 
		
			Statement st_OW2=Tcon.createStatement();
			ResultSet rs_OW2 = st_OW2.executeQuery("Select * from OBJ_WH where OWHID = '" + OWID + "'");
			Statement st00=Tcon.createStatement();
				switch (Tflag) {
				case 31: st00.executeUpdate("Update OBJ_REP Set TITLE = '"+rs_OW2.getString("TITLE")+"' where OBJ_REF = '"+rs_OR.getString("OBJ_REF")+"'");
				case 25: st00.executeUpdate("Update OBJ_REP Set LINKTEXT = '"+rs_OW2.getString("LINKTEXT")+"' where OBJ_REF = '"+rs_OR.getString("OBJ_REF")+"'");
				case 21: st00.executeUpdate("Update OBJ_REP Set ID = '"+rs_OW2.getString("ID")+"' where OBJ_REF = '"+rs_OR.getString("OBJ_REF")+"'");
				case 19: st00.executeUpdate("Update OBJ_REP Set NAME = '"+rs_OW2.getString("NAME")+"' where OBJ_REF = '"+rs_OR.getString("OBJ_REF")+"'");
				}
			}
		}
		Tcon.close();
	}

	public static boolean compare(String str1, String str2) {
	    if (!(str1 == null)){
	    if (!(str2 == null)){
	    if (!(str1 == "")){
	    if (!(str2 == "")){
	    	return (str1.equals(str2));
	    }}}}
		return false;
	}

}
  