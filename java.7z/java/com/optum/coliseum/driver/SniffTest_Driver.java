package com.optum.coliseum.driver;

public class SniffTest_Driver {
	
	public static void main(String []args) throws Exception
	{
		DriverLib driver = new DriverLib();
		driver.Drive_REGR(4, null, null);
	}
}