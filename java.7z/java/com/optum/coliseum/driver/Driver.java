package com.optum.coliseum.driver;


public class Driver
{
	public static void main(String []args) throws InterruptedException {
		DriverLib driver = new DriverLib();
		driver.Drive_REGR(1, null, null);
	}
}	
