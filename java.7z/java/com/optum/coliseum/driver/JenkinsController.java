package com.optum.coliseum.driver;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import com.optum.coliseum.generic.DBUtils;


//Author Adam Varco
public class JenkinsController {

	private static Connection connection = DBUtils.DBConnect_Automation();
	private static DriverLib driverLib = new DriverLib();
	private static String filePath = new String();
	private static ArrayList<String> logArrList = new ArrayList<String>();

	public static void main(String[] args) {
		validateArray(args);
		try {
			connection.setAutoCommit(false);
			validateSettings(args);
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				System.out.println("Rolling back data here....");
				logArrList.add("***** Rolling back data here *****");
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}

		} finally {
			try {
				connection.setAutoCommit(true);
				connection.close();
				System.out.println("Connection closed in JenkinsController");
				logArrList.add("***** Connection closed in JenkinsController *****");
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				System.out.println("exit");
				jenkinsLog();
				System.exit(0);
			}
		}

	}

	public static void validateArray(String[] args) {

		if (args.length < 5) {
			throw new ArrayIndexOutOfBoundsException("\n Not enough Elements in the Array!\n "
					+ "The Program Needs 5 elements, this array has " + args.length + " elements"
					+ "\n The program needs an Application Type, Test Environment, Browser Type, and Execution Type");

		} else if (args.length > 5) {
			throw new ArrayIndexOutOfBoundsException("\n Too many Elements in the Array!\n"
					+ "The Program Needs 5 elements, this array has " + args.length + " elements"
					+ "\n program needs an Application Type, Test Environment, Browser Type, and Execution Type");

		} else {
			filePath = args[4];
			logArrList.add("***** START OF JENKIN'S TEST! *****");
		}

	}

	public static void validateSettings(String[] args) throws SQLException {
		String applicationType = args[0].toUpperCase();
		String testEnvironment = args[1].toUpperCase();
		String browserType = args[2].toUpperCase();
		String executionType = args[3];

		switch (applicationType) {
		case "SQ":
		case "MP":
		case "C4":
		case "AC":
		case "MG":
		case "J2":
		case "J3":
			if (testEnvironment.equals("QA02") || testEnvironment.equals("QA01")) {
				validateBrowserType(applicationType, testEnvironment, browserType, executionType);
				break;
			} else {
				logArrList.add("***** Wrong Test Enviornmnet :" + testEnvironment + "For application " + applicationType + " *****");
				jenkinsLog();
				System.exit(0);
				break;
			}
		case "VP":
		case "WTC":
			if (testEnvironment.equals("QA")) {
				validateBrowserType(applicationType, testEnvironment, browserType, executionType);
				break;
			} else {
				logArrList.add("***** Wrong Test Enviornmnet :" + testEnvironment + "For application " + applicationType + " *****");
				jenkinsLog();
				System.exit(0);
				break;
			}
		default:
			System.err.println("Wrong Application Type Selected \n"
					+ "Needs to be SQ or MP or C4 or MG or AC or J2 or J3 or VP or WTC");
			logArrList.add("***** Wrong Application Type " + applicationType + " *****");
			logArrList.add("***** Needs to be SQ or MP or C4 or MG or AC or J2 or J3 or VP or WTC *****");
			jenkinsLog();
			System.exit(0);
		}
	}

	public static void validateBrowserType(String applicationType, String testEnvironment, String browserType,
			String executionType) throws SQLException {
		switch (browserType) {
		case "FIREFOX":
		case "CHROME":
		case "IE":
		case "PHANTOM":
			populateSettings(applicationType, testEnvironment, browserType, executionType);
			break;
		default:
			System.err.println("Wrong Browser Type entered \n" + "Needs to be FIREFOX, CHROME, IE, or PHANTOM");
			logArrList.add("***** Wrong Browser Type entered. Needs to be FIREFOX, CHROME, IE, or PHANTOM *****");
			jenkinsLog();
			System.exit(0);
		}
	}

	public static void populateSettings(String applicationType, String testEnvironment, String browserType,
			String executionType) throws SQLException {
		connection.createStatement()
				.executeUpdate("update SETTINGS set VALUE='" + testEnvironment + "' where SKEY='ENVIRONMENT'");

		connection.createStatement()
				.executeUpdate("update SETTINGS set VALUE='" + applicationType + "' where SKEY='AUT'");

		connection.createStatement()
				.executeUpdate("update SETTINGS set VALUE='" + browserType + "' where SKEY='BROWSER'");

		logArrList.add("***** Commiting data for settings table *****");
		connection.commit();

		decideWhatTestsToRun(applicationType, executionType);
	}

	public static void decideWhatTestsToRun(String applicationType, String executionType) throws SQLException {
		if (executionType.equalsIgnoreCase("runObjectCollectionTests"))
			runObjectCollectionTests();
		else if (executionType.equalsIgnoreCase("runBuildVerficationTests"))
			runBuildVerficationTests();
		else if (executionType.equalsIgnoreCase("runSanityTests"))
			runSanityTests();
		else if (executionType.equalsIgnoreCase("runRegressionTests"))
			runRegressionTests(applicationType);
		else if (executionType.equalsIgnoreCase("runASisVersionTests"))
			runASisVersionTests();
		else {
			System.err.println("Wrong Execution type entered \n"
					+ "Need to enter objectcollectiontests, buildverficationtests \n"
					+ ", sanitytests, regressiontests, or asisversiontests \n" + "you entered : " + executionType);
			logArrList.add("***** Wrong Execution type entered *****");
			logArrList.add("***** Need to enter objectcollectiontests, buildverficationtests, sanitytests, regressiontests, or asisversiontests *****");
			logArrList.add("***** you entered " +executionType + " *****");
			jenkinsLog();
			System.exit(0);
		}

	}

	public static void runObjectCollectionTests() throws SQLException {
		connection.createStatement().executeUpdate("update SETTINGS set VALUE='Y' where SKEY='SMK_COLOBJS'");
		logArrList.add("***** Committing data for Object Collection *****");
		connection.commit();
		logArrList.add("***** Running Object Collection *****");
		driverLib.Drive_REGR(2, null, null);
		// I have this turned off right now until we figure out if it is needed.
		// OWOR ow = new OWOR();
		// ow.actionPerform();

	}

	public static void runBuildVerficationTests() throws SQLException {
		connection.createStatement().executeUpdate("update SETTINGS set VALUE='N' where SKEY='SMK_COLOBJS'");
		logArrList.add("***** Committing data for Smoke Tests *****");
		connection.commit();
		logArrList.add("***** Run Smoke Tests *****");
		driverLib.Drive_REGR(2, null, null);
	}

	public static void runSanityTests() {
		System.out.println("Run Sanity Tests");
		logArrList.add("***** Run Sanity Tests *****");
		driverLib.Drive_REGR(4, null, null);
	}

	public static void runRegressionTests(String applicationType) throws SQLException {
		connection.createStatement().executeUpdate("update TC_SCHEDULER set EXEC_FLAG ='YES'" + " where application = '"
				+ applicationType + "' and MODULEID <>'SNIFF' " + "and MODULEID <> 'SMOKE' and MODULEID <> 'AUTOIT'");

		connection.createStatement()
				.executeUpdate("update MOD_SCHEDULER set EXEC_FLAG ='YES'" + " where application = '" + applicationType
						+ "' and MODULEID <>'SNIFF' " + "and MODULEID <> 'SMOKE' and MODULEID <> 'AUTOIT'");

		logArrList.add("***** Committing data for Regression *****");
		connection.commit();
		logArrList.add("***** Running Regression Tests *****");
		driverLib.Drive_REGR(1, null, null);

	}

	public static void runASisVersionTests() {
		logArrList.add("***** Run as is Version Tests *****");
		driverLib.Drive_REGR(1, null, null);
	}

	public static void jenkinsLog() {
		try {
			System.out.println("LOG");
			logArrList.add("***** End of Jenkin's Test ! *****");
			String time = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());

			PrintWriter out = new PrintWriter(
					new BufferedWriter(new FileWriter(filePath + "/Jenkin'sTest" + time + ".txt", true)));
			for (String s : logArrList) {
				out.println(s);
			}
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
