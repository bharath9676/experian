ipackage com.optum.coliseum.driver;

import java.awt.AWTException;
import java.awt.Desktop;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
/*import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;*/
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.DBUtils;
import com.optum.coliseum.generic.Settings;

import pack1.Webdriver;


/*########################################################################################################################################
##########################################################################################################################################
##########################################################################################################################################
f

													D  R  I  V  E  R      L  I  B  R  A  R  Y

												   ****Logics for driving the test scripts****


Author: Ashutosh Jain, Co-Author: P Bharath Kumar, Satish Alladi, Susheel Mane, Parameshwar Motukoori, Santhosh Lakkapatini, Bhargav Kona
Developed on: 7/1/2016, Modified on: 2/13/2017
Version 1.0
##########################################################################################################################################
##########################################################################################################################################
##########################################################################################################################################*/

public class DriverLib {
	
	int kwType;
	long totalTestStepTime;
	public WebElement webelm1;
	public File Folder;
	public Alert alert;
	public String rtvalRef;
	public static String Mid;				    public String TCDesc;			        String random;                  public int iObjCount=0;
	public JavascriptExecutor js;				public static String Tid;				public String ModDesc;			public int iItrNum;
	public static Connection con_APP;			public static int Sid;					public String stepDesc;			public int itr;
	public static Connection Tcon;				public String TMPLID;					public String SSFilePath;		public int stepStart = 1;
	public WebDriver driver;					public String sAUT;						public String sLogText;			public int stepStop  = 1;
	public WebDriverWait wait;					public String keyword;					public String sQuery;			
	public WebElement webelm;					public String objectRef;				public String sActual;
	public XWPFDocument document;				public String tData;					public String sRepRoot;
	public XWPFParagraph paragraph;				public String ColObjs = "N";			public String sRepFolder;
	public XWPFRun run;							public String screenShot = "Y";			public int ParentSid;
	public FileInputStream imgFile;				public String Reuse_TPKS;				String outputString = "";
	public PrintWriter out;						public String sURL;						String responseString = "";
	public List<WebElement> ObjList;			public String Value;					
	public List <String> TmplParamsList;		public String  dataRef;

	public boolean isFailure;
	public boolean isObjPresent;				public String sEnv;
	public boolean isSmoke 		= false;		public String sUserName = null;
	public boolean isPlayback 	= false;		public String sPassword = null;
	public boolean isSniff 		= false;		public String sTimestamp;
	public boolean isTemplate 	= false;		public String xpath;
	public boolean isExitOnFail = false;		public String Title;
	public boolean isSmkColObjs = false;		public String URL;


 /* ###########################################################################################################################################

                 						              							TestType = 1 for Regression
       																			TestType = 2 for Smoke
       						M A I N   D R I V E R   S C R I P T					TestType = 3 for Playback
       																			TestType = 4 for Sniff
       																			TestType = 5 for Test Data Generation

 	###########################################################################################################################################*/

    public void Drive_REGR(int TestType, String unitMid, String unitTid)
       {
		
    	    sQuery = initVariables(TestType, unitMid);
    	    long testCaseBeginTime = 0;
    		random = String.valueOf(new Random().nextInt(1000)+1000);
    	    if (!(initBrowser(""))) Log("@@@@@@@@@@@@@@@@@ FAILURE! Browser cant be initialized. Exiting Regression Suite!");
    		else {
    			   try {ResultSet rs_Module = Tcon.createStatement().executeQuery(sQuery);
    			   		System.out.println(sQuery);
    			   		while (rs_Module.next()) {
    			   			Mid 	= rs_Module.getString("MODULEID");
    			   			ModDesc = rs_Module.getString("MODULE_NAME");
    			   			Log("MODULEID: "+Mid+" initiated!");
    			   			
    			   			sQuery = getTCQuery(unitMid, unitTid);
    			   			ResultSet rs_TC = Tcon.createStatement().executeQuery(sQuery);
    			   			System.out.println(sQuery);
    			   			while (rs_TC.next()) {
    			   				itr = 1;
    			   				Tid 				= rs_TC.getString("TCID");
    			   				TCDesc				= rs_TC.getString("TC_NAME");
    			   				stepDesc			= rs_TC.getString("TC_DESC");
    			   				
    			   				
    			   				if (!isSmoke && !isSniff){
    			   					itr				= rs_TC.getInt("ITERATIONS");
			   						stepStart 		= rs_TC.getInt("STEP_START");
			   						stepStop 		= rs_TC.getInt("STEP_STOP");
			   						ValidateTDGenVariables();
    			   				}
    			   				initReport();
    			   				if (isPlayback) {if (getTPKFromAppDBforPlayback()) {ReuseWord("Error! No TPK found!", 11, true, false, ParagraphAlignment.LEFT); break;}}
    			   				else if (TestType == 1) if (Reuse_TPKS.equals("N"))  if (DataHandler.FetchTPKfromDM(Tcon, Mid, Tid, sRepFolder)) {
    			   					isFailure = true;
    			   				}

    			   				if (isSniff) {
    			   					sAUT 	= rs_TC.getString("APPLICATION");
    			   					getLoginVariables(1);
    			   				}
    			   				
    			   				if (isSmkColObjs) PrepareWHforSmoke();
    			   				
    			   				
    			   				if (isSniff | isSmoke){
    			   					System.out.println("Navigating to URL "+sURL);
    			   					driver.get(sURL);
        			   				if (!(LoginAction())) {
	    			   					Log("Login failed. Exiting test...");
			  							writeResults(true);
			  							continue;
    			   					}
		  						}
		  						for (iItrNum=1; iItrNum<itr+1; iItrNum++){
			  						isFailure = false;
			  						if(iItrNum==1) stepStart=1;
			  						
			  						sQuery = "select * from DRIVER where TCID = '" + Tid + "' and MODULEID = '"+ Mid + "' ORDER BY STEPID";
			  						if (!isSmoke && !isSniff){
			  							sQuery = "select * from DRIVER where TCID = '" + Tid + "' and MODULEID = '"+ Mid + "' and STEPID BETWEEN "+stepStart+" and "+stepStop+" ORDER BY STEPID";
			  						}
			  						
			  						System.out.println(sQuery);
			  						try {
										ResultSet rs_Driver = Tcon.createStatement().executeQuery(sQuery);
										testCaseBeginTime = System.currentTimeMillis();
										Log("********************BEGIN TEST CASE OF TCID " + Tid + " and MODULEID " + Mid + " ******************************");
										while (rs_Driver.next()) {
											isFailure = false;
											Sid 		= rs_Driver.getInt("STEPID");
											dataRef=rs_Driver.getString("Data_ref");
											if (callProcDataRef (dataRef)) {if (isExitOnFail) break;}
											keyword		= rs_Driver.getString("KEYWORD");
											objectRef 	= rs_Driver.getString("OBJ_REF");
											stepDesc 	= rs_Driver.getString("STEP_DESC");
											screenShot 	= rs_Driver.getString("SCREENSHOT");
											rtvalRef=rs_Driver.getString("RTVAL_REF");
											
											ReplaceTPK(null);
											
											
											if(dataRef==null || dataRef.equalsIgnoreCase("NULL")) dataRef="N";
											if(screenShot==null || screenShot.equalsIgnoreCase("NULL")) screenShot="N";

											if (isSmoke) ColObjs = rs_Driver.getString("COLLECT_OBJECTS");

											getTData();
											execStep();
											Log(Mid + " " + Tid +  "_Step:" + Sid + "-Log Time:" + totalTestStepTime
													+ " milliseconds");
											writeResults(false);
								            updateExecHist();
											if (isFailure) {
//												ReuseWord("Status :"+sAUT+" _Log Message "+getLogText(), 11, true, false, ParagraphAlignment.LEFT); Log(sAUT+"_Log Message "+getLogText());
												run.setColor("ff0000");

												if (isExitOnFail) break;}
										}
										String endTestDate = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
										long endTestCaseTime = System.currentTimeMillis();

										long totalTestCaseTime = endTestCaseTime - testCaseBeginTime;
				                        Log("");
										Log(sTimestamp + " : " + Mid + " " + Tid +  "-Log Time:" + endTestDate + ", " + totalTestCaseTime
												+ " Milliseconds");
										Log("************************END TEST CASE OF TCID " + Tid + " and MODULEID " + Mid + " **********************************");
										Log("");
			  						}
			  						catch (Exception e) {Log(e.getMessage()); e.printStackTrace();}
		  						}
		  						flushReportDoc();
		  						updateExecSummary();
    			   			}
    			   		}
    			   		handleAlert();
    			   }
    			   catch (Exception e){e.printStackTrace();}
    		   }
    	    shutDown();
  		}

/*     ##########################################################################################################################################

											S  U  P  P  O  R  T  I  N  G     M   E  T  H  O  D  S


											Generic methods shared across multiple test types
											* Driver must comply with the below supporting methods
											** All supporting methods must comply with the Driver

       ##########################################################################################################################################*/
       ;

	public String initVariables(int TestType, String unitMid){

		   try {Runtime.getRuntime().exec("wscript " + Constants.PATH_DRIVERS_KILLPROCS );} catch (IOException e) {e.printStackTrace();}

			Tcon 		= DBUtils.DBConnect_Automation();
			if(!isSniff)
				con_APP 	= DBUtils.DBConnect_Application();
			sTimestamp 	= new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
			Reuse_TPKS 	= Settings.getSetting("TDATA_TPK_REUSE", Tcon);
			sEnv 		= Settings.getSetting("ENVIRONMENT", Tcon);
			sAUT 		= Settings.getSetting("AUT", Tcon);
			sRepRoot 	= createReportsDir("REPORT_ROOT");
			String sMQuery = "select * from MOD_SCHEDULER where EXEC_FLAG ='YES' AND APPLICATION ='" + sAUT + "' and ModuleID NOT IN ('SMOKE', 'SNIFF')";
			if 		(TestType == 2){ isSmoke = true;		sMQuery = "select * from MOD_SCHEDULER where ModuleID =  'SMOKE'";  }
 	  		else if (TestType == 3){ isPlayback = true; 	sMQuery = "select * from MOD_SCHEDULER where ModuleID =  '"+unitMid+"'";}
 	  		else if (TestType == 4){ isSniff = true; 		sMQuery = "select * from MOD_SCHEDULER where ModuleID =  'SNIFF'";}
			sRepFolder	= getRepFolder(sRepRoot);

			if (isSmoke) if(Settings.getSetting("SMK_COLOBJS", Tcon).equalsIgnoreCase("Y")) isSmkColObjs = true;
			if (Settings.getSetting("EXIT_TC_ON_FAILURE", Tcon).equalsIgnoreCase("Y")) isExitOnFail = true;
			if (!isSniff) getLoginVariables(0);

			return sMQuery;
  	  	}

  	private String createReportsDir(String getSettings_reportsSkey) {

  			String filePath = Constants.PATH_REPORTS_FOLDER;
  			Folder = new File(filePath); if (!Folder.exists()) Folder.mkdir();

  			return filePath;
	}

  	
	public void getLoginVariables(int flag){
		//flag 0== Sniff Flag 1 = smoke
		String squery="";
		if(flag==0)
			squery ="select * from ENV where APPLICATION = '" + sAUT + "' and TEST_ENVIRONMENT = '" + sEnv + "'";
		else
			squery ="select * from ENV where APPLICATION = '" + sAUT + "'";
		
		   try {ResultSet rs001 = Tcon.createStatement().executeQuery(squery);
				   	while (rs001.next()) {
						sUserName 	= rs001.getString("USER_NAME");
						sPassword 	= rs001.getString("PASSWORD");
						sURL 		= rs001.getString("LOGIN_URL");
				   	}
		   } catch (SQLException e1) {e1.printStackTrace();}
 	  	}

	
  	public String getTCQuery(String unitMid, String unitTid){

  		  String sTQuery = "select * from TC_SCHEDULER  where MODULEID = '" + Mid+ "' and EXEC_FLAG ='YES' AND APPLICATION ='"+sAUT+"' ORDER BY TCID";
		  if (isPlayback) 	sTQuery = "select * from TC_SCHEDULER  where MODULEID = '" + unitMid+ "' AND TCID = '"+unitTid+"' AND APPLICATION ='" + sAUT + "'";
		  else if (isSniff) sTQuery = "select * from TC_SCHEDULER  where MODULEID = '" + Mid+ "' ORDER BY TCID";
		  else if (isSmoke) sTQuery = "select * from TC_SCHEDULER  where MODULEID = '" + Mid+ "' and APPLICATION ='" + sAUT + "' ORDER BY TCID";
 		  return sTQuery;
  	  }

  	public void initReport(){
    	document = new XWPFDocument();
    	//imgFile
   		ReuseWord("Automation Test execution results", 11, true, false, ParagraphAlignment.CENTER);
   		ReuseWord("", 11, false, false, ParagraphAlignment.CENTER);
   		ReuseWord("Module: "+ModDesc, 11, false, false, ParagraphAlignment.LEFT);
   		ReuseWord("Test Case: "+TCDesc, 11, false, false, ParagraphAlignment.LEFT);
   		ReuseWord("Test Case Description: "+stepDesc, 11, false, false, ParagraphAlignment.LEFT);
   		ReuseWord("Execution Timestamp: "+ sTimestamp, 11, false, false, ParagraphAlignment.LEFT);
   		ReuseWord("Tester: "+ Settings.getSetting("ACT_USER", Tcon), 11, false, false, ParagraphAlignment.LEFT);
   		ReuseWord("", 11, false, false, ParagraphAlignment.CENTER);
   		ReuseWord("Step wise execution details:", 13, true, false, ParagraphAlignment.CENTER);
   		ReuseWord("", 11, false, false, ParagraphAlignment.CENTER);
    }

    public void ReuseWord(String Text, int fontSize, Boolean bold, boolean isScrSht, ParagraphAlignment pa){
   		paragraph = document.createParagraph();
   		paragraph.setAlignment(pa);
   		run = paragraph.createRun();

   		try {
			if (isScrSht){run.addPicture(imgFile, XWPFDocument.PICTURE_TYPE_JPEG, "", Units.toEMU(458), Units.toEMU(300));}
			else{run.setText(Text);}
		} catch (InvalidFormatException e) {e.printStackTrace();} catch (IOException e) {e.printStackTrace();}

   		run.setBold(bold);
   		run.setFontSize(fontSize);
    }

   	public void updateExecHist(){
   		int i = 0;
   		sLogText=sLogText.replaceAll("\'","");
   		if (isFailure){	sActual = "Fail"; sLogText="Failed while "+sLogText;}
   		else 			sActual = "Pass";
   		try {
   			ResultSet rs = Tcon.createStatement().executeQuery("Select Max (EXEC_HIST_ID) AS MAXX from EXEC_HIST");
   			while (rs.next()){i = rs.getInt("MAXX") + 1;}

   			if (isTemplate) Tcon.createStatement().executeUpdate("insert into EXEC_HIST(EXEC_HIST_ID, EXEC_TIMESTAMP, MODULEID, TCID, STEPID, RESULT, LOGTEXT, ITERATION, TMPLID, TMPLSTEPID) values ("+i+", '"+sTimestamp+"', '"+Mid+"', '"+Tid+"', '"+ParentSid+"', '"+sActual+"', '"+sLogText+"', '"+iItrNum+"', '"+TMPLID+"', '"+Sid+"')");
   			else 			Tcon.createStatement().executeUpdate("insert into EXEC_HIST(EXEC_HIST_ID, EXEC_TIMESTAMP, MODULEID, TCID, STEPID, RESULT, LOGTEXT, ITERATION) values ("+i+", '"+sTimestamp+"', '"+Mid+"', '"+Tid+"', "+Sid+", '"+sActual+"', '"+sLogText+"', '"+iItrNum+"')");
   		}
   		catch (SQLException e) {e.printStackTrace();}
   	}

   	public void updateExecSummary() {
	   	if (isFailure) sActual = "Fail"; else sActual = "Pass";
	   	try { Tcon.createStatement().executeUpdate("insert into EXEC_SUMMARY(EXEC_TIMESTAMP, MODULEID, TCID, RESULT) values ('"+sTimestamp+"', '"+Mid+"', '"+Tid+"', '"+sActual+"')");}
	   	catch (SQLException e) {e.printStackTrace();}
   	}
   	public String getRepFolder(String filePath){

   		String 			 	sFile = filePath + "Regression";
   		if (isPlayback)		sFile = filePath + "UnitTest";
   		else if (isSmoke)	sFile = filePath + "Smoke";
   		else if (isSniff)	sFile = filePath + "Sniff";

   		File Folder = new File(sFile); if (!Folder.exists()) Folder.mkdir();

   		sFile = sFile + "\\"+ sTimestamp;
   		Folder = new File(sFile); if (!Folder.exists()) Folder.mkdir();

		return sFile;
   	}

   	public void flushReportDoc(){
   		try {
   			FileOutputStream out = new FileOutputStream(new File(sRepFolder +"\\"+Mid+Tid+ "_" +sAUT+sEnv + ".docx"));
			document.write(out);
			out.close();
		} catch (IOException e) {e.printStackTrace();}
   	}

   	public void PublishSummary(){

   		try {
			document = new XWPFDocument();
			ReuseWord("Regression Execution Summary", 14, true, false, ParagraphAlignment.CENTER);
			ReuseWord("Execution initiated on: "+sTimestamp+ " for "+sAUT+" in "+sEnv, 11, false, false, ParagraphAlignment.CENTER);
			ReuseWord("", 11, true, false, ParagraphAlignment.CENTER);
			ReuseWord("Test Status:", 10, true, false, ParagraphAlignment.LEFT);
			ResultSet rs = Tcon.createStatement().executeQuery("select ModuleID, TCID, RESULT from EXEC_SUMMARY where EXEC_TIMESTAMP = '"+sTimestamp+"'");
			while(rs.next()){ReuseWord(rs.getString("ModuleID")+" | "+rs.getString("TCID") +" | "+rs.getString("RESULT"), 10, false, false, ParagraphAlignment.LEFT);
			}
			ReuseWord("", 11, true, false, ParagraphAlignment.CENTER);
			ReuseWord("Test Status in Detail:", 10, true, false, ParagraphAlignment.LEFT);
			ResultSet rs1 = Tcon.createStatement().executeQuery("Select MODULEID, TCID, STEPID, RESULT, LOGTEXT, TMPLID, TMPLSTEPID from EXEC_HIST where EXEC_TIMESTAMP = '"+sTimestamp+"' order by ModuleID, TCID, ITERATION, STEPID, TMPLID, TMPLSTEPID");
			while(rs1.next()){

				if (rs1.getString("TMPLID")!=null)  ReuseWord(rs1.getString("ModuleID")+" | "+rs1.getString("TCID") +" | "+rs1.getString("STEPID") +" | "+rs1.getString("TMPLID") +" | "+rs1.getString("TMPLSTEPID") +" | "+  rs1.getString("RESULT") +" | "+rs1.getString("LOGTEXT"), 10, false, false, ParagraphAlignment.LEFT);
				else 			  					ReuseWord(rs1.getString("ModuleID")+" | "+rs1.getString("TCID") +" | "+rs1.getString("STEPID") +" | "+rs1.getString("RESULT") +" | "+rs1.getString("LOGTEXT"), 10, false, false, ParagraphAlignment.LEFT);

				if (rs1.getString("RESULT").equalsIgnoreCase("Fail")){
					ReuseWord("####### FAILURE #######", 10, false, false, ParagraphAlignment.LEFT);
					ReuseWord("", 10, false, false, ParagraphAlignment.LEFT);
					run.setColor("ff0000");
				}
			}
		} catch (SQLException e) {e.printStackTrace();}

        try {
			FileOutputStream out = new FileOutputStream(new File(sRepFolder +"\\Exec_Summary_" +sAUT+sEnv+"_"+sTimestamp+".docx"));
			document.write(out);
			out.close();
		} catch (FileNotFoundException e) {e.printStackTrace();} catch (IOException e) {e.printStackTrace();}
   	}

	public String getTData(){
		try {
			ResultSet rs_Driver_1 = Tcon.createStatement().executeQuery("select * from DRIVER where TCID = '" + Tid+ "' and MODULEID = '" + Mid + "' and STEPID = " + Sid);
			if (rs_Driver_1.next()) tData = rs_Driver_1.getString("TEST_DATA");
			return tData;
		} catch (SQLException e) { e.printStackTrace();return null;}
   	}

	public void execStep() {
   		long testStepBeginTime = System.currentTimeMillis();
    	   try {
			if (isSmkColObjs) {
				   if (ColObjs.equalsIgnoreCase("Y")) {
					   ObjList   = driver.findElements(By.xpath("//*"));
					   CollectObjects(ObjList);
				   }
			   }
			   if(objectRef!=null && !objectRef.isEmpty() && !objectRef.equalsIgnoreCase("NULL") && !objectRef.equalsIgnoreCase("") && !keyword.equalsIgnoreCase("CallTemplate") && !objectRef.equalsIgnoreCase("NA") ){
				   		if(!keyword.equalsIgnoreCase("WEBSERVICES"))
			    	  	if (!isTemplate) Log(Mid + Tid + "_Step:" +Sid +" | Attempting "+keyword+" on "+objectRef+" with Data Value : "+tData);
			    	  	else 			 Log(Mid + Tid + TMPLID + "_Step:" +Sid +" | TEMPLATE: Attempting "+keyword+" on "+objectRef+" with Data Value : "+tData);
				   		else Log(Mid + Tid + "_Step:" +Sid +" | TEMPLATE: Attempting "+keyword+" Sending webservices xml req : "+ tData);
			    	  	
			    	  	if(objectRef.contains(","))
			    	  		processKeywordTYPE1();
			    	  	else
				            if (getObject(objectRef)){
				            	processKeywordTYPE1(); 
				            }                     							
				            else {
								isFailure = true;
								Log("@@@@@@@@@@@@@@@@@ ERROR! Object cant be accessed by DRIVER!");
				            }
			      }
			      else  { 
			    	  if (!isTemplate)  Log(Mid + Tid + "_Step:" +Sid +" | Attempting "+keyword);
			    	  else 				Log(Mid + Tid + "_"+ TMPLID + "_Step:" +Sid +" | TEMPLATE: Attempting "+keyword);
			    	  	processKeywordTYPE2(); 
			      }
			   	long testStepEndTime = System.currentTimeMillis();
				totalTestStepTime = testStepEndTime - testStepBeginTime;
		} catch (Exception e) {
			e.printStackTrace();
		}
    	   
       }

       public boolean initBrowser(String strURL)
       {
	      String browser = null;
	      boolean isBrowserinitiated = false;
	      try {browser = Settings.getSetting("BROWSER", Tcon);} catch (Exception e1) {}
	      if(browser.equalsIgnoreCase("FIREFOX")){
	    	  System.setProperty("webdriver.gecko.driver", Constants.PATH_DRIVERS_GECKODRIVER);
	    	  DesiredCapabilities capab =  DesiredCapabilities.firefox();
	    	  capab.setCapability("marionette", true);
	    	  driver = new FirefoxDriver(capab);

	      }
	      else if(browser.equalsIgnoreCase("IE")){
	    	    DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
	               ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
	               System.setProperty("webdriver.ie.driver", Constants.PATH_DRIVERS_IEDRIVERSERVER);
	                     driver = new InternetExplorerDriver(ieCapabilities);
	      }
	      else if(browser.equalsIgnoreCase("CHROME")){
	    	  System.setProperty("webdriver.chrome.driver", Constants.PATH_DRIVERS_CHROMEDRIVER);
              ChromeOptions o = new ChromeOptions();
              o.addArguments("disable-extensions");
              o.addArguments("--start-maximized");
              driver = new ChromeDriver(o);
          }
	      else if (browser.equalsIgnoreCase("Phantom")) {
            Capabilities caps = new DesiredCapabilities();
            ((DesiredCapabilities) caps).setJavascriptEnabled(true);
            ((DesiredCapabilities) caps).setCapability("takesScreenshot", true);
            ((DesiredCapabilities) caps).setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY, Constants.PATH_DRIVERS_PHANTOMJS);
           driver = new PhantomJSDriver(caps);
        }
	    else if (browser.equalsIgnoreCase("HU")) driver = new HtmlUnitDriver(true);

        if(!(driver==null)){
        		if(!(browser.equalsIgnoreCase("CHROME")))
               driver.manage().window().maximize();
               if (!((strURL == null) || (strURL == ""))){
                      driver.get(strURL);
                      if (browser.equalsIgnoreCase("IE")) {try {driver.findElement(By.id("overridelink")).click();} catch (Exception e) {}}
               }
               wait  = new WebDriverWait(driver, 40);
               js = (JavascriptExecutor)driver;
               isBrowserinitiated = true;
        }
        else Log("@@@@@@@@@@@@@@@@@ ERROR! While initiating browser");

        return isBrowserinitiated;
    }

       public void shutDown()
       {
    	   PublishSummary();
    	   try {Tcon.close();} catch (SQLException e) {}
    	   if(!isSniff){
    		   try {con_APP.close();} catch (SQLException e) {}   
    	   }
    	   try {driver.quit();} catch (Exception e) {}
    	   try { imgFile.close(); File f = new File(sRepFolder+"\\temp_"+random+".png");  
    	   f.delete();} catch (Exception e) {}
    	   Log(" " + "\n" + "--------------- Execution completed! -----------------");
    	   try {Desktop.getDesktop().open(new File(sRepFolder));} catch (IOException e) {}
       }

       public boolean LoginAction(){
           	if (isSmkColObjs) {
           		Title 	  = driver.getTitle();
            	URL 	  = driver.getCurrentUrl();
            	ObjList   = driver.findElements(By.xpath("//*"));
            	CollectObjects(ObjList);
           	}
           	System.out.println("Current URL: "+driver.getCurrentUrl());
           	handleAlert();
           	try {Thread.sleep(5000);} catch (InterruptedException e1) {e1.printStackTrace();}

              boolean isLoginSuccessful = false;
              String sUN = "username";
              String sPW = "password";

              if (sAUT.equals("J2")) isLoginSuccessful = true;
              else {
                           try {
                             wait.until(ExpectedConditions.presenceOfElementLocated(By.name(sUN))).sendKeys(sUserName);
                             wait.until(ExpectedConditions.presenceOfElementLocated(By.name(sPW))).sendKeys(sPassword);
                             wait.until(ExpectedConditions.presenceOfElementLocated(By.name(sPW))).sendKeys(Keys.ENTER);
                             isLoginSuccessful = true;
                           } catch (Exception e) {Log("Error! @@@@@@@@@@@@@@@@@@ Login page objects distorted for "+ sAUT);}
              }

              return isLoginSuccessful;
       }

       public void LogOUTAction(String sAUT)
       {
              String sSubmitXPath = null;
              switch (sAUT) {
              case "MG"     : sSubmitXPath = ".//div[@id='toplinks']/a[7]";   break;
              case "MP"     : sSubmitXPath = "";                              break;
              case "AC"     : sSubmitXPath = "";                              break;
              case "SQ"     : sSubmitXPath = "";                              break;
              case "C4"     : sSubmitXPath = "";                              break;
              case "J3"     : sSubmitXPath = "";                              break;
              }

              if (!(sAUT.equals("J2"))){
                     try {
                            wait.until(ExpectedConditions.elementToBeClickable(By.xpath(sSubmitXPath))).click();
                     } catch (Exception e) {Log("Error! @@@@@@@@@@@@@@@@@@ LoginOUT button distorted for "+ sAUT);}
              }
       }

       public Boolean IsElementPresent(By locator){
    	      try {wait.until(ExpectedConditions.presenceOfElementLocated(locator));
                   return true;
              }
              catch(Exception e) {
                   Log("Timeout on '" + objectRef+ "'!");
                    Log(e.getMessage());
                    e.printStackTrace();
                    return false;
              }
       }

       private void writeResults(boolean isLoginFailure) 
       {
    	if (screenShot!=null)
		if (screenShot.equalsIgnoreCase("Y") | isLoginFailure) {
			try {
				Robot robot = new Robot();
				SSFilePath = sRepFolder+"\\temp_"+random+".png";
				Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
				BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
				ImageIO.write(screenFullImage, "jpg", new File(SSFilePath));
				imgFile =new FileInputStream(SSFilePath);
			} catch (Exception e) {Log("#################### FAILURE! while creating screenshot");}
		}
		
		if (isLoginFailure) {
			sLogText = "Login Failed. Exiting test!";
			Log("Login Failed. Exiting test!");
			ReuseWord(sLogText, 11, true, true, ParagraphAlignment.LEFT);
		}
		else fetchLogText();
		String sStInfo;
		if (isTemplate) sStInfo = TMPLID +"_Step#"+ Sid; else sStInfo = "Step#"+Sid;
		ReuseWord(Mid + "_" +Tid + "_" + sStInfo + " "+ "-"+ " "+ stepDesc, 11, true, false, ParagraphAlignment.LEFT);
		
		if (isFailure) 	{ ReuseWord("Status : FAILED while "+sLogText, 11, true, false, ParagraphAlignment.LEFT); Log("FAILED while "+sLogText);}
		else 			{ ReuseWord("Status : PASSED while "+sLogText, 11, true, false, ParagraphAlignment.LEFT);}
		if (screenShot!=null) if (screenShot.equalsIgnoreCase("Y")) {ReuseWord("", 11, true, true, ParagraphAlignment.LEFT);} 
		Log("");
		Log("==========================================================" + sStInfo + " Executed"+ "==========================================================");
		Log("");
		if (screenShot.equalsIgnoreCase("Y") | isLoginFailure){try {imgFile.close();} catch (IOException e) {e.printStackTrace();}
		}
	}
		

   	public void fetchLogText(){
		try {
			
			ResultSet r = Tcon.createStatement().executeQuery("Select LOGTEXT from KEYWORDS WHERE KEYWORD = '"+keyword+"' AND KW_TYPE_ID="+kwType+"");
			while (r.next()) {
				sLogText = r.getString("LOGTEXT");
			if(tData==null) tData = "NA";
			
			if(keyword.equalsIgnoreCase("WEBSERVICES")){ sLogText=sLogText.replace("TDATA",getTData());}
			else sLogText=sLogText.replace("TDATA",tData);
			if(objectRef==null || objectRef.equalsIgnoreCase("null".toLowerCase())) objectRef ="NA";
			else
				if(kwType==1)
					if(keyword .equals("VerifyEquals") | keyword .equals("VerifyContains")) objectRef =webelm.getText();
					
			sLogText=sLogText.replace("OBJREF",objectRef);
			}
		} catch (SQLException e) {e.printStackTrace();}

	}

       public void processKeywordTYPE1()     //TYPE1 refers to all the Keywords which use OBJECT to perform an Action
       {if (isObjPresent) {
			try {
				Highlight(0, webelm);
				kwType=1;		
				System.out.println(",,,,,"+keyword+",,,,");
				switch (keyword) {
				  case "Set"                 : webelm.clear(); webelm.sendKeys(tData);                      break;
                  case "Click"               : webelm.click();                                              break;
                  case "ClickJS"             : ClickJS();													break;
                  case "ClickMouseHover"     : Mousehover(2);                                               break;
                  case "DoubleClick" 		 : Doubleclick();  												break;
                  case "GetText"        	 : GetText();   				      		  					break;
                  case "MoveMouseHover"      : Mousehover(1);                                               break;
                  case "ScrollToObject"		 : ScrollToObject(webelm);										break;
     			  case "Select"              : new Select(webelm).selectByVisibleText(tData);  				break;
				  case "SelectDate"  		 : webelm.click(); Thread.sleep(2000);  SelectRandomDate();		break;
				  case "SelectRandomExcept"  : SelectRandomExcept(); 										break;
                  case "WEBSERVICES"  	 	 : webservices();	 											break;
                  case "VerifyEquals"		 : Verify(true, 1);                    							break;//Equals
                  case "VerifyContains"		 : Verify(true, 0);    	                 				        break;//Contains
                  case "VerifyDropdown"	 	 : VerifyAbsenceInDropdown();                           		break;
                  case "VerifyEnable" 		 : VerifyEnable(); 												break;
                  case "SelectRandom"     	 : Thread.sleep(4000);selectList(2);							break;
   				  case "SelectListByName" 	 : webelm.click();Thread.sleep(2000); selectList(0);			break;
   				  case "SelectListRandom"	 : webelm.click();Thread.sleep(2000); selectList(1);			break;
   				  case "VerifyListValues"     : SplitDataRef();  											break;
                  case "ClickTable" 		 : Keyword_Table(0);											break;
                  case "VerifyTable" 		 : Keyword_Table(2);											break;
                  case "ClickTableArrow"  	 : Keyword_Table(1); 											break;
                }
				Highlight(1, webelm);
				handleAlert();
			} catch (Exception e) {
				e.printStackTrace();
				Log(e.getMessage());

				isFailure = true;
			}
		} else {
			isFailure = true;
			Log("@@@@@@@@@@@@@@@@@ ERROR!! Object is either not displayed or is not enabled!");
		}
       }

       public void processKeywordTYPE2() throws Exception    //TYPE2 refers to all the Keywords which DO NOT use OBJECT to perform an Action
       {
    	   kwType=2;
    	   System.out.println(",,,,,"+keyword+",,,,");
              switch (keyword) {
              case "AccessURL"      : driver.get(tData);                      	break;
              case "VerifyURL":
            	  if(tData==null || tData=="NA" || tData.equalsIgnoreCase("null") ||tData.equals(""))
            		  PlaceTestData(VerifyURL(driver.getCurrentUrl()));
            	  PlaceTestData(VerifyURL(tData));
      			break;
              case "AcceptAlert"    : AcceptAlert(); 							break;
              case "CallTemplate"   : ParentSid = Sid; CallTemplate();  	  	break;
			  case "CallAutoIT"		: callAutoIT();						 	  	break;
              case "ClickRandom"	: ClickRandom();						  	break;
              case "GetCurrentURL" 	: PlaceTestData(driver.getCurrentUrl()); 	break;
              case "ProcessDataRef" : 											break;
              case "CloseCurrentTab": winhand(true);                            break;
              case "SwitchToTab"	: winhand(false);                           break;
              case "SwitchToFrame"  :Thread.sleep(2000); driver.switchTo().frame(0);break;
              case "SwitchToWindow" : driver.switchTo().defaultContent();    	break;
              case "VerifyEquals"   : Verify(false, 1); 	                    break;//Equals
              case "VerifyContains"	: Verify(false, 0);    		                break;//Contains
              case "Parser"         :  parser(); break;
              case "Services"		: services(false, true);					break;	//Plan to retire this
              case "VerifyWarning"	: services(false, true);					break;  //Plan to retire this
              case "VerifyServAbs"	: services(false, false);					break;  //Plan to retire this
              case "Sleep"			: sleep();									break;
              case "VerifyAbsence"	: if (!getObject(tData)) isFailure=false;	break;
              case "VerifyPresence"	: getObject(tData); 						break;
			  case "ScrollToBottom"	: ScrollToBottom();							break;
			  case "ScrollToTop"	: scrollToUP();								break;
			  case "InsertTPK"		: PlaceTDinDM();						    break;
			  case "FileDownload"	: callAutoIT();								break;
			  case "FileDownload_Pharma": callAutoITScript2();					break;
			  case "VerifyXML"      : VerifyXML(); 								break;
              }
       }

         public boolean getObject(String ObjRef){
        	 boolean isObj = false;
             try {
                    Statement st9=Tcon.createStatement();
                    ResultSet rs9=st9.executeQuery("select * from OBJ_REP where OBJ_REF = '" + ObjRef + "'");
                    if(rs9.next())
                    {
                        String id = rs9.getString("id");
                        if(!(rs9.wasNull())) {
                                 if (!(id.equals(""))){
                                        isObjPresent = IsElementPresent(By.cssSelector("*[id="+id+"]"));
                                        if(isObjPresent){
                                               webelm = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("*[id="+id+"]")));
                                               isObj=true;
                        }}}

                        if (!isObj){
		                          String name = rs9.getString("name");
		                          if(!(rs9.wasNull())) {
		                                 if (!(name.equals(""))){
		                                        isObjPresent = IsElementPresent(By.cssSelector("*[name="+name+"]"));
		                                        if(isObjPresent){
		                                               webelm = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("*[name="+name+"]")));
		                                               isObj=true;
		                          }}}
                        }
		                if (!isObj){
		                          String linkText = rs9.getString("linkText");
		                          if(!(rs9.wasNull())){
		                                 if (!(linkText.equals(""))){
		                                        isObjPresent = IsElementPresent(By.linkText(linkText));
		                                        if(isObjPresent){
		                                               webelm =wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(linkText)));
		                                               isObj=true;
		                          }}}
		                }
		                if (!isObj){
		                           xpath = rs9.getString("xpath");
		                          if(!(rs9.wasNull())){
		                                 if (!(xpath.equals(""))){
		                                        isObjPresent = IsElementPresent(By.xpath(xpath));
		                                        if(isObjPresent){
		                                        webelm = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
		                                        isObj=true;
		                          }}}

		                }
                    }
             } catch (SQLException e) {isFailure=true; Log(e.getMessage());e.printStackTrace();}
             return isObj;
      }

	public boolean callProcDataRef(String sDataRef){
		boolean isFail = false;
		if (sDataRef!=null) {
			if (!sDataRef.equalsIgnoreCase("null") && !sDataRef.equalsIgnoreCase("NA") && !sDataRef.equalsIgnoreCase("")){
				if (!isTemplate){
					if (DataHandler.ProcessDataRef(Tcon, con_APP, sDataRef, sAUT, Mid,Tid, Sid, null, null, sRepFolder).equals("^__^")) {
						Log("Data Not Found for the given reference! Exiting Test...");
						isFail  = true;
					}
				}
				else {
					if (DataHandler.ProcessDataRef(Tcon, con_APP, sDataRef, sAUT, Mid,Tid, Sid, TMPLID, TmplParamsList, sRepFolder).equals("^__^")) {
					Log("Data Not Found for the given reference! Exiting Test...");
					isFail  = true;
					}
				}
			}
		}
		return isFail;
	}
       public  void handleAlert(){
           try {
                  if (driver instanceof PhantomJSDriver) {
	                   PhantomJSDriver phantom = (PhantomJSDriver) driver;
	                   phantom.executeScript("window.alert = function(){}");
	                   phantom.executeScript("window.confirm = function(){return true;}");
	                   Log("********************************************** ALERT PRESENT **********************************************");
                  }
                  else {if(isAlertPresent()) {Alert alert = driver.switchTo().alert(); alert.accept();}}
           } catch (Exception e) {
                  Log("Failed to hanlde Alert");
                  e.printStackTrace();
           }
       }

       public boolean isAlertPresent() {
            boolean isAlert = false;
              try{
               alert= driver.switchTo().alert();
                isAlert = true;
            }
            catch (NoAlertPresentException Ex) { return false; }
              return isAlert;
       }

       public void PrepareWHforSmoke(){
    	   if (Settings.getSetting("SMK_REFRESH_WH", Tcon).equalsIgnoreCase("Y")){
		       try {Tcon.createStatement().executeUpdate("Delete from OBJ_WH where application = '"+sAUT+"'");}
		       catch (SQLException e) {e.printStackTrace();}
		       Log("Old Object Warehouse Records Deleted for "+sAUT+"!");
    	   }
       }

       public boolean getTPKFromAppDBforPlayback(){
    	   try {
    		   ResultSet rs9=Tcon.createStatement().executeQuery("Select ESQL from SQLS s, DM_MAP D where D.DMID = S.SQLID and ModuleID = '"+Mid+"' and TCID = '"+Tid+"'");
    		   while (rs9.next()){
    			   ResultSet rs_APP=con_APP.createStatement().executeQuery(rs9.getString("ESQL"));
    			   while(rs_APP.next()){
                     Tcon.createStatement().executeUpdate("UPDATE DM_MAP SET ACTIVE_TPK = '"+rs_APP.getString(1)+"' where MOduleID = '"+Mid+"' and TCID = '"+Tid+"'");
    			   }
    		   }
    	   }
    	   catch (SQLException e1) {
    		   isFailure = true;
    		   Log("################# Failure! Data Manager failed while Playback. Please revisit DM Query.");
    	   }
    	   return isFailure;
       }

       private void Highlight(int flag, WebElement webelement) {
			try {
				if (flag == 0) 	{js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');",webelement);}
				else 			{js.executeScript("arguments[0].setAttribute('style', 'background: ; border:0px ; ');", webelement);}
			}
			catch (Exception e) {}
       }

       public void PlaceTDinDM(){
    	try {
    		String dmID = "";
    		ResultSet rs=Tcon.createStatement().executeQuery("SELECT DMID FROM DM_MAP WHERE TCID = '"+Tid+"' AND MODULEID = '"+Mid+"'");
			   if(rs.next()){
				   dmID = rs.getString("DMID");
			   }
			System.out.println("Insert into DM Values ('"+dmID+"', '"+tData+"', 'R')");
    		Tcon.createStatement().executeUpdate("Insert into DM Values ('"+dmID+"', '"+tData+"', 'R')");}
    	catch (SQLException e) {e.printStackTrace();}

       }

       public void resetIterations(){
    	   try {Tcon.createStatement().executeUpdate("UPDATE TC_SCHEDULER SET ITERATIONS = NULL");}
    	   catch (SQLException e) {e.printStackTrace();}
       }

       public void ValidateTDGenVariables(){
    	   int maxStep = 1;
    	   try {
    		   ResultSet rs=Tcon.createStatement().executeQuery("Select MAX(STEPID) AS MAX from DRIVER WHERE TCID = '" + Tid + "' and MODULEID = '"+ Mid + "'");
			   while(rs.next()){
                 maxStep = rs.getInt("MAX");
			   }
    	   }
    	   catch (SQLException e) {e.printStackTrace();}
    	   if (itr 	     == 0) itr = 1;
    	   if (stepStart == 0) stepStart = 1;
    	   if (stepStop  == 0) stepStop  = maxStep;
       }

       public void PlaceTestData(String sTdata){
    	   try {
				if(isTemplate)
					Tcon.createStatement().executeUpdate("Update TEMPLATES Set TEST_DATA ='"+sTdata+"' where TMPLID = '" +TMPLID + "' and STEPID = "+Sid);
	            else
	            	Tcon.createStatement().executeUpdate("Update DRIVER Set TEST_DATA ='"+sTdata+"' where Application = '"+sAUT+"' and TCID = '" +Tid + "' and MODULEID = '" +Mid + "' and STEPID = "+Sid);
			} catch (SQLException e) {isFailure = true;	e.printStackTrace();}
       }

/*##################################################################################################################################################
  ##################################################################################################################################################

                                       						METHODS FOR KEYWORDS

  ##################################################################################################################################################
  ##################################################################################################################################################*/

       public void GetText(){
    	   	try {Tcon.createStatement().executeUpdate("UPDATE DRIVER SET TEST_DATA = '"+webelm.getText()+"' where MODULEID = '"+Mid+"' AND TCID = '"+Tid+"' AND STEPID = "+Sid);}
    		catch (SQLException e) {e.printStackTrace();}
       }

       public void ClickJS(){
    	   ((JavascriptExecutor) driver).executeScript("arguments[0].click();", webelm);
       }

       public void Keyword_Table(int table){
		     List<WebElement> rows =driver.findElements(By.xpath(GetTableSize("tr", "")));
		     List<WebElement> columns =driver.findElements(By.xpath(xpath));

		     for(int i=1; i<=rows.size(); i++){
		      try {
		        for(int j=1; j<=columns.size(); j++){
		                 webelm =driver.findElement(By.xpath(GetTableSize("tr", "["+i+"]/td["+j+"]")));
		                 if(webelm.getText().equalsIgnoreCase(tData)){
		                	 System.out.println("***************Match found in the table***************");
		                	 if(table==1){ j=j-1;  }
		                	 if(table!=2){
		                		 driver.findElement(By.xpath(GetTableSize("tr", "["+i+"]/td["+j+"]")+"/a")).click();
		                	 }
		                	 break;
		                 } 		        }
		    } catch (Exception e) { System.out.println("Match not found. Moving to the next row "); }}
     }

   public void SelectRandomExcept(){
	   try {
		   	String[] split = tData.split("\\,");
	   		Select objSel = new Select(webelm);
			List <WebElement> weblist = objSel.getOptions();
			int iSelect = 0;
			boolean isGood = false;

			while (isGood!=true){
				iSelect = new Random().nextInt(weblist.size()); if (iSelect == 0) iSelect = 1;
				for(int i = 0;i<split.length;i++){
					if (weblist.get(iSelect).getText().trim().equalsIgnoreCase(split[i].trim())) {isGood = false; break;}
					else isGood = true;
				}
			}
			try {
				objSel.selectByIndex(iSelect);
				tData = weblist.get(iSelect).getText().trim();
				PlaceTestData(tData);
			} catch (Exception e) {isFailure = true;}
	   	 }
		catch (Exception e) {e.printStackTrace();}
   }
   private void SelectRandomDate() throws Exception{
       String ClickOnNext= dataRef.split(",")[0].split("\\)")[0].split("\\(")[1];
       
       String getDate;      String selectDate = null;      int convDate;
       for(int i=1; i<=Integer.parseInt(ClickOnNext); i++){
    	   getObject(dataRef.split(",")[0].split("\\)")[0].split("\\(")[0]);
    	   webelm.click();
    	   Thread.sleep(2000);
       }
       
       if(dataRef.split(",")[1].contains("(")){
    	   getDate=dataRef.split(",")[1].split("\\(")[1].split("\\)")[0];
    	   if(getDate.contains("-")){
    		   convDate=Calendar.getInstance().get(Calendar.DAY_OF_MONTH)-Integer.parseInt(getDate);   
    	   }else{
    		   System.out.println(" getting Date is "+Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
    		   convDate=Calendar.getInstance().get(Calendar.DAY_OF_MONTH)+Integer.parseInt(getDate);
    	   }
    	   selectDate=String.valueOf(convDate);
    	   dataRef =dataRef.split(",")[1].split("\\(")[0].replace("\\(","");
       }else{
    	   selectDate="1";
    	   dataRef=dataRef.split(",")[1];
       }
       getObject(dataRef);
       List<WebElement> colum
       ns=webelm.findElements(By.tagName("td"));
       for (WebElement cell : columns)
       {
          if (cell.getText().equalsIgnoreCase(selectDate))
          {
             cell.click();
             System.out.println(cell.getText());
             break;
          }
       }
   }
   



   public void sleep(){
	   try {Thread.sleep(Integer.parseInt(tData));
	   } catch (NumberFormatException e) {e.printStackTrace();} catch (InterruptedException e) {e.printStackTrace();}
   }

   public void getCurrentURL(){

   }
   
   
   public void parser(){
	   String[] split = dataRef.split("\\|");
	  	   try {
	  		   String PTag  = split[2];
	  		   String CTag  = split[4];
	  		   String Exvalue = split[6];
	  		   String[] XML = tData.split("\\|");
	  		   String file = XML[0];
	  			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	  			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	  			Document doc = dBuilder.parse(new InputSource(new StringReader(file)));
	  			doc.getDocumentElement().normalize();
	  			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

	  			NodeList nList = doc.getElementsByTagName(PTag);
	  			System.out.println("----------------------------");
	  			System.out.println(nList.getLength());
	  			for (int temp = 0; temp < nList.getLength(); temp++) {

	  				Node nNode = nList.item(temp);

	  				System.out.println("\nCurrent Element :" + nNode.getNodeName());
	  				
	  				if(nNode.hasChildNodes()){
	  					
	  					NodeList clist =nNode.getChildNodes();
	  					System.out.println(clist.getLength());
	  					Element eElement = (Element) nNode;
	  					
	  					int mylist = eElement.getElementsByTagName(CTag).getLength();
	  					System.out.println("Duplicates tags"+mylist);

	  					for(int i=0;i<mylist;i++){
	  					//System.out.println(eElement.getElementsByTagName("Code").item(i).getTextContent());
	  					if(eElement.getElementsByTagName(CTag).item(i).getTextContent().equals(Exvalue)){
	  						System.out.println("========================================================");
	  						System.out.println(Exvalue+" Value is lies In this XMl between the "+ nNode.getNodeName()+ " Tags ");
	  					}
	  				
	  					}
	  					tData=Exvalue;
	  			        compareData(Exvalue);}}
	  		    } catch (Exception e) {
	  			e.printStackTrace();
	  		    }
	   
	  }


	public void ClickRandom(){
		try {
			Actions actions = new Actions(driver);
			Robot robot = new Robot();
			robot.mouseMove(5,50);
			actions.click().build().perform();
		} catch (AWTException e) {e.printStackTrace();}
		try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
	}


	   public  String GetTableSize(String td, String remainedXpath){
		   	String lastOne = xpath.split(td)[xpath.split(td).length-1];
        return xpath.replace(lastOne, remainedXpath);
	   }

		public void AcceptAlert(){
				handleAlert();
			  try {
				Robot robot=new Robot();
				robot.keyPress(java.awt.event.KeyEvent.VK_ENTER);
				robot.keyRelease(java.awt.event.KeyEvent.VK_ENTER);
				try {Thread.sleep(2000);
				} catch (InterruptedException e) {e.printStackTrace();}
			   } catch (AWTException e) {e.printStackTrace();}
			   Alert alert=driver.switchTo().alert();
			   alert.accept();
 		}

 		public void Mousehover(int MH_Type) throws InterruptedException{
              Actions actions = new Actions(driver);

              Thread.sleep(4000);
              System.out.println(webelm);
              actions.moveToElement(webelm);
              if (MH_Type == 1) actions.build().perform();
              else actions.click().build().perform();
       }

       public void Doubleclick() throws Exception{
    	   Actions actions = new Actions(driver);
    	   actions.moveToElement(webelm);
    	   actions.doubleClick().build().perform();
       }

       public void move(WebElement webelm){
              Actions actions = new Actions(driver);
              WebElement Logg = webelm;
              actions.moveToElement(Logg);
       }

       public void VerifyEnable(){
        	   if (tData.equalsIgnoreCase("false")){
        		   if(webelm.isEnabled()){
        			   isFailure = true; Log("@@@@@@@@@@@@@@@@@ FAILURE! Element is enabled"); }
        	   }
        	   else{
        		   if(!webelm.isEnabled()){
        			   isFailure = true; Log("@@@@@@@@@@@@@@@@@ FAILURE! Element is disabled"); }
        	   }
       }

       
       public void  Verify(boolean isKWType1, int flag){
    	   try {
			String[] split =null;
			   if(tData!=null && !tData.equalsIgnoreCase("NULL") &&  !tData.equalsIgnoreCase("NA")){
			  	split = tData.split("\\|\\|");
			  	String sExp = split[0];

			  	if (isKWType1) sExp = webelm.getText();

				else if (sExp.length()==1) Log("@@@@@@@ Warning! Step incorrectly written. Need more arguments in Dataref for comparision.");
			  	for (String sAct : split){

			  		if(flag==1){
			  			if (!(sAct.equalsIgnoreCase(sExp))) 
			  				isFailure = true;
			  		}
			  		else{
			  			System.out.println(sAct+",,,"+sExp);
			  			if (!( sAct.toLowerCase().contains(sExp.toLowerCase()) || sExp.toLowerCase().contains(sAct.toLowerCase()) ))  
			  				isFailure = true;
			  		}

				}
			  }
		} catch (Exception e) {
			e.printStackTrace();
		}
      }

       public void VerifyAbsenceInDropdown() {

           Select select = new Select(webelm);
           try { select.selectByVisibleText(tData); isFailure = true;}
           catch (Exception e) {}
      }
       public void CallTemplate() throws Exception  {
    	   Log("");
    	   Log("_________________");
    	   Log("Entering Template");
    	   Log("_________________");
    	   Log("");
    	   isTemplate = true;
    	   if(tData!=null && !tData.equalsIgnoreCase("NA") && !tData.equalsIgnoreCase("NULL"))
    	   TmplParamsList = Arrays.asList(tData.split("\\s*,\\s*"));
    	   try {
    		   		 isFailure=false;
                     ResultSet rs_Temp=Tcon.createStatement().executeQuery("select * from Templates where TMPLID = '"+objectRef+"' ORDER BY STEPID");
                     while(rs_Temp.next()){
                    	 isFailure=false;
                    	   Sid           = rs_Temp.getInt ("STEPID");
                           TMPLID		 = rs_Temp.getString ("TMPLID");
                           dataRef= rs_Temp.getString("Data_ref");
                           
                           if (callProcDataRef (dataRef)) {isFailure = true; //if (isExitOnFail) break;
                           }
	                       objectRef     = rs_Temp.getString ("OBJ_REF");
	                       keyword       = rs_Temp.getString ("KEYWORD");
	                       rtvalRef		 =rs_Temp.getString("RTVAL_REF");
	                       
	                       ReplaceTPK(TMPLID);
	                       
	                       ResultSet rs_Temp1=Tcon.createStatement().executeQuery("select TEST_DATA FROM Templates where TMPLID = '"+TMPLID+"' AND STEPID = "+Sid);
	                       if (rs_Temp1.next()) tData = rs_Temp1.getString("TEST_DATA");

	                       execStep();
	                       Log(Mid + " " + Tid + " TMPLID " + TMPLID + "_Step:" + Sid + "-Log Time:" + totalTestStepTime
		       						+ " milliseconds");
	                       Thread.sleep(4000);
	                       writeResults(false);
				           updateExecHist();
				           if (isFailure) {if (isExitOnFail) break;}
                     }
           } catch (SQLException e) {e.printStackTrace(); Log(e.getMessage());e.printStackTrace();}
    	   finally {
    		   isTemplate 		= false;
    		   TmplParamsList 	= null;
    		   TMPLID 			= null;
    	   }

    	   Log("");
    	   Log("_________________");
    	   Log("Exiting Template");
    	   Log("_________________");
    	   Log("");
       }

       private void callAutoIT() {
      		try {
      			Process proc=Runtime.getRuntime().exec(Constants.PATH_AUTOIT_FILEDOWNLOAD);
      			InputStream is = proc.getInputStream();
      			int retCode = 0;
      			while (retCode != -1){retCode = is.read();}
      		} catch (IOException e) {e.printStackTrace();}
       	}


       private void callAutoITScript2() {
      		try {
      			Process proc=Runtime.getRuntime().exec(Constants.PATH_AUTOIT_REQUESTPHARMACYCARD);
      			InputStream is = proc.getInputStream();
      			int retCode = 0;
      			while (retCode != -1){retCode = is.read();}
      		} catch (IOException e) {e.printStackTrace();}
       	}

       public void winhand(boolean isCloseTab) {
		   ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
           if (isCloseTab) {
        	    driver.close();
        	    driver.switchTo().window(tabs.get(0));
           }
           else driver.switchTo().window(tabs.get(1));
           handleAlert();
	   }



  	public void ScrollToBottom() {
  		((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
  	}

	private void ScrollToObject(WebElement webElement) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", webElement);
	}

    public void services(boolean isWarningImage, boolean isPresenceExpected) {
   	 int i = 0;
   	 switch (tData)
   	   {
          case "DME"  : i =1; break;		case "OP"   : i =2; break;		case "HM"   : i =3; break;
          case "HH"   : i =4; break;		case "PT"   : i =5; break; 		case "MRI"  : i =6; break;
          case "TRSP" : i =7; break; 		case "TRSL" : i =8; break;		case "DNT"  : i =9; break;
       }
   	   String button = ".//*[@id='serviceItemSection']/div/div["+i+"]/div/div[1]/div[3]/button[1]";
   	   if (isWarningImage) button= ".//*[@id='serviceItemSection']/div/div["+i+"]/div/div[1]/div[3]/img";

   	   try {
   		   if(IsElementPresent(By.xpath(button))){
	   	   		webelm = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(button)));
		   	   	if(!webelm.isDisplayed()) {if (isPresenceExpected) isFailure = true;}
		   	   	else {
		   	   		if (!isPresenceExpected) isFailure = true;
		   	   		else {
		   	   			if(!isWarningImage){
		   	   		   		webelm.click();
		   	   	  	   		objectRef = "TM000"+i;
		   	   	  	   		CallTemplate();
		   	   	  	   	}
		   	   		}
   		   		}
   	   		}
   	   }
   	   catch (Exception e) {}
    }




    private int generateRandomDigit(int digit){
    	int iSelect = new Random().nextInt(digit);
		if(iSelect == 0) iSelect = 1;
		return iSelect;
    }

    private void selectList(int flag) throws InterruptedException, SQLException{
    	WebElement findElement; String position ="1";
		if(dataRef.contains("||")){		String[] split = dataRef.split("\\|");  dataRef = split[0];	position = split[2];}

       	try {
			if(flag==1){
				ResultSet rs_ObjeRep = Tcon.createStatement().executeQuery("SELECT XPATH FROM OBJ_REP WHERE OBJ_REF ='"+dataRef+"'");
				if (rs_ObjeRep.next()) {
					 findElement = driver.findElement(By.xpath(rs_ObjeRep.getString("xpath")+"["+generateRandomDigit( driver.findElements(By.xpath(rs_ObjeRep.getString("xpath"))).size())+"]"));
					 Thread.sleep(2000);
					 findElement.click(); Value = findElement.getText();
				}
			}
			else if (flag==2) {
			 	Select 				objSel 	= new Select(webelm);
			 	List <WebElement> 	weblist = objSel.getOptions();
			 	if(weblist.size()==0) {isFailure = true;				Log("Drop down is empty. Cant proceed with Random Selection");}
			 	else{
				objSel.selectByIndex(generateRandomDigit( objSel.getOptions().size()));
				Value = weblist.get(generateRandomDigit( objSel.getOptions().size())).getText();
			 	}
			}
			else{
				 System.out.println(driver.findElement(By.xpath("(.//li[contains(text(),'"+dataRef+"')])[position()="+position+"]")));
			   	 findElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(.//li[contains(text(),'"+dataRef+"')])[position()="+position+"]")));
			   	 findElement.click(); 	 Value = findElement.getText();
				}
		} catch (Exception e) {
			isFailure=true;
		}
       		PlaceTestData(Value);
   	}

    private  void SplitDataRef(){
    	String getLastParam;
    	try {
			webelm.click();	getLastParam="1";
			if(dataRef.contains("||"))  getLastParam= getLastParam("\\|");
			List<String> dataRefValues = Arrays.asList(tData.split(","));
			for (String dataRefValue : dataRefValues) {
					if(dataRefValue!="")
					webelm1 =wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(.//li[contains(text(),'"+dataRefValue+"')])[position()="+getLastParam+"]")));
			}
			webelm.click();
		} catch (Exception e) {
			e.printStackTrace();
			isFailure=true;
		}
    }
    private String getLastParam(String replacor){
        return dataRef.split(replacor)[dataRef.split(replacor).length-1];
      }
    public void scrollToUP(){
  		((JavascriptExecutor) driver).executeScript("window.scrollTo(250,0)");
  	}
/*       #############################################################################################################
                                  METHODS FOR KEYWORDS END
       #############################################################################################################*/

    public void Log(String text){
	    try {
	    	//Bharath Passing variable here
	    	out = new PrintWriter(new BufferedWriter(new FileWriter(sRepFolder+"\\log.txt", true)));
	    	out.println(text);
	    	out.close();
	    }
	    catch (IOException e) {e.printStackTrace();}
    }

/*    public void CollectObjects() {
  	  String ID; String Name; String LinkText; String TagName; String Class; String Title = driver.getTitle(); String URL = driver.getCurrentUrl();

  	   List<WebElement> ObjList = driver.findElements(By.xpath("//*"));

  	   System.out.println("Number of Objects present on this page: "+ObjList.size());
  	   Log("Number of Objects present on this page: "+ObjList.size());

  	   for(int i = 0; 	i<ObjList.size(); 	i++)
  	   {
  		   System.out.println(iObjCount);

	            	try {TagName 	= ObjList.get(i).getTagName(); 			} catch (Exception e) {TagName  = null;}
	            	if(TagName!="table"  | TagName!="tr" | TagName!="td"){
		            	try {Class 		= ObjList.get(i).getAttribute("class");} catch (Exception e) {Class 	= null;}
		            	try {ID 		= ObjList.get(i).getAttribute("id");	} catch (Exception e) {ID 	  	= null;}
		            	try {Name 		= ObjList.get(i).getAttribute("name"); } catch (Exception e) {Name 	= null;}
		            	try {LinkText 	= ObjList.get(i).getText(); 			} catch (Exception e) {LinkText = null;}

		            	String insertIntoObj ="insert into OBJ_WH (OWHID, ID, NAME, LINKTEXT, TAG_NAME, CLASS_NAME, TITLE, PAGEURL, APPLICATION) values ('"
	                          + iObjCount + "', '"
	            			  + ID + "','"
	            			  + Name + "','"
	            			  + LinkText + "','"
	            			  + TagName + "','"
	            			  + Class + "','"
	                    	  + Title + "','"
	                    	  + URL + "','"
	            			  + sAUT + "')";

	            	  //System.out.println(insertIntoObj);
	            	  try {Tcon.prepareStatement(insertIntoObj).executeUpdate();} catch (SQLException e) {e.printStackTrace();}

	                  iObjCount=iObjCount+1;
          	 	}
          }
   }
*/
     /*public String getTagAction(String tagType){
              String tagAction;
              if(tagType.equals("text") || tagType.equals("password") ||tagType.equals("email")) tagAction = "Set";
              else if(tagType.equals("submit")|| tagType.equals("button") ||  tagType.equals("radio") || tagType.equals("checkbox")) tagAction = "Click";
              else tagAction = "Unknown";
              return tagAction;
       }

     	public void CollectObjects(List<WebElement> ObjectList) {

     	int sz = ObjectList.size();
		iObjCount = iObjCount + sz;

		System.out.println("Number of Objects present on this page: "+sz);
		int j = (int) (Math.floor(sz/10));

		ObjCollection R1 = 	(new DriverLib()).new ObjCollection("Thread1", ( 0*j)+1,  1*j, ObjectList);		R1.start();
	    ObjCollection R2 = 	(new DriverLib()).new ObjCollection("Thread2", ( 1*j)+1,  2*j, ObjectList);		R2.start();
	    ObjCollection R3 = 	(new DriverLib()).new ObjCollection("Thread3", ( 2*j)+1,  3*j, ObjectList); 	R3.start();
	    ObjCollection R4 = 	(new DriverLib()).new ObjCollection("Thread4", ( 3*j)+1,  4*j, ObjectList); 	R4.start();
	    ObjCollection R5 = 	(new DriverLib()).new ObjCollection("Thread5", ( 4*j)+1,  5*j, ObjectList); 	R5.start();
	    ObjCollection R6 = 	(new DriverLib()).new ObjCollection("Thread6", ( 5*j)+1,  6*j, ObjectList); 	R6.start();
	    ObjCollection R7 = 	(new DriverLib()).new ObjCollection("Thread7", ( 6*j)+1,  7*j, ObjectList); 	R7.start();
	    ObjCollection R8 = 	(new DriverLib()).new ObjCollection("Thread8", ( 7*j)+1,  8*j, ObjectList); 	R8.start();
	    ObjCollection R9 = 	(new DriverLib()).new ObjCollection("Thread9", ( 8*j)+1,  9*j, ObjectList); 	R9.start();
	    ObjCollection R10 = (new DriverLib()).new ObjCollection("Thread10",( 9*j)+1, 10*j, ObjectList); 	R10.start();
	    ObjCollection R11 = (new DriverLib()).new ObjCollection("Thread11",(10*j)+1, sz-1, ObjectList);		R11.start();

	    ThreadGroup currentGroup = Thread.currentThread().getThreadGroup();
		int noThreads = currentGroup.activeCount();
		Thread[] listThreads = new Thread[noThreads];
		currentGroup.enumerate(listThreads);

		for (int i = noThreads-11; i < noThreads; i++) {try {listThreads[i].join();} catch (InterruptedException e) {e.printStackTrace();}}

     }

     class ObjCollection implements Runnable {
		   private Thread t;
		   private String sThreadName;
		   private int i1;
		   private int i2;
		   private List<WebElement>  ObjList;

		   ObjCollection(String sName, int iStart, int iStop, List<WebElement>  Objlist) {
		      i1 = iStart;
		      i2 = iStop;
		      sThreadName = sName;
		      ObjList = Objlist;
		   }

		   public void run() {
			   System.out.println("Starting Thread : "+ sThreadName);
			  	  String ID 		= null;
			  	  String Name 		= null;
			  	  String LinkText 	= null;
			  	  String TagName 	= null;
			  	  String Class 		= null;

			  	   for(int i = i1; 	i<i2; 	i++)
			  	   {
			  		   try {TagName 	= ObjList.get(i).getTagName();} catch (Exception e) {TagName  = null;}
			  		   if(TagName!="table"  | TagName!="tr" | TagName!="td" | TagName != null){
			  			   try {Class 		= ObjList.get(i).getAttribute("class");	} catch (Exception e) {Class 	= null;}
					       try {ID 			= ObjList.get(i).getAttribute("id");	} catch (Exception e) {ID 	  	= null;}
					       try {Name 		= ObjList.get(i).getAttribute("name"); 	} catch (Exception e) {Name 	= null;}
					       try {LinkText 	= ObjList.get(i).getText(); 			} catch (Exception e) {LinkText = null;}

					    if ((ID!=null && ID!="") | (Name!=null && Name!="") | (LinkText!=null && LinkText != "")){
					    	String insertIntoObj ="insert into OBJ_WH (OWHID, ID, NAME, LINKTEXT, TAG_NAME, CLASS_NAME, TITLE, PAGEURL, APPLICATION) values ('"
		                          + (iObjCount + i) + "', '"
		            			  + ID + "','"
		            			  + Name + "','"
		            			  + LinkText + "','"
		            			  + TagName + "','"
		            			  + Class + "','"
		                    	  + Title + "','"
		                    	  + URL + "','"
		            			  + sAUT + "')";

			            	System.out.println(insertIntoObj);
			            	if (insertIntoObj.contains("'")) insertIntoObj.replace("'", "''");
			            	try {Tcon.createStatement().executeUpdate(insertIntoObj);} catch (SQLException e) {e.printStackTrace();}
					    }
			          }
			  	   }
			   System.out.println("Exiting Thread : "+ sThreadName);
		   }

		   public void start () {
		      if (t == null) {t = new Thread (this); t.start ();}
		   }
	}*/
    public void CollectObjects(final List<WebElement> ObjList)  {

        final int iSize = ObjList.size();
        iObjCount = iObjCount + iSize;
        System.out.println("Number of Objects present on this page: "+iSize);
        Log("Number of Objects present on this page: "+iSize);
        final int j = (int) (Math.floor(iSize/10));

       ExecutorService executor = Executors.newFixedThreadPool(11);
       Set<Callable<Void>> callables =  new HashSet<Callable<Void>> ();

       callables.add(new Callable<Void>() { public Void call() {collObj((0*j)+1, 1*j,  ObjList);	return null; }});
       callables.add(new Callable<Void>() { public Void call() {collObj((1*j)+1, 2*j,  ObjList);	return null; }});
       callables.add(new Callable<Void>() { public Void call() {collObj((2*j)+1, 3*j,  ObjList);	return null; }});
       callables.add(new Callable<Void>() { public Void call() {collObj((3*j)+1, 4*j,  ObjList);	return null; }});
       callables.add(new Callable<Void>() { public Void call() {collObj((4*j)+1, 5*j,  ObjList);	return null; }});
       callables.add(new Callable<Void>() { public Void call() {collObj((5*j)+1, 6*j,  ObjList);	return null; }});
       callables.add(new Callable<Void>() { public Void call() {collObj((6*j)+1, 7*j,  ObjList);	return null; }});
       callables.add(new Callable<Void>() { public Void call() {collObj((7*j)+1, 8*j,  ObjList);	return null; }});
       callables.add(new Callable<Void>() { public Void call() {collObj((8*j)+1, 9*j,  ObjList);	return null; }});
       callables.add(new Callable<Void>() { public Void call() {collObj((9*j)+1, 10*j, ObjList);	return null; }});
       callables.add(new Callable<Void>() { public Void call() {collObj((10*j)+1,iSize-1, ObjList);	return null; }});

       try {
		List<Future<Void>> invokeAll = executor.invokeAll(callables);
		   for (Future<Void> future : invokeAll) {
				future.get(100, TimeUnit.SECONDS);
		   }
       }
       catch (InterruptedException e) {e.printStackTrace();} catch (ExecutionException e) {e.printStackTrace();} catch (TimeoutException e) {e.printStackTrace();}
       executor.shutdown();
    }

    void collObj(int j, int j2, List<WebElement> objList2){
                 String ID         = null;
                 String Name       = null;
                 String LinkText   = null;
                 String TagName    = null;
                 
                 String Class      = null;

                  for(int i = j;   i<j2; i++)
                  {
                        try {TagName     = objList2.get(i).getTagName();} catch (Exception e) {TagName  = null;}
                        if(TagName!="table"  | TagName!="tr" | TagName!="td" | TagName != null){

                             try {Thread.sleep(1000); Class 	= objList2.get(i).getAttribute("class");} catch (Exception e) {Class    = null;}
                             try {Thread.sleep(1000); ID    	= objList2.get(i).getAttribute("id");   } catch (Exception e) {ID       = null;}
                             try {					  Name      = objList2.get(i).getAttribute("name"); } catch (Exception e) {Name 	= null;}
                             try {					  LinkText  = objList2.get(i).getText();            } catch (Exception e) {LinkText = null;}

                        	  String insertIntoObj ="insert into OBJ_WH (OWHID, ID, NAME, LINKTEXT, TAG_NAME, CLASS_NAME, TITLE, PAGEURL, APPLICATION) values ('"
                        	   + i + "', '"
                               + ID + "','"
                               + Name + "','"
                               + LinkText + "','"
                               + TagName + "','"
                               + Class + "','"
                               + Title + "','"
                               + URL + "','"
                               + sAUT + "')";

		                    System.out.println(insertIntoObj);
		                    if (insertIntoObj.contains("'")) insertIntoObj.replace("'", "''");
		                    try {Thread.sleep(1000);Tcon.createStatement().executeUpdate(insertIntoObj);} catch (Exception e) {e.printStackTrace();}
                       }
                  }
    }
    String replacePrimaryKey(String squery, String resultSetColumnName)throws Exception{
    	String TPK_RTVAL="";
			ResultSet rs_Driver = Tcon.createStatement().executeQuery(squery);
			if (rs_Driver.next()) {
				TPK_RTVAL = rs_Driver.getString(resultSetColumnName);
		}
			return TPK_RTVAL;
    }
    public void webservices() throws Exception{
    	String xmlInput=null;  String getText="";  String getServerResponse="";
    	if(dataRef.contains("||")){
    		xmlInput = dataRef.split("\\|\\|")[0];
    		
			HttpURLConnection httpConn = (HttpURLConnection) new URL(Settings.getSetting("SOAP_URL", Tcon)).openConnection();
			if(dataRef.split("\\|\\|")[0].contains("RTVAL"))
				xmlInput = dataRef.split("\\|\\|")[0].replace("RTVAL"+dataRef.split("RTVAL")[1].split("</")[0],
						replacePrimaryKey("SELECT TEST_DATA FROM DRIVER WHERE APPLICATION = '" +sAUT + "' and TCID = '" +Tid + "' and Moduleid = '" +Mid+"' and RTVAL_REF = 'RTVAL"+dataRef.split("RTVAL")[1].split("</")[0]+"'",
								"TEST_DATA"));
			if(dataRef.split("\\|\\|")[0].contains("TPK"))
				xmlInput = dataRef.split("\\|\\|")[0].replace("TPK", replacePrimaryKey("SELECT ACTIVE_TPK FROM DM_MAP WHERE MODULEID ='"+Mid+"' AND TCID='"+Tid+"'", "ACTIVE_TPK"));
			
			while (xmlInput.contains("RTVAL")) {
				xmlInput =xmlInput.replace("RTVAL" + xmlInput.split("RTVAL")[1].split("</")[0], 
						replacePrimaryKey("SELECT TEST_DATA FROM DRIVER WHERE APPLICATION = '" +sAUT + "' and TCID = '" +Tid + "' and Moduleid = '" +Mid+"' and RTVAL_REF = 'RTVAL"+xmlInput.split("RTVAL")[1].split("</")[0]+"'",
						"TEST_DATA"));
			}
			
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			bout.write(xmlInput.getBytes());//this will return you the xml input
			byte[] b = bout.toByteArray();
			httpConn.setRequestProperty("Content-Length", String.valueOf(b.length));
			httpConn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
			
			httpConn.setRequestProperty("SOAPAction",dataRef.split("xmlns:web=\"")[1].split("\">")[0]+dataRef.split("<web:")[1].split(">")[0]);
			
			
			httpConn.setRequestMethod("POST");
			httpConn.setDoOutput(true);
			httpConn.setDoInput(true);
	
			OutputStream out = httpConn.getOutputStream();
			out.write(b);out.close();
			
	
			try {
				BufferedReader in = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));
				while ((responseString = in.readLine()) != null) {
					outputString = outputString + responseString;
				}
			} catch (Exception e) {
				Log("@@@@@@@ Error! XML input is incorrect.");
			}
			Document document = parseXmlFile(outputString);
			if(objectRef.contains(",")){
				String[] splitObjref = objectRef.split(",");
				for (int i=0; i<=splitObjref.length-1; i++) {
					if(isFailure ==true){
						break;
					}
					if(!splitObjref[i].equals("")){
						getObject(splitObjref[i].replace(" ", ""));
						getText+=webelm.getText()+",";
					}
					if(dataRef.split("\\|\\|")[1].contains(",")) {
						String[] splitDataRef = dataRef.split("\\|\\|")[1].split(",");
						for (int j=0; j<=splitDataRef.length-1; j++) {
							if(i==j){
								if(!splitDataRef[j].equals("")) {
									System.out.println("Comparing web elem text  "+webelm.getText()+ " against Webservices response " +document.getElementsByTagName(splitDataRef[j].replace(" ", "")).item(0).getTextContent() );
									if (!(webelm.getText().contains( document.getElementsByTagName(splitDataRef[j].replace(" ", "")).item(0).getTextContent())))
										isFailure = true;
										
									getServerResponse+=  document.getElementsByTagName(splitDataRef[j].replace(" ", "")).item(0).getTextContent()+",";
								}
							}
						}
					}
				}
				Tcon.createStatement().executeUpdate("Update DRIVER Set TEST_DATA ='"+getText+"||"+getServerResponse+"' where Application = '"+sAUT+"' and TCID = '" +Tid + "' and MODULEID = '" +Mid + "' and STEPID = "+Sid);
			}else{
				outputString = document.getElementsByTagName(dataRef.split("\\|\\|")[1]).item(0).getTextContent();
				if (!(webelm.getText().contains(outputString))) isFailure = true;
				Tcon.createStatement().executeUpdate("Update DRIVER Set TEST_DATA ='"+webelm.getText()+"||"+outputString+"' where Application = '"+sAUT+"' and TCID = '" +Tid + "' and MODULEID = '" +Mid + "' and STEPID = "+Sid);
			}
	    	}
    	else 
    		 Log("@@@@@@@ Warning! Step incorrectly written. Need more arguments in Dataref for comparision.");
    	xmlInput="";
    	dataRef="";
    	outputString="";
    }
    private static Document parseXmlFile(String in) {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			InputSource is = new InputSource(new StringReader(in));
			return (Document) db.parse(is);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	  public String VerifyURL(String url2) {
	        String ERRORCODE = "";
	        try {
	        	  URL currentURl = new URL(url2);
	              HttpURLConnection urlConnection = (HttpURLConnection)currentURl.openConnection();
	              ERRORCODE =URLStatus.getStatusMessageForStatusCode(urlConnection.getResponseCode()) + " For URL " + currentURl;
	              
	              if(urlConnection.getResponseCode() == URLStatus.INTERNAL_SERVER_ERROR.getStatusCode()  || urlConnection.getResponseCode() == URLStatus.NOT_FOUND.getStatusCode()){
	              ERRORCODE = URLStatus.getStatusMessageForStatusCode(urlConnection.getResponseCode()) + " For URL " +currentURl;
	              isFailure = true;
	              }
	              
	              System.out.println(ERRORCODE);
	        }catch(Exception e) {
	              System.out.println(e.getMessage());
	            isFailure = true;
	        }
	        return ERRORCODE;
	  }
	  public void VerifyXML(){
			String expectedValue = DataHandler.value; 
			PlaceTestData(expectedValue);
			
			if (!objectRef.equalsIgnoreCase("null") && !objectRef.equalsIgnoreCase("NA") && !objectRef.equalsIgnoreCase(""))
				if(!(webelm.getText().equalsIgnoreCase(expectedValue)))
					isFailure=true;
			else
				compareData(expectedValue);
				
		}
			

		private void compareData(String Fparameter) {
		    
		    if(getLastParam().startsWith("#SQ"))
		    	if (callProcDataRef (dataRef))
		    		getTData();
		    System.out.println("Comparision between "+Fparameter+"&"+tData);
		    
		    if(!(tData.equalsIgnoreCase(Fparameter)))
		    	isFailure=true;
		}
		    	


		private String getLastParam(){
		    return dataRef.split("\\|")[dataRef.split("\\|").length-1];

		}
		
		private void ReplaceTPK(String templateParam) throws Exception{
			if(rtvalRef!=null)
			if(rtvalRef.equalsIgnoreCase("RTVAL0")){
				try {
					String rtVal = DataHandler.getRTVal(Tcon, sAUT, Mid, Tid, templateParam, "RTVAL0");
					Statement st1=Tcon.createStatement();
					st1.executeUpdate("Update DM_MAP Set ACTIVE_TPK= '" +rtVal + "'  where Moduleid = '"+ Mid + "' and TCID = '"+ Tid +"' ");
				} catch (Exception e) {
					isFailure=true;
					Log("Failed to replace RTVAL0 with TPK");
				}
			}
		}
		

}