package com.optum.coliseum.driver;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.optum.coliseum.generic.Constants;
import com.optum.coliseum.generic.DBUtils;

public class Recorder {

	public WebElement webelm;
	public WebDriver driver;
	public Connection Tcon;
	public WebDriverWait wait;

	public static void main(String []args) throws Exception
	{
		Recorder recorder = new Recorder();
		recorder.Recording();
	}

	public void Recording() {
			Tcon = DBUtils.DBConnect_Automation();
			String sEnv = null;
			String sAUT = null;
			try {
				Statement st01=Tcon.createStatement();
				ResultSet rs01=st01.executeQuery("select * from SETTINGS where KEY = 'ENVIRONMENT'" );
				while (rs01.next()) { sEnv = rs01.getString("VALUE");}

				Statement st02=Tcon.createStatement();
				ResultSet rs02=st02.executeQuery("select * from SETTINGS where KEY = 'AUT'" );
				while (rs02.next()) { sAUT = rs02.getString("VALUE");}

				InitBrowser(sEnv, sAUT);

				WebElement activeElement = driver.switchTo().activeElement();
				String className =  activeElement.getAttribute("class");
				String id = activeElement.getAttribute("id");
				String name = activeElement.getAttribute("name");
				System.out.println(className);
				System.out.println(id);
				System.out.println(name);

				/*try {LogOutandClose();} catch (Exception e) {e.printStackTrace();}*/
			}
			catch (SQLException e) {e.printStackTrace();}
		}

	public void InitBrowser(String sEnv, String sApp){
		String sURL = null;
		String browser = null;

		try {
			Tcon = DBUtils.DBConnect_Automation();
			Statement st01=Tcon.createStatement();
			ResultSet rs01=st01.executeQuery("select * from [ENV] where TEST_ENVIRONMENT='"+sEnv+"' and APPLICATION = '"+sApp+"'" );
			System.out.println("select * from [ENV] where TEST_ENVIRONMENT='"+sEnv+"' and APPLICATION = '"+sApp+"'" );
			if(rs01.next()) sURL = rs01.getString("LOGIN_URL");

			Statement st00=Tcon.createStatement();
			ResultSet rs00=st00.executeQuery("select VALUE from SETTINGS WHERE KEY = 'BROWSER'" );
			if(rs00.next()) browser = rs00.getString("VALUE");
		} catch (SQLException e) {
			e.printStackTrace();
		}

        if (browser.equalsIgnoreCase("FIREFOX")){
	        driver = new FirefoxDriver();
	        driver.get(sURL);
	        driver.manage().window().maximize();
        }
        else if(browser.equalsIgnoreCase("IE")){
	    	DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
	        ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
	        System.setProperty("webdriver.ie.driver", Constants.PATH_DRIVERS_IEDRIVERSERVER);
	       	driver = new InternetExplorerDriver(ieCapabilities);
	        driver.manage().window().maximize();
	        driver.navigate().to(sURL);
	      	driver.findElement(By.id("overridelink")).click();
        }
        else if(browser.equalsIgnoreCase("CHROME")){
        	System.setProperty("webdriver.chrome.driver", Constants.PATH_DRIVERS_CHROMEDRIVER);
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--start-maximized");
            driver = new ChromeDriver( options );
            driver.get(sURL);
         }
	}

	public void LoginAction(String sApp, String sUserName, String sPassword){
		String sPW = "password";
		String sSubmitXPath = null;

		switch (sApp) {
		case "MAGNOLIA" 	: sSubmitXPath = ".//input[@type='submit']"; 														break;
		case "MAPLE" 		: sSubmitXPath = ".//*[@id=loginsection]/form/div/div[3]/button"; sPW = "userpass";					break;
		case "ADMINCONSOLE" : sSubmitXPath = ".//*[@id='loginbutton']"; 														break;
		case "SEQUOIA"		: sSubmitXPath = ".//*[@id='login']/table[2]/tbody/tr[5]/td/input"; 								break;
		case "C4" 			: sSubmitXPath = ".//*[@id='loginDiv']/form/table/tbody/tr/td[2]/div/table/tbody/tr[5]/td[2]/input";break;
		}

		wait  = new WebDriverWait(driver, 10);

		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.name("username"))).sendKeys(sUserName);
			wait.until(ExpectedConditions.elementToBeClickable(By.name(sPW))).sendKeys(sPassword);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(sSubmitXPath))).click();
		} catch (Exception e) {
			System.out.println("Login page objects distorted for "+ sApp);
			e.printStackTrace();
		}
	}

	public void LogOutandClose() throws Exception{
		try {
			driver.get(Constants.PATH_REPORTS_FOLDER + "Reports.html");
			Tcon.close();
		} catch (Exception e) {e.printStackTrace();}
	}

}
